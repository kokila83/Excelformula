﻿namespace Scripter
{
    using System;
    using System.Data.Common;
    using System.IO;

    /// <summary>
    /// A class for reading text from a database.
    /// </summary>
    public sealed class DbReader : TextReader
    {
        private DbDataReader reader;
        private DbCommand command;
        private bool canAdvance = false;

        private string[] text;
        private string line;
        private char[] buffer = new char[0];
        private int position = 0;

        /// <summary>
        /// Create a new DbReader to read text data from a database.
        /// </summary>
        /// <param name="connection">The database connection to read.</param>
        /// <param name="query">The query to read.</param>
        public DbReader(DbConnection connection, string query)
        {
            command = connection.CreateCommand();
            command.CommandTimeout = 24 * 3600;
            command.CommandText = query;
            reader = command.ExecuteReader();
            Advance();
        }

        // Finalizer
        ~DbReader()
        {
            Dispose(false);
        }
        
        private bool CanRead
        {
            get
            {
                return canAdvance || (position < buffer.Length);
            }
        }

        public override string ReadToEnd()
        {
            StringWriter writer = new StringWriter();
            while (Peek() != -1)
            {
                writer.Write((char)Read());
            }
            return writer.ToString();
        }
        
        public override int Read()
        {
            int value = (int)buffer[position];
            position++;

            if (position >= buffer.Length)
            {
                Advance();
            }

            return value;
        }

        public override string ReadLine()
        {
            if (buffer.Length > 0 && position < buffer.Length) // this has been problematic and may not be the best long-term solution
            {
                string value = new string(buffer, position, buffer.Length - position - 1);
                position = buffer.Length;
                Advance();
                return value;
            }
            else return string.Empty;
        }

        public override int Peek()
        {
            return CanRead ? 1 : -1;
        }

        public override int Read(char[] buffer, int index, int count)
        {
            int readCount = 0;
            for (int i = index; i < index + count && this.CanRead; i++)
            {
                buffer[i] = (char)Read();
                readCount++;
            }
            return readCount;
        }

        public override int ReadBlock(char[] buffer, int index, int count)
        {
            return this.Read(buffer, index, count);
        }

        protected override void Dispose(bool disposing)
        {
            // Do not close the connection, since that is an input
            // but do close the Command and Reader if not already closed
            if (reader != null)
            {
                reader.Dispose();
                reader = null;
            }
            if (command != null)
            {
                command.Dispose();
                command = null;
            }

            GC.SuppressFinalize(this);
            base.Dispose(disposing);
        }

        private void Advance()
        {
            canAdvance = reader.Read();

            if (canAdvance)
            {
                text = new string[reader.FieldCount];
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if (!reader.IsDBNull(i))
                    {
                        // Dates Are Not Converted to yyyy-MM-dd by Default.
                        if (reader.GetDataTypeName(i) == "DATE")
                        {
                            text[i] = reader.GetDateTime(i).ToString("yyyy-MM-dd");
                        }
                        else text[i] = reader.GetString(i);
                    }
                    else text[i] = "\\N";
                }
                line = string.Join("\t", text) + "\n";
                buffer = line.ToCharArray();
                position = 0;
            }
        }
    }
}