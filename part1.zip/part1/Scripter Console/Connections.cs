﻿using Microsoft.Win32;
using System;
using System.Data.Common;

using MySql.Data.MySqlClient;
using Oracle.DataAccess.Client;
using Sybase.Data.AseClient;
using System.Security.Principal;
using System.Net.NetworkInformation;
using System.Net;

namespace Scripter
{
    /// <summary>
    /// static class for managing connection information and establishing connections
    /// </summary>
    public static class Connections
    {
        /// <summary>
        /// list of supported database providers
        /// </summary>
        public static string[] Providers = { "MySQL", "Oracle", "Sybase" };

        /// <summary>
        /// checks whether the current application is running as administrator
        /// </summary>
        /// <returns></returns>
        private static bool IsAdmin()
        {
            using (var identity = WindowsIdentity.GetCurrent())
            {
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        /// <summary>
        /// static constructor, runs automatically whenever the connections class is used
        /// </summary>
        static Connections()
        {            
            RegistryKey rkSoftware = null, rkProduct = null, rkConnections = null;

            try
            {
                // location of software in the registry
                rkSoftware = IsAdmin()
                    ? Registry.LocalMachine.OpenSubKey("Software", RegistryKeyPermissionCheck.ReadWriteSubTree)
                    : Registry.CurrentUser.OpenSubKey("Software", RegistryKeyPermissionCheck.ReadWriteSubTree);

                // make sure there is an entry for Scripter
                rkProduct = rkSoftware.OpenSubKey("Scripter", RegistryKeyPermissionCheck.ReadWriteSubTree);
                if (rkProduct == null)
                    rkProduct = rkSoftware.CreateSubKey("Scripter", RegistryKeyPermissionCheck.ReadWriteSubTree);

                // make sure there is an entry for Scriter/Connections
                rkConnections = rkProduct.OpenSubKey("Connections", RegistryKeyPermissionCheck.ReadWriteSubTree);
                if (rkConnections == null)
                    rkConnections = rkProduct.CreateSubKey("Connections", RegistryKeyPermissionCheck.ReadWriteSubTree);
            }
            finally
            {
                // dispose of unmanged objects
                if (rkSoftware != null)
                {
                    rkSoftware.Dispose();
                    rkSoftware = null;
                }
                if (rkProduct != null)
                {
                    rkProduct.Dispose();
                    rkProduct = null;
                }
                if (rkConnections != null)
                {
                    rkConnections.Dispose();
                    rkConnections = null;
                }
            }
        }

        /// <summary>
        /// save the connection to the registry
        /// </summary>
        /// <param name="name">connection name</param>
        /// <param name="provider">database provider</param>
        /// <param name="connectionString">connection string</param>
        public static void Save(string name, string provider, string connectionString)
        {
            using (RegistryKey rkSoftware = IsAdmin() 
                ? Registry.LocalMachine.OpenSubKey("Software") 
                : Registry.CurrentUser.OpenSubKey("Software"))
            using (RegistryKey rkProduct = rkSoftware.OpenSubKey("Scripter"))
            using (RegistryKey rkConnections = rkProduct.OpenSubKey("Connections", true))
            {
                RegistryKey rkName = rkConnections.CreateSubKey(name, RegistryKeyPermissionCheck.ReadWriteSubTree);

                rkName.SetValue("Name", name, RegistryValueKind.String);
                rkName.SetValue("Provider", provider, RegistryValueKind.String);
                rkName.SetValue("ConnectionString", connectionString, RegistryValueKind.String);
            }
        }

        /// <summary>
        /// read all available connection names from the registry
        /// </summary>
        /// <returns></returns>
        public static string[] Read()
        {
            // list of connection names, empty to start
            var list = new System.Collections.Generic.List<string>();

            // location of software in the registry
            using (RegistryKey rkSoftware = IsAdmin() 
                ? Registry.LocalMachine.OpenSubKey("Software") 
                : Registry.CurrentUser.OpenSubKey("Software"))
            using (RegistryKey rkProduct = rkSoftware.OpenSubKey("Scripter"))
            using (RegistryKey rkConnections = rkProduct.OpenSubKey("Connections"))
                foreach (string keyName in rkConnections.GetSubKeyNames())
                    list.Add(keyName);

            // convert list of connection names to an array
            return list.ToArray();
        }

        /// <summary>
        /// read connection details from the registry
        /// </summary>
        /// <param name="name">connection name</param>
        /// <param name="provider">database provider</param>
        /// <param name="connectionString">connection string</param>
        public static void Read(string name, out string provider, out string connectionString)
        {
            using (RegistryKey rkSoftware = IsAdmin() 
                ? Registry.LocalMachine.OpenSubKey("Software") 
                : Registry.CurrentUser.OpenSubKey("Software"))
            using (RegistryKey rkProduct = rkSoftware.OpenSubKey("Scripter"))
            using (RegistryKey rkConnections = rkProduct.OpenSubKey("Connections"))
            using (RegistryKey rkEntry = rkConnections.OpenSubKey(name))
            {
                provider = (string)rkEntry.GetValue("Provider");
                connectionString = (string)rkEntry.GetValue("ConnectionString");                
            }
        }

        /// <summary>
        /// delete the connection from the registry
        /// </summary>
        /// <param name="name">connection name</param>
        public static void Delete(string name)
        {
            using (RegistryKey rkSoftware = IsAdmin()
                ? Registry.LocalMachine.OpenSubKey("Software")
                : Registry.CurrentUser.OpenSubKey("Software"))
            using (RegistryKey rkProduct = rkSoftware.OpenSubKey("Scripter"))
            using (RegistryKey rkConnections = rkProduct.OpenSubKey("Connections", RegistryKeyPermissionCheck.ReadWriteSubTree))
                rkConnections.DeleteSubKey(name);
        }
       
        /// <summary>
        /// get an ado.net database connection
        /// </summary>
        /// <param name="name">connection name</param>
        public static DbConnection GetConnection(string name)
        {
            // read connection details from the registry
            string provider = null, connectionString = null;
            Read(name, out provider, out connectionString);

            // create a new database connection
            if (provider == "MySQL")
                return new MySqlConnection(connectionString);

            else if (provider == "Sybase")
                return new AseConnection(connectionString);

            else if (provider == "Oracle")
                return new OracleConnection(connectionString);

            else throw new ArgumentException("Unhandled Database Provider", provider);
        }

        /// <summary>
        /// test a database connection
        /// </summary>
        /// <param name="name">name of the connection to test</param>
        /// <param name="success">indicates whether the test was successful</param>
        /// <param name="message">message about the test result</param>
        public static void TestConnection(string provider, string connectionString, out bool success, out string message)
        {
            success = false;
            message = "The test was not conducted";

            try
            {
                if (provider == "MySQL")
                {
                    using (var connection = new MySqlConnection(connectionString))
                    {                        
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                        connection.Open();                         
                          
                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = "select now()";
                            command.CommandTimeout = 10;
                            message = ((DateTime)command.ExecuteScalar()).ToLongTimeString();
                            message = string.Format("Connection Successful.  Current database time is {0}", message);
                            success = true;
                        }
                    }
                }
                else if (provider == "Oracle")
                {
                    using (var connection = new OracleConnection(connectionString))
                    {
                        connection.Open();
                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = "select sysdate from dual";
                            command.CommandTimeout = 10;
                            message = ((DateTime)command.ExecuteScalar()).ToLongTimeString();
                            message = string.Format("Connection Successful.  Current database time is {0}", message);
                            success = true;
                        }
                    }
                }
                else if (provider == "Sybase")
                {
                    using (var connection = new AseConnection(connectionString))
                    {
                        connection.Open();
                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = "select getdate()";
                            command.CommandTimeout = 10;
                            message = ((DateTime)command.ExecuteScalar()).ToLongTimeString();
                            message = string.Format("Connection Successful.  Current database time is {0}", message);
                            success = true;
                        }
                    }
                }             
            }
            catch (Exception exception)
            {
                success = false;
                message = string.Format("Connection Failed with error message: {0}", exception.Message);

                if (exception.InnerException != null)
                    message += exception.InnerException.Message;
            }
        }
    }
}
