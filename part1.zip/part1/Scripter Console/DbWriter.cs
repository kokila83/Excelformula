﻿namespace Scripter
{
    using System;
    using System.Data.Common;
    using System.IO;
    using System.Text;

    /// <summary>
    /// A class for writing data to a database.
    /// </summary>
    public sealed class DbWriter : System.IO.TextWriter
    {
        private DbCommand command;

        private string table;
        private StringWriter writer = new StringWriter();
        private char delimiter;

        private bool insideSingleQuote = false;
        private bool insideDoubleQuote = false;

        /// <summary>
        /// Create a new Database Writer
        /// </summary>
        /// <param name="connection">The target database connection</param>
        /// <param name="table">The target database table name</param>
        public DbWriter(DbConnection connection, string table)
        {
            this.table = table;
            this.command = connection.CreateCommand();
            this.command.CommandTimeout = 3600;
            this.delimiter = '\t';
        }

        /// <summary>
        /// Create a new DbWriter to write text to a database table.
        /// </summary>
        /// <param name="connection">The database connection.</param>
        /// <param name="table">The table to append.</param>
        /// <param name="delimiter">The column delimiter.</param>
        public DbWriter(DbConnection connection, string table, char delimiter)
        {
            this.table = table;
            this.command = connection.CreateCommand();
            this.command.CommandTimeout = 3600;
            this.delimiter = delimiter;
        }

        // Finalizer
        ~DbWriter()
        {
            Dispose(false);
        }

        public override Encoding Encoding
        {
            get { return Encoding.Default; }
        }

        public override void Write(bool value)
        {
            writer.Write(value);
        }

        public override void Write(char value)
        {
            if ((value == '\n') && !insideSingleQuote && !insideDoubleQuote)
            {
                Insert(this.writer.ToString());     // Submit INSERT Statement
                this.writer.Dispose();
                this.writer = new StringWriter();   // Reset StringWriter()
                return;
            }
            else if (value == '\"' && !insideSingleQuote)
            {
                insideDoubleQuote = !insideDoubleQuote;
            }
            else if (value == '\'' && !insideDoubleQuote)
            {
                insideSingleQuote = !insideSingleQuote;
            }
            else if (value == '\r')
            {
                return;
            }
            else
            {
                writer.Write((char)value);
                return;
            }
        } // ** IMPORTANT **
                
        public override void Write(char[] buffer)
        {
            for (int i = 0; i < buffer.Length; i++)
            {
                this.Write((char)buffer[i]);
            }
        }

        public override void Write(char[] buffer, int index, int count)
        {
            for (int i = index; i < count; i++)
            {
                this.Write((char)buffer[i]);
            }
        }

        public override void Write(decimal value)
        {
            writer.Write(value);
        }

        public override void Write(double value)
        {
            writer.Write(value);
        }

        public override void Write(float value)
        {
            writer.Write(value);
        }

        public override void Write(int value)
        {
            writer.Write(value);
        }

        public override void Write(long value)
        {
            writer.Write(value);
        }

        public override void Write(object value)
        {
            this.Write(value.ToString());
        }

        public override void Write(string format, object arg0)
        {
            this.Write(string.Format(format, arg0));
        }

        public override void Write(string format, object arg0, object arg1)
        {
            this.Write(string.Format(format, arg0, arg1));
        }

        public override void Write(string format, object arg0, object arg1, object arg2)
        {
            this.Write(string.Format(format, arg0, arg1, arg2));
        }

        public override void Write(string format, params object[] arg)
        {
            this.Write(string.Format(format, arg));
        }

        public override void Write(string value)
        {
            for (int i = 0; i < value.Length; i++)
            {
                Write((char)value[i]);
            }
        } // ** IMPORTANT **

        public override void Write(uint value)
        {
            writer.Write(value);
        }

        public override void Write(ulong value)
        {
            writer.Write(value);
        }

        public override void WriteLine()
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(bool value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(char value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(char[] buffer)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(char[] buffer, int index, int count)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(decimal value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(double value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(float value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(int value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(long value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(object value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(string format, object arg0)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(string format, object arg0, object arg1)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(string format, object arg0, object arg1, object arg2)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(string format, params object[] arg)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(string value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(uint value)
        {
            throw new NotImplementedException();
        }

        public override void WriteLine(ulong value)
        {
            throw new NotImplementedException();
        }

        protected override void Dispose(bool disposing)
        {
            if (command != null)
            {
                command.Dispose();
                command = null;
            }
            if (writer != null)
            {
                writer.Dispose();
                writer = null;
            }
            base.Dispose();

            base.Dispose(disposing);
            GC.SuppressFinalize(this);
        }

        private void Insert(string[] text)
        {
            this.command.CommandText = string.Format("INSERT IGNORE INTO {0} SELECT '{1}';", table, string.Join("','", text));
            this.command.ExecuteNonQuery();
        }

        private void Insert(string line)
        {
            this.command.CommandText = string.Format("INSERT IGNORE INTO {0} SELECT '{1}';", table, string.Join("','", line.Split(delimiter)));
            this.command.ExecuteNonQuery();
        }
    }
}