﻿namespace Scripter
{
    using System;
    using System.Collections.Generic;
    using System.Data.Common;
    using System.IO;
    using System.Text;

    using Scripter.Office.Excel;
    using Scripter.Office.PowerPoint;

    /// <summary>
    /// Use a standard textbox as a console writer.
    /// </summary>
    /// <remarks>
    /// Add the following lines after InitializeComponent(); 
    ///   Console.SetOut(new ConsoleWriter(this.MessageLog)); 
    ///   Log.WriteLine("Application Started..{0}", Environment.NewLine);
    /// </remarks>
    public sealed class ConsoleWriter : TextWriter
    {
        private System.Windows.Forms.TextBox textBox;

        /// <summary>
        /// Create a new ConsoleWriter
        /// </summary>
        /// <param name="textBox">The Windows.Forms.Textbox to wrap.</param>
        public ConsoleWriter(System.Windows.Forms.TextBox textBox)
        {
            this.textBox = textBox;
        }

        // Delegate for the WriteLine() Function
        private delegate void WriteLineDelegate(string text);

        // Delegate for the Write() Function
        private delegate void WriteDelegate(string text);

        /// <summary>
        /// Gets the text encoding.
        /// </summary>
        public override Encoding Encoding
        {
            get { return Encoding.ASCII; }
        }

        /// <summary>
        /// Write text to the stream.
        /// </summary>
        /// <param name="text">The text to write.</param>
        public override void Write(string text)
        {
            if (textBox.InvokeRequired)
            {
                WriteDelegate writeDelegate = new WriteDelegate(Write);
                textBox.Invoke(writeDelegate, text);
            }
            else
            {
                textBox.AppendText(text);
            }
        }

        /// <summary>
        /// Write a line of text to the stream.
        /// </summary>
        /// <param name="text">The line of text to write.</param>
        public override void WriteLine(string text)
        {
            if (textBox.InvokeRequired)
            {
                WriteLineDelegate writeDelegate = new WriteLineDelegate(WriteLine);
                this.textBox.Invoke(writeDelegate, text);
            }
            else
            {
                this.textBox.AppendText(text + Environment.NewLine);
            }
        }
    }

    /// <summary>
    /// Script
    /// </summary>
    public sealed class Script : IDisposable
    {
        private static SortedList<string, string> custom
            = new SortedList<string, string>();

        private int count = 1;                      // The number of lines in the script

        private DbConnection dbInstance;
        private string sqlPath;

        private Scripter.Office.Excel.Application xlInstance;
        private Scripter.Office.Excel.Book xlBook;

        private Scripter.Office.PowerPoint.Application ppInstance;
        private Scripter.Office.PowerPoint.Deck ppDeck;

        private bool xlStarted = false; // Indicates whether Microsoft XL was started from within this script.
        private bool ppStarted = false; // Indicates whether Microsoft PP was started from within this script.

        private bool xlOpen = false;  // Indicates whether the xl document is open.
        private bool ppOpen = false;  // Indicates whether the pp document is open.    

        private static int commandTimeout = 3600 * 24; 

        // Static Constructor
        static Script()
        {
            custom.Add("plan", null);
            custom.Add("date", null);
            custom.Add("peer", null);
            custom.Add("path", null);
            custom.Add("sqlscalar", null);
        }

        /// <summary>
        /// Create a new script processor.
        /// </summary>
        /// <param name="filename">The file to process.</param>
        /// <param name="connection">The database connection to use.</param>
        /// <param name="xlInstance">The Microsoft Excel application instance to use.</param>
        /// <param name="ppInstance">The Microsoft PowerPoint application instance to use.</param>
        public Script(string filename
            , DbConnection connection
            , Scripter.Office.Excel.Application xlInstance
            , Scripter.Office.PowerPoint.Application ppInstance)
            : this(filename, connection, xlInstance)
        {
            // Setup PowerPoint Application Instance
            if (ppInstance != null)
            {
                this.ppInstance = ppInstance;
                this.PpEnabled = true;
            }
            else this.PpEnabled = false;
        }

        /// <summary>
        /// Create a new script processor.
        /// </summary>
        /// <param name="filename">The file to process.</param>
        /// <param name="connection">The database connection to use.</param>
        /// <param name="xlInstance">The Microsoft Excel application instance to use.</param>
        public Script(string filename
            , DbConnection connection
            , Scripter.Office.Excel.Application xlInstance)
            : this(filename, connection)
        {
            // Setup Excel Application Instance
            if (xlInstance != null)
            {
                this.xlInstance = xlInstance;
                this.XlEnabled = true;
            }
            else this.XlEnabled = false;
        }

        /// <summary>
        /// Create a new script processor.
        /// </summary>
        /// <param name="filename">The file to process.</param>
        /// <param name="connection">The database connection to use.</param>
        public Script(string filename, DbConnection connection)
            : this(filename)
        {
            // Setup Database Connection
            if (connection != null)
            {
                if (connection.State != System.Data.ConnectionState.Open)
                    connection.Open();

                this.dbInstance = connection;
                this.DbEnabled = true;
            }
            else this.DbEnabled = false;
        }

        /// <summary>
        /// Create a new script processor.
        /// </summary>
        /// <param name="filename">The file to process.</param>
        public Script(string filename)
        {
            // Setup Sql Path
            if (!File.Exists(filename))
                throw new FileNotFoundException("The provided sql script was not found: " + filename, filename);

            sqlPath = System.IO.Path.GetFullPath(filename);

            DbEnabled = false; // Default State
            XlEnabled = false; // Default State
            PpEnabled = false; // Default State

            xlStarted = false;
            ppStarted = false;

            Date = DateTime.Today;
        }

        // Destructor
        ~Script()
        {
            Dispose();
        }

        /// <summary>
        /// Gets or sets the script output stream.
        /// </summary>
        public TextWriter Out { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether database querying is enabled.
        /// </summary>
        public bool DbEnabled { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Microsoft Excel tags are enabled.
        /// </summary>
        public bool XlEnabled { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Microsoft PowerPoint tags are enabled.
        /// </summary>
        public bool PpEnabled { get; set; }

        /// <summary>
        /// gets or sets the [plan] tag value
        /// </summary>
        public string Plan { get; set; }

        /// <summary>
        /// gets or sets the [peer] tag value
        /// </summary>
        public string Peer { get; set; }

        /// <summary>
        /// gets or sets the [folder] tag value
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// gets or sets the [date] tag value
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether script tags is be written to the output log.
        /// </summary>
        public bool LogTags { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether script sql code is written to the output log.
        /// </summary>
        public bool LogCode { get; set; }

        /// <summary>
        /// Gets the path to the last file saved by the script.
        /// </summary>
        public string SaveFile { get; private set; }

        /// <summary>
        /// Gets a value indicating whether any files were saved by the script.
        /// </summary>
        public bool Saved { get; private set; }

        /// <summary>
        /// Gets a value indicating whether [xl] tags can be used. Can start Microsoft Excel
        /// using late-binding if needed.
        /// </summary>
        private bool XlAble
        {
            get
            {
                if (XlEnabled)
                {
                    if (xlOpen)
                    {
                        return true;
                    }
                    else throw new Exception("Error: You must call [xlopen] before using other [xl] tags.");
                }
                else return false;
            }
        }

        // Want this functionality
        // -----------------------
        // [sqlScalar] followed by a SQL statement.  Evaluates to text in the script.  Can be embedded within other tags.         
        // [ppChartSql, slideNumber, chartName, sheetName, rangeName] followed by SQL statement
        // [ppChartAxisMin, slideNumber, chartName, axisMin]
        // [ppChartAxisMax, slideNumber, chartName, axisMax]


        /// <summary>
        /// Gets a value indicating whether [pp] tags can be used. Can start Microsoft PowerPoint
        /// using late binding if needed.
        /// </summary>
        private bool PpAble
        {
            get
            {
                if (PpEnabled)
                {
                    if (ppOpen)
                    {
                        return true;
                    }
                    else throw new Exception("Error: You must call [ppopen] before using other [pp] tags.");
                }
                else return false;
            }
        } 

        /// <summary>
        /// Process a batch of scripts.
        /// </summary>
        /// <param name="sqlFile">The sql file to process.</param>
        /// <param name="batFile">The batch file to process.</param>
        /// <param name="dbInstance">The database connection to use.</param>
        public static void Batch(string sqlFile, string batFile, DbConnection dbInstance)
        {
            string folder = (string)Properties.Scripter.Default["path"];

            int xlOpenLimit = (int)Properties.Scripter.Default["xlOpenLimit"];
            int xlMemoryLimit = (int)Properties.Scripter.Default["xlMemoryLimit"];
            int xlStartDelay = (int)Properties.Scripter.Default["xlStartDelay"];
            int xlTryCount = (int)Properties.Scripter.Default["xlTryCount"];

            int ppOpenLimit = (int)Properties.Scripter.Default["ppOpenLimit"];
            int ppMemoryLimit = (int)Properties.Scripter.Default["ppMemoryLimit"];
            int ppStartDelay = (int)Properties.Scripter.Default["ppStartDelay"];
            int ppTryCount = (int)Properties.Scripter.Default["ppTryCount"];

            // Open the Batch File
            using (StreamReader batReader = new StreamReader(batFile))
            using (var xlInstance = new Office.Excel.Application(xlOpenLimit, xlMemoryLimit, xlTryCount, xlStartDelay))
            using (var ppInstance = new Office.PowerPoint.Application(ppOpenLimit, ppMemoryLimit, xlTryCount, xlStartDelay))

            using (var batchLog = new StreamWriter("scritper.batch.log", true))
            using (var errorLog = new StreamWriter("scripter.error.log", true))
            {
                while (batReader.Peek() != -1)
                {
                    string[] text = batReader.ReadLine().Split('\t');

                    try
                    {
                        string message = string.Format("Processing Date: {0} Plan: {1} Peer: {2}", text[0], text[1], text[2]);

                        Console.WriteLine(message);
                        batchLog.WriteLine(message);
                        batchLog.Flush();

                        using (Script script = new Script(sqlFile, dbInstance, xlInstance, ppInstance))
                        {
                            script.Out = TextWriter.Null;                            
                            script.Plan = text[1];
                            script.Peer = text[2];                            
                            script.Date = DateTime.Parse(text[0]);
                            script.Path = folder;
                            script.Process();
                        }
                    }
                    catch (Exception e)
                    {
                        string message = string.Format("Error with Date: {0} Plan: {1} Peer: {2}", text[0], text[1], text[2]);

                        Console.WriteLine(message);
                        errorLog.WriteLine(message);
                        batchLog.WriteLine(message);

                        Console.WriteLine(e.Message);
                        batchLog.WriteLine(e.Message);

                        Console.WriteLine(e.StackTrace);
                        batchLog.WriteLine(e.StackTrace);

                        batchLog.Flush();
                        errorLog.Flush();
                    }
                }
                Console.WriteLine("Done");
            }

        }

        /// <summary>
        /// Close the script processor and release unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            if (xlBook != null && xlOpen)
            {
                xlBook.Dispose();
                xlBook = null;
                xlOpen = false;
            }
            if (ppDeck != null && ppOpen)
            {
                ppDeck.Dispose();
                ppDeck = null;
                ppOpen = false;
            }
            if (xlInstance != null && xlStarted)
            {
                xlInstance.Dispose();
                xlInstance = null;
            }
            if (ppInstance != null && ppStarted)
            {
                ppInstance.Dispose();
                ppInstance = null;
            }

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Process the script.
        /// </summary>
        public void Process()
        {
            try
            {
                using (StreamReader reader = new StreamReader(File.Open(sqlPath, FileMode.Open, FileAccess.Read, FileShare.Read)))
                {
                    //Console.WriteLine("Starting Script {0}", Path.GetFileName(sqlPath));
                    
                    while (reader.Peek() != -1)
                    {
                        Tag tag = Read(reader);
                        Process(tag, reader);
                    }
                    Out.WriteLine("{0}# End of Script", Environment.NewLine); // Indicate that the script finished processing.
                    //Console.WriteLine("Finished Script {0}", Path.GetFileName(sqlPath));
                }
            }
            catch (DbException exception)
            {
                Out.Write(Environment.NewLine);
                Out.Write(Environment.NewLine);
                Out.WriteLine("A sql error occurred while processing script around line {0}", count);
                Out.WriteLine(exception.Message);
                Out.Write(Environment.NewLine);

                Console.WriteLine("A sql error occured while processing script {0} around line {1}"
                    , System.IO.Path.GetFileName(sqlPath)
                    , count);

                throw exception;
            }
            catch (Exception exception)
            {
                Out.Write(Environment.NewLine);
                Out.Write(Environment.NewLine);
                Out.WriteLine("Error occurred while processing script around line {0}.", count);
                Out.WriteLine(exception.Message);
                Out.Write(Environment.NewLine);

                Console.WriteLine("Error occurred while processing script {0} around line {1}."
                    , System.IO.Path.GetFileName(sqlPath)
                    , count);

                throw exception;
            }
        }

        /// <summary>
        /// Process a tag and update the tag's result property.
        /// </summary>
        /// <param name="tag">The tag to process.</param>
        /// <param name="reader">The TextReader to read trailing tag data from.</param>
        private void Process(Tag tag, TextReader reader)
        {
            if (tag.Keyword == "date")
            {
                /*  Function: GetDate
                 *  This function calculates a date relative to a reference date from a month 
                 *  offset. It returns a string with the specified format.
                 */

                int offset = int.Parse(tag[1].Trim());
                string format = tag[2].Trim().ToLower();

                if (format.Replace("m", string.Empty)
                    .Replace("y", string.Empty)
                    .Replace("d", string.Empty)
                    .Replace("-", string.Empty)
                    .Replace("_", string.Empty)
                    .Replace("/", string.Empty).Length != 0)
                {
                    string message = string.Format("Valid date format charcters are: ('y','m','d','-','_') and they are not case sensitive.", count);
                    throw new Exception(message);
                }
                format = format.Replace("m", "M");

                tag.Value = new DateTime(Date.AddMonths(offset).Year, Date.AddMonths(offset).Month, 1).AddMonths(1).AddDays(-1).ToString(format);
            }
            else if (tag.Keyword == "plan")
            {
                tag.Value = Plan;
            }
            else if (tag.Keyword == "peer")
            {
                tag.Value = Peer;
            }
            else if (tag.Keyword == "path")
            {
                tag.Value = Path;
            }
            else if (tag.Keyword == "ignore")
            {
                return; // Blank Tag
            }
            else if (tag.Keyword == "debug")
            {
                tag.Value = string.Format("Line Count: {0}", count);
            }
            else if (tag.Keyword == "xlopen")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [xlopen,path]");

                if (XlEnabled && xlOpen)
                {
                    xlBook.Dispose();
                    xlOpen = false;
                }

                if (XlEnabled && !xlOpen)
                {
                    // Late Binding
                    if (xlInstance == null)
                    {
                        if (xlStarted == false)
                        {
                            xlInstance = new Scripter.Office.Excel.Application();
                            xlStarted = true;
                        }
                        else throw new NullReferenceException("Microsoft XL Application Not Found");
                    }

                    xlBook = xlInstance.Open(tag[1]);
                    xlOpen = true;
                }
            }
            else if (tag.Keyword == "ppopen")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [ppopen,path]");

                if (PpEnabled && ppOpen)
                {
                    ppDeck.Close();
                    ppOpen = false;
                }

                if (PpEnabled && !ppOpen)
                {
                    // late binding
                    if (ppInstance == null)
                    {
                        if (ppStarted == false)
                        {
                            ppInstance = new Scripter.Office.PowerPoint.Application();
                            ppStarted = true;
                        }
                        else throw new NullReferenceException("Microsoft PP Application Not Found");
                    }

                    ppDeck = ppInstance.Open(tag[1].Trim());
                    ppOpen = true;
                }
            }
            else if (tag.Keyword == "xlsave")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [xlsave,path]");

                if (XlAble)
                {
                    xlBook.Save(tag[1].Trim());

                    Saved = true;
                    SaveFile = tag[1].Trim();
                }
            }
            else if (tag.Keyword == "ppsave")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [ppsave,path]");

                if (PpAble)
                {
                    ppDeck.Save(tag[1].Trim());

                    Saved = true;
                    SaveFile = tag[1].Trim();
                }
            }
            else if (tag.Keyword == "exit")
            {
                // read to the end of the script, which will trigger normal termination of the script
                // the tag will only actually function within control flow statements
                if (XlEnabled)
                {
                    reader.ReadToEnd();
                    Out.Write(Environment.NewLine);
                    Out.WriteLine("## Script Exited with [exit] Tag", Environment.NewLine);
                }
            }
            else if (tag.Keyword == "xlclose")
            {
                if (xlOpen && XlEnabled)
                {
                    xlBook.Dispose();
                    xlOpen = false;
                }
            }
            else if (tag.Keyword == "ppclose")
            {
                if (ppOpen && PpEnabled)
                {
                    ppDeck.Close();
                    ppOpen = false;
                }
            }
            else if(tag.Keyword == "ppmerge")
            {
                if (tag.Count < 3)
                    throw new ArgumentException("Expected: [ppmerge, output.pptx, infile1.pptx, infile2.pptx]");

                if (PpEnabled)
                {
                    // if powerpoint has not arleady started, then start it up with late binding
                    if (ppInstance == null)
                    {
                        if (ppStarted == false)
                        {
                            ppInstance = new Scripter.Office.PowerPoint.Application();
                            ppStarted = true;
                        }
                        else throw new NullReferenceException("Microsoft PP Application Not Found");
                    }

                    // open the first deck
                    if (File.Exists(tag[2].Trim()))
                    {
                        using (Scripter.Office.PowerPoint.Deck ppMerge = ppInstance.Open(tag[2].Trim()))
                        {
                            // open each deck to append
                            for (int i = 3; i < tag.Count; i++)
                            {
                                if (File.Exists(tag[i].Trim()))
                                {
                                    using (Scripter.Office.PowerPoint.Deck ppInput = ppInstance.Open(tag[i].Trim()))
                                    {
                                        // append each slide to the end of the first deck
                                        for (int j = 1; j <= ppInput.Count; j++)
                                            using (Scripter.Office.PowerPoint.Slide ppSlide = ppInput.Slide(j))
                                            {
                                                ppSlide.Copy();
                                                ppMerge.Paste(ppMerge.Count + 1);
                                            }

                                        ppInput.Close();
                                    }
                                }
                            }
                            // save the merged deck to the output.pptx filename
                            ppMerge.Save(tag[1].Trim());
                            ppMerge.Close();
                        }
                    }
                }
                
            }
            else if(tag.Keyword == "script")
            {
                // idea: recursively call another script, like a modularized report
                // all parent options are passed to the child script

                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [script, file.sql]");

                Out.Write(Environment.NewLine);
                using (Script subscript = new Script(tag[1].Trim(), this.dbInstance, this.xlInstance, this.ppInstance))
                {
                    subscript.XlEnabled = this.XlEnabled;
                    subscript.PpEnabled = this.PpEnabled;
                    subscript.Plan = this.Plan;
                    subscript.Date = this.Date;
                    subscript.Path = this.Path;
                    subscript.LogCode = this.LogCode;
                    subscript.LogTags = this.LogTags;
                    subscript.Out = this.Out;
                    subscript.Process();
                }
                Out.Write(Environment.NewLine);
            }

            else if (tag.Keyword == "void")
            {
                // do nothing
            }

            else if (tag.Keyword == "export")
            {
                if (tag.Count < 2 || tag.Count > 4)
                    throw new ArgumentException("Expected: [export, filename]");

                if (this.DbEnabled)
                {
                    //string delimiter = tag.Count >= 3 ? tag[2] : ((char)'\t').ToString();    // Delimit by tab by default.
                    //string enclosure = tag.Count >= 4 ? tag[3] : ((char)'\'').ToString();    // By default, single-quote enclosure.

                    // Step 1: Query the Database
                    using (StreamWriter writer = new StreamWriter(tag[1], false))
                    using (DbCommand command = dbInstance.CreateCommand())
                    {
                        command.CommandText = tag.Sql.TrimEnd().TrimEnd(';');
                        command.CommandTimeout = commandTimeout;

                        string[] text = null;

                        int rows = 0;
                        System.Diagnostics.Stopwatch s = new System.Diagnostics.Stopwatch();
                        s.Start();

                        using (DbDataReader dataReader = command.ExecuteReader())
                        {
                            // Optimiation for Oracle Connections
                            /* ODP prefetches 64k of DATA. And the 64k is based on column size, not data size. 

                                Try adding this to your code to level the playing field:

                                OracleDataReader reader = command.ExecuteReader ();
                                reader.FetchSize =command.RowSize * 100; // add this
                                while (reader.Read ())

                            */
                            if (dbInstance.GetType().ToString().Contains("Oracle"))
                            {
                                Oracle.DataAccess.Client.OracleCommand cmd = (Oracle.DataAccess.Client.OracleCommand)command;
                                Oracle.DataAccess.Client.OracleDataReader rdr = (Oracle.DataAccess.Client.OracleDataReader)dataReader;

                                rdr.FetchSize = cmd.RowSize * 1000;
                            }

                            while (dataReader.Read())
                            {
                                int fields = dataReader.FieldCount;
                                text = new string[fields];

                                for (int i = 0; i < fields; i++)
                                {
                                    if (!dataReader.IsDBNull(i))
                                    {
                                        Type t = dataReader.GetFieldType(i);
                                        if (t.ToString() == "System.DateTime")
                                        {
                                            text[i] = dataReader.GetDateTime(i).ToString("yyyy-MM-dd");
                                        }
                                        else
                                        {
                                            text[i] = dataReader.GetValue(i).ToString();
                                        }
                                    }
                                    else text[i] = "\\N";
                                }
                                writer.WriteLine(string.Format("'{0}'", string.Join("','", text)));
                                rows++;
                            }
                        }

                        s.Stop();
                        Out.WriteLine(System.Environment.NewLine);
                        Out.WriteLine("## Rows Exported: {0}", rows);
                        Out.WriteLine("## Time Elapsed: {0}", s.Elapsed.TotalSeconds);
                    }
                }
            }

            else if (tag.Keyword == "sqlexport")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [sqlexport, filename]");

                if (this.DbEnabled)
                {
                    // Step 1: Query the Database
                    using (StreamWriter writer = new StreamWriter(tag[1], false))
                    using (DbCommand command = dbInstance.CreateCommand())
                    {
                        command.CommandText = tag.Sql.TrimEnd().TrimEnd(';');
                        command.CommandTimeout = commandTimeout;

                        string[] text = null;

                        int rows = 0;
                        System.Diagnostics.Stopwatch s = new System.Diagnostics.Stopwatch();
                        s.Start();

                        using (DbDataReader dataReader = command.ExecuteReader())
                        {
                            // Optimiation for Oracle Connections
                            /* ODP prefetches 64k of DATA. And the 64k is based on column size, not data size. 

                                Try adding this to your code to level the playing field:

                                OracleDataReader reader = command.ExecuteReader ();
                                reader.FetchSize =command.RowSize * 100; // add this
                                while (reader.Read ())

                            */
                            if (dbInstance.GetType().ToString().Contains("Oracle"))
                            {
                                Oracle.DataAccess.Client.OracleCommand cmd = (Oracle.DataAccess.Client.OracleCommand)command;
                                Oracle.DataAccess.Client.OracleDataReader rdr = (Oracle.DataAccess.Client.OracleDataReader)dataReader;

                                rdr.FetchSize = cmd.RowSize * 1000;
                            }

                            while (dataReader.Read())
                            {
                                int fields = dataReader.FieldCount;
                                text = new string[fields];

                                for (int i = 0; i < fields; i++)
                                {
                                    if (!dataReader.IsDBNull(i))
                                    {
                                        Type t = dataReader.GetFieldType(i);
                                        if (t.ToString() == "System.DateTime")
                                        {
                                            text[i] = dataReader.GetDateTime(i).ToString("yyyy-MM-dd");
                                        }
                                        else
                                        {
                                            text[i] = dataReader.GetValue(i).ToString();
                                        }
                                    }
                                    else text[i] = "\\N";
                                }
                                writer.WriteLine(string.Join("\t", text));
                                rows++;
                            }
                        }

                        s.Stop();
                        Out.WriteLine(System.Environment.NewLine);
                        Out.WriteLine("## Rows Exported: {0}", rows);
                        Out.WriteLine("## Time Elapsed: {0}", s.Elapsed.TotalSeconds);
                    }
                }
            }
            else if (tag.Keyword == "xlsql")
            {
                if (tag.Count < 3 || tag.Count > 4)
                    throw new ArgumentException("Expected: [xlsql,sheet,range] or [xlsql,sheet,range,transpose]");

                string sheetName = tag[1].Trim();
                string rangeName = tag[2].Trim();
                bool transpose = false;

                if (tag.Count == 4)
                    transpose = tag[3].ToLower().Contains("transpose");

                if (DbEnabled && XlAble)
                {
                    List<string[]> data = new List<string[]>();
                    string[] text = null;

                    // Step 1: Query the Database
                    using (DbCommand command = dbInstance.CreateCommand())
                    {
                        command.CommandText = tag.Sql.TrimEnd().TrimEnd(';');
                        command.CommandTimeout = commandTimeout;

                        using (DbDataReader dataReader = command.ExecuteReader())
                        {
                            while (dataReader.Read())
                            {
                                text = new string[dataReader.FieldCount];

                                for (int i = 0; i < dataReader.FieldCount; i++)
                                {
                                    if (!dataReader.IsDBNull(i))
                                    {
                                        Type t = dataReader.GetFieldType(i);
                                        if (t.ToString() == "System.DateTime")
                                        {
                                            text[i] = dataReader.GetDateTime(i).ToString("yyyy-MM-dd");
                                        }
                                        else
                                        {
                                            //text[i] = dataReader.GetValue(i).ToString();
                                            text[i] = dataReader.GetString(i);
                                        }
                                    }
                                    else text[i] = "\\N";
                                }
                                data.Add(text);
                            }
                            dataReader.Close();
                        }
                    }

                    // Step 2: Copy to Excel
                    using (Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Range xlRange = xlSheet.Range(rangeName))
                    {
                        // Only Copy/Paste Dataset if Dataset is not empty. (trying to do so will throw a MySqlException)
                        if (data.Count > 0)
                        {
                            if (transpose == false)
                            {
                                string[,] dataArray = new string[data.Count, text.Length];

                                for (int i = 0; i < dataArray.GetLength(0); i++)
                                    for (int j = 0; j < dataArray.GetLength(1); j++)
                                        dataArray[i, j] = data[i][j];

                                using (Range xlRangeResized = xlRange.Resize(data.Count, text.Length))
                                {
                                    xlRangeResized.Value = dataArray;
                                    xlRangeResized.Value = xlRangeResized.Value;
                                }
                            }
                            else
                            {
                                string[,] dataArray = new string[text.Length, data.Count];

                                for (int i = 0; i < dataArray.GetLength(0); i++)
                                    for (int j = 0; j < dataArray.GetLength(1); j++)
                                        dataArray[i, j] = data[j][i];

                                using (Range xlRangeResized = xlRange.Resize(text.Length, data.Count))
                                {
                                    xlRangeResized.Value = dataArray;
                                    xlRangeResized.Value = xlRangeResized.Value;
                                }
                            }
                        }
                        else Out.WriteLine("Warning: Query returned empty result" + Environment.NewLine);
                    }
                }
            }
            else if (tag.Keyword == "ppsql")
            {
                if (tag.Count < 5)
                    throw new ArgumentException("Expected: [ppsql,slide,table,range]");

                bool transpose = false;
                if (tag.Count == 6)
                    if (tag[5].ToLower().Trim() == "transpose")
                        transpose = true;

                if (DbEnabled && PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string name = tag[2].Trim();
                    int rowOffset = int.Parse(tag[3]);
                    int columnOffset = int.Parse(tag[4]);

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.PowerPoint.Table ppTable = ppSlide.Table(name))
                    {
                        if (!transpose)
                        {
                            using (DbReader dbReader = new DbReader(dbInstance, tag.Sql.TrimEnd().TrimEnd(';')))
                                for (int i = 0; i < ppTable.Rows - rowOffset + 1 && reader.Peek() != -1; i++)
                                {
                                    string[] text = dbReader.ReadLine().Split('\t');
                                    for (int j = 0; j < Math.Min(text.Length, ppTable.Columns - columnOffset + 1); j++)
                                    {
                                        string format = ppTable[i + rowOffset, j + columnOffset].Text;
                                        ppTable[i + rowOffset, j + columnOffset].Text = text[j];
                                    }
                                }
                        }
                        else
                        {
                            using (DbReader dbReader = new DbReader(dbInstance, tag.Sql.TrimEnd().TrimEnd(';')))
                                for (int i = 0; i < ppTable.Columns - columnOffset + 1 && reader.Peek() != -1; i++)
                                {
                                    string[] text = dbReader.ReadLine().Split('\t');
                                    for (int j = 0; j < Math.Min(text.Length, ppTable.Rows - rowOffset + 1); j++)
                                    {
                                        ppTable[j + columnOffset, i + rowOffset].Text = text[j];
                                    }
                                }
                        }
                    }
                }
            }
            else if (tag.Keyword == "mysql" || tag.Keyword == "sql")
            {
                if (tag.Count != 1)
                    throw new ArgumentException("Expected: [mysql] or [sql]");

                if (DbEnabled)
                {
                    int rows = 0;
                    System.Diagnostics.Stopwatch time = new System.Diagnostics.Stopwatch();
                    time.Start();

                    using (DbCommand command = dbInstance.CreateCommand())
                    {
                        command.CommandText = tag.Sql.TrimEnd().TrimEnd(';');
                        command.CommandTimeout = commandTimeout;
                        rows = command.ExecuteNonQuery();
                        
                        command.Dispose();
                    }

                    Out.WriteLine(Environment.NewLine);
                    Out.WriteLine("## Rows Affected: {0}", rows);
                    Out.WriteLine("## Time Elapsed: {0}", time.Elapsed.TotalSeconds);
                }
            }

            else if (tag.Keyword == "sqlscalar")
            {
                if (tag.Count != 1)
                    throw new ArgumentException("Expected: [sqlscalar]");

                if (DbEnabled)
                {                    
                    string scalar = string.Empty;

                    using (DbCommand command = dbInstance.CreateCommand())
                    {
                        command.CommandText = tag.Sql.TrimEnd().TrimEnd(';');
                        command.CommandTimeout = commandTimeout;
                        object data = command.ExecuteScalar();

                        if (data is DateTime)
                        {
                            DateTime d = (DateTime)data;
                            tag.Value = d.ToString("yyyy-MM-dd");
                        }
                        if (data == null)
                        {
                            tag.Value = string.Empty;
                        }
                        else tag.Value = data.ToString();

                        command.Dispose();
                    }
                }
            }
            else if (tag.Keyword == "xlchartcopypng")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [xlchartcopypng,sheet,chart,slide,shape]");

                if (XlAble && PpAble)
                {
                    string sheetName = tag[1].Trim();
                    string chartName = tag[2].Trim();
                    string shapeName = tag[4].Trim();
                    int page = int.Parse(tag[3]);

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                        ppSlide.AddChartPNG(shapeName, xlSheet.Chart(chartName));
                }
            }
            else if (tag.Keyword == "xlchartcopyemf")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [xlchartcopy,sheet,chart,slide,shape]");

                if (XlAble && PpAble)
                {
                    string sheetName = tag[1].Trim();
                    string chartName = tag[2].Trim();
                    string shapeName = tag[4].Trim();
                    int page = int.Parse(tag[3]);

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                        ppSlide.AddChartEMF(shapeName, xlSheet.Chart(chartName));
                }
            }
            else if (tag.Keyword == "xlrangecopy")
            {
                if (tag.Count < 5 || tag.Count > 6)
                    throw new ArgumentException("Expected: [xlrangecopy,sheet,range,sheet,range,all|format|value|formula|transpose]");

                if (XlAble)
                {
                    string sourceSheet = tag[1].Trim();
                    string sourceRange = tag[2].Trim();
                    string targetSheet = tag[3].Trim();
                    string targetRange = tag[4].Trim();

                    using (Sheet
                        xlSourceSheet = xlBook.Sheet(sourceSheet),
                        xlTargetSheet = xlBook.Sheet(targetSheet))
                    using (Range
                        xlSourceRange = xlSourceSheet.Range(sourceRange),
                        xlTargetRange = xlTargetSheet.Range(targetRange))
                    {
                        if (tag.Count == 5)
                        {
                            xlSourceRange.Copy(xlTargetRange, true, false, false, false, false);
                        }
                        else
                        {
                            string options = tag[5].ToLower();

                            if (options.Contains("all"))
                            {
                                bool transpose = options.Contains("transpose");
                                xlSourceRange.Copy(xlTargetRange, transpose);
                            }
                            else
                            {
                                bool value = options.Contains("value");
                                bool width = options.Contains("width");
                                bool format = options.Contains("format");
                                bool formula = options.Contains("formula");
                                bool transpose = options.Contains("transpose");

                                xlSourceRange.Copy(xlTargetRange, value, formula, format, width, transpose);
                            }
                        }
                    }
                }
            }
            else if (tag.Keyword == "xlrangeclear")
            {
                if (tag.Count < 3 || tag.Count > 4)
                    throw new ArgumentException("Expected: [xlrangeclear,sheet,range,value|format|all]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Sheet sheet = xlBook.Sheet(sheetName))
                    using (Range range = sheet.Range(rangeName))
                    {
                        if (tag.Count == 3)
                        {
                            // Clear Values Only by Default
                            range.Clear(true, false, false);
                        }
                        else
                        {
                            if (tag[3].Trim().ToLower() == "value")
                                range.Clear(true, false, false);

                            if (tag[3].Trim().ToLower() == "format")
                                range.Clear(false, true, false);

                            if (tag[3].Trim().ToLower() == "all")
                                range.Clear();
                        }
                    }
                }
            }
            else if (tag.Keyword == "xlrangevalue")
            {
                if (tag.Count != 4)
                    throw new ArgumentException("Expected: [xlrangevalue,sheet,range,value]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Value = tag[3];
                }
            }
            else if (tag.Keyword == "xlaxismin")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [xlaxismin,sheet,chart,axis,value]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string chartName = tag[2].Trim();
                    string axis = tag[3].ToUpper().Trim();
                    double value = double.Parse(tag[4].Trim());

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Chart xlChart = xlSheet.Chart(chartName))
                    {
                        if (axis == "X") xlChart.XAxisMin = value;
                        if (axis == "Y") xlChart.YAxisMin = value;
                    }
                }
            }
            else if (tag.Keyword == "xlaxismax")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [xlaxismax,sheet,chart,axis,value]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string chartName = tag[2].Trim();
                    string axis = tag[3].ToUpper().Trim();
                    double value = double.Parse(tag[4].Trim());

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Chart xlChart = xlSheet.Chart(chartName))
                    {
                        if (axis == "X") xlChart.XAxisMax = value;
                        if (axis == "Y") xlChart.YAxisMax = value;
                    }
                }
                throw new NotImplementedException();
            }
            else if (tag.Keyword == "xlaxisunit")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [xlaxisunit,sheet,chart,axis,value]");

                throw new NotImplementedException();
            }
            else if (tag.Keyword == "xlaxisauto")
            {
                if (tag.Count != 6)
                    throw new ArgumentException("Expected: [xlaxisauto,sheet,chart,axis,rangemin,rangemax]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string chartName = tag[2].Trim();
                    string axis = tag[3].ToUpper().Trim();

                    double min;
                    double max;

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    {
                        using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(tag[4].Trim()))
                            min = double.Parse(xlRange.Text);

                        using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(tag[5].Trim()))
                            max = double.Parse(xlRange.Text);

                        using (Scripter.Office.Excel.Chart xlChart = xlSheet.Chart(chartName))
                        {
                            if (axis == "X") xlChart.PrettyXAxis(min, max);
                            if (axis == "Y") xlChart.PrettyYAxis(min, max);
                        }
                    }
                }
            }
            else if (tag.Keyword == "xlreplace")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [xlreplace,sheet,range,find,replace]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Replace(tag[3], tag[4]);
                }
            }
            else if (tag.Keyword == "xlif")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlif,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    bool result = false;
                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        bool.TryParse(xlRange.Text, out result);

                    if (!result)
                    {
                        bool done = false;
                        while (reader.Peek() != -1 && !done)
                        {
                            char cursor = (char)reader.Read();

                            if (cursor == '[')
                            {
                                string keyword = string.Empty;
                                while (reader.Peek() != -1)
                                {
                                    cursor = (char)reader.Read();

                                    if (cursor == ']')
                                    {
                                        if (keyword == "xlendif")
                                        {
                                            done = true;
                                        }
                                        break;
                                    }
                                    else keyword += cursor;
                                }
                            }
                        }
                    }
                }
            }
            else if (tag.Keyword == "xlendif")
            {
                // do nothing.
            }
            else if (tag.Keyword == "ppreplace")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [ppreplace,slide,shape,find,replace]");

                if (PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string shapeName = tag[2].Trim();

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.PowerPoint.Shape ppShape = ppSlide.Shape(shapeName))
                        ppShape.Replace(tag[3], tag[4]);
                }
            }
            else if (tag.Keyword == "ppreplaceall")
            {
                if (tag.Count != 5)
                    throw new ArgumentException("Expected: [ppreplaceall,slide,shape,find,replace]");

                if (PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string shapeName = tag[2].Trim();

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.PowerPoint.Shape ppShape = ppSlide.Shape(shapeName))
                        ppShape.ReplaceAll(tag[3], tag[4]);
                }
            }
            else if (tag.Keyword == "ppdeleteshape")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [ppdeleteshape,slide,shape]");

                if (PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string shapeName = tag[2].Trim();

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.PowerPoint.Shape ppShape = ppSlide.Shape(shapeName))
                        ppShape.Delete();
                }
            }
            else if (tag.Keyword == "ppdeleteslide")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [ppdeleteslide,slide]");

                if (PpAble)
                {
                    int page = int.Parse(tag[1]);
                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                        ppSlide.Delete();
                }
            }
            else if (tag.Keyword == "ppdeleterow")
            {
                if (tag.Count != 4)
                    throw new ArgumentException("Expected: [ppdeleterow,slide,table,rowindex");

                if(PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string tableName = tag[2].Trim();
                    int rowindex = int.Parse(tag[3]);

                    using (Scripter.Office.PowerPoint.Slide ppSlide = ppDeck.Slide(page))
                    using (Scripter.Office.PowerPoint.Table ppTable = ppSlide.Table(tableName))
                        ppTable.DeleteRow(rowindex);
                }
            }

            else if (tag.Keyword == "xlinsertrow")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlinsertrow,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Insert(RangeInsertMethod.InsertRow);
                }
            }
            else if (tag.Keyword == "xlinsertcolumn")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlinsertcolumn,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Insert(RangeInsertMethod.InsertColumn);
                }
            }
            else if (tag.Keyword == "xldeleterow")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xldeleterow,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Delete(RangeDeleteMethod.DeleteRow);
                }
            }
            else if (tag.Keyword == "xldeletecolumn")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xldeletecolumn,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Delete(RangeDeleteMethod.DeleteColumn);
                }
            }
            else if (tag.Keyword == "xlhiderow")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlhiderow,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Hide(true, false);
                }
            }
            else if (tag.Keyword == "xlhidecolumn")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlhidecolumn,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Hide(false, true);
                }
            }
            else if (tag.Keyword == "xlunhiderow")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlshowrow,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Show(true, false);
                }
            }
            else if (tag.Keyword == "xlunhidecolumn")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlshowcolumn,sheet,range]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Scripter.Office.Excel.Range xlRange = xlSheet.Range(rangeName))
                        xlRange.Show(false, true);
                }
            }
            else if (tag.Keyword == "xlhidesheet")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [xlhidesheet,sheet]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                        xlSheet.Hide();
                }
            }
            else if (tag.Keyword == "xlunhidesheet")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected: [xlshowsheet,sheet]");

                if (XlAble)
                {
                    string sheetName = tag[1].Trim();
                    using (Scripter.Office.Excel.Sheet xlSheet = xlBook.Sheet(sheetName))
                        xlSheet.Show();
                }
            }
            else if (tag.Keyword == "xltablecopy")
            {
                if (tag.Count != 7)
                    throw new ArgumentException("Expected [xlcopytable,sheet,range,slide,table,row,column]");

                if (XlAble && PpAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    int page = int.Parse(tag[3]);
                    string tableName = tag[4].Trim();
                    int row = int.Parse(tag[5]);
                    int column = int.Parse(tag[6]);

                    using (Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Range xlRange = xlSheet.Range(rangeName))
                    using (Slide ppSlide = ppDeck.Slide(page))
                    using (Table ppTable = ppSlide.Table(tableName))
                    {
                        for (int i = 0; i < Math.Min(xlRange.Rows, ppTable.Rows - row + 1); i++)
                        {
                            for (int j = 0; j < Math.Min(ppTable.Columns - column + 1, xlRange.Columns); j++)
                            {
                                ppTable[row + i, column + j].Text = xlRange[i, j].Text;
                            }
                        }
                    }
                }
            }

            else if (tag.Keyword == "xlscalar")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected: [xlscalar,sheet,range]");

                if(XlAble)
                {
                    string sheetName = tag[1].Trim();
                    string rangeName = tag[2].Trim();

                    using (Sheet xlSheet = xlBook.Sheet(sheetName))
                    using (Range xlRange = xlSheet.Range(rangeName))
                        tag.Value = xlRange.Text;
                }
            }
            else if (tag.Keyword == "ppcustomformatpas03")
            {
                if (tag.Count != 3)
                    throw new ArgumentException("Expected [pachighlight,slide,table]");

                if (PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string tableName = tag[2].Trim();
                    System.Drawing.Color color = System.Drawing.Color.FromArgb(217, 217, 217);

                    using (Slide ppSlide = ppDeck.Slide(page))
                    using (Table ppTable = ppSlide.Table(tableName))
                    {
                        for (int i = 1; i <= ppTable.Rows; i++)
                        {
                            string text = ppTable[i, 1].Text;
                            if (text == "Domestic Stock" || text == "Foreign Stock" || text == "Bond" || text == "Short-Term" || text == "Other")
                            {
                                for (int j = 1; j <= ppTable.Columns; j++)
                                {
                                    ppTable[i, j].IsBold = true;
                                    ppTable[i, j].FillColor = color;
                                }
                            }
                        }
                    }
                }
            }

            else if (tag.Keyword == "ppformatrows")
            {
                if (tag.Count != 3 && tag.Count != 4)
                    throw new ArgumentException("Expected [ppformatrows,slide,table] or [ppformatrows,slide,table,\"#FFFF99\"]");

                //System.Drawing.Color color = System.Drawing.Color.FromArgb(217, 217, 217);
                System.Drawing.Color color = System.Drawing.ColorTranslator.FromHtml("#FFFF99");
                if (tag.Count == 4)
                {
                    string hexColor = tag[3].Trim().Trim('"');
                    if (hexColor.Length != 7)
                        throw new ArgumentOutOfRangeException("expected hex code of form #0F1A9C");

                    else color = System.Drawing.ColorTranslator.FromHtml(hexColor);
                }

                if (PpAble)
                {
                    int page = int.Parse(tag[1]);
                    string tableName = tag[2].Trim();

                    using (Slide ppSlide = ppDeck.Slide(page))
                    using (Table ppTable = ppSlide.Table(tableName))
                    {
                        for (int i = 1; i <= ppTable.Rows; i++)
                        {
                            string text = ppTable[i, 1].Text;
                            if (text.Contains("%fill%"))
                            {
                                ppTable[i, 1].Text = ppTable[i, 1].Text.Replace("%fill%", "");
                                for (int j = 1; j <= ppTable.Columns; j++)
                                    ppTable[i, j].FillColor = color;
                            }
                            if(text.Contains("%bold%"))
                            {
                                ppTable[i, 1].Text = ppTable[i, 1].Text.Replace("%bold%", "");
                                for (int j = 1; j <= ppTable.Columns; j++)
                                    ppTable[i, j].IsBold = true;
                            }
                        }
                    }
                }
            }

            else if (tag.Keyword == "xltitle")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected [xltitle,\"title\"]");

                if (XlAble)
                    xlBook.Title = tag[1].Trim().Trim('\"');
            }
            else if (tag.Keyword == "xlsubject")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected [xlsubject,\"subject\"]");

                if (XlAble)
                    xlBook.Subject = tag[1].Trim().Trim('\"');
            }
            else if (tag.Keyword == "xlauthor")
            {
                if (tag.Count != 2)
                    throw new ArgumentException("Expected [xlauthor,\"author\"]");

                if (XlAble)
                    xlBook.Author = tag[1].Trim().Trim('\"');
            }
            else if (custom.ContainsKey(tag.Keyword))
            {
                // Custom Keyword Functionality
                if (tag.Count < 1 || tag.Count > 2)
                    throw new ArgumentException("Expected: [keyword] or [keyword,value]");

                if (tag.Count == 1)
                {
                    tag.Value = custom[tag.Keyword];
                }
                if (tag.Count == 2)
                {
                    throw new NotSupportedException("The [keyword,value] tag is disabled");
                }
            }
            else throw new Exception(string.Format("Error: invalid keyword '{0}' at line {1}", tag.Keyword, count));
        }

        /// <summary>
        /// Read the next tag from the stream.
        /// </summary>
        /// <param name="reader">The stream to read.</param>
        private Tag Read(TextReader reader)
        {
            StringBuilder writer = new StringBuilder();

            string head = string.Empty;
            string body = string.Empty;
            string tail = string.Empty; 

            bool inHead = true; 
            bool inBody = false;
            bool inTail = false;

            while (reader.Peek() != -1)
            {
                char cursor = (char)reader.Peek();
                
                if (cursor == '[') 
                {
                    /* Detect Tag Start
                     * ------------------------------------------------------------
                     * This can indicate the start of the current tag, or the start
                     * of a nested tag, depending on whether the cursor is already
                     * located within a tag or a sql statement.
                     */
                                        
                    if (inHead)
                    {
                        // Indicates Start of Current Tag

                        // Convert Writer to Head
                        head = writer.ToString();
                        writer = new StringBuilder();

                        inHead = false;
                        inBody = true;

                        reader.Read();
                        writer.Append(cursor);

                        // Write Tag Head to Log
                        Out.Write(head);
                    }
                    else if (inTail)
                    {
                        // Indicates Nested Tag in Tag Tail
                        Tag nested = Read(reader);

                        Process(nested, reader);
                        writer.Append(nested.Value);
                    }                    
                    else if (inBody)
                    {
                        // Indicates Nested Tag in Tag Body
                        Tag nested = Read(reader);

                        Process(nested, reader);
                        writer.Append(nested.Value);                      
                    }
                    else throw new Exception("Error: Unexpected State in Script.Read");
                }
                else if (cursor == ']')
                {
                    /* Detect Tag Terminator
                     * ------------------------------------------------------------
                     * This indicates the end of the tag body. Determine whether 
                     * the tag is followed by SQL statements. 
                     */

                    // Indicates the end of the tag body.
                    if (inBody)
                    {
                        reader.Read();
                        writer.Append(cursor);
                       
                        // Convert Writer to Body
                        body = writer.ToString();
                        writer = new StringBuilder();

                        Tag tag = new Tag(head, body);

                        // comment out subscripts to avoid double-recursion
                        if (tag.Keyword == "script")
                            Out.Write("## ");

                        // Write Tag Body to Log, but only if tag has a value.
                        if (LogTags && !custom.ContainsKey(tag.Keyword))
                            Out.Write(tag.Body);

                        // Detect SQL Tag
                        if (tag.IsSql)
                        {
                            inBody = false;
                            inTail = true;
                            continue;
                        }
                        else return tag;
                    }
                    else throw new Exception("Unexpected ']' Character");
                }                
                else if (cursor == '#') 
                {
                    // Single Line Comments
                    if (inHead || inTail)
                    {
                        writer.Append(reader.ReadLine() + Environment.NewLine);
                        count++;
                        continue;
                    }
                    else if (inBody)
                    {
                        reader.Read();
                        writer.Append(cursor);
                        continue;
                    }                
                }
                else if (cursor == '\n')
                {
                    reader.Read();
                    writer.AppendLine();

                    count++;
                    continue;
                }
                else if (cursor == '\r')
                {
                    reader.Read();
                    continue;
                }
                else if (cursor == ' ')
                {
                    reader.Read();
                    writer.Append(cursor);
                    continue;
                }
                else if (cursor == '/')
                {
                    /* Block Comments
                     * ------------------------------------------------------------
                     * Search for slash-star. Then consume everything in between 
                     * while ignoring tags and semicolons until star-slash occurs.
                     */

                    reader.Read();
                    writer.Append(cursor);
                    cursor = (char)reader.Peek();

                    if (cursor == '*')
                    {
                        reader.Read();
                        writer.Append(cursor);

                        while (reader.Peek() != -1)
                        {
                            cursor = (char)reader.Peek();

                            if (cursor == '*')
                            {
                                reader.Read();
                                writer.Append(cursor);
                                cursor = (char)reader.Peek();

                                if (cursor == '/')
                                {
                                    reader.Read();
                                    writer.Append(cursor);
                                    break;
                                }
                                else continue;
                            }
                            else if (cursor == '\n')
                            {
                                reader.Read();
                                writer.AppendLine();
                                count++;
                                continue;
                            }
                            else if (cursor == '\r')
                            {
                                reader.Read();
                                continue;
                            }
                            else
                            {
                                reader.Read();
                                writer.Append(cursor);
                                continue;
                            }
                        }
                    }
                    else continue;
                }
                    /*
                else if (cursor == '\\')
                {
                    // Escape Sequences 
                    // \' = Single Quote
                    // \" = Double Quote
                    // \[ = Left Bracket
                    // \] = Right Bracket
                    //

                    reader.Read(); // Consume the Backslash Character
              s  }
            */
                else if (cursor == ';')
                {
                    reader.Read();
                    writer.Append(cursor);

                    // Indicates end of the sql block
                    if (inTail)
                    {
                        // Convert Writer to Tail
                        tail = writer.ToString();
                        writer = new StringBuilder();

                        // Write Tag Tail to Log
                        if (LogCode && body.ToLower() !="[sqlscalar]") Out.Write(tail);

                        return new Tag(head, body, tail);
                    }
                    else continue;
                }
                else if (inHead)
                {
                    throw new Exception("Missing tag or comment");
                }
                else
                {
                    reader.Read();
                    writer.Append(cursor);
                }
            }

            // Check Whether End of Script Makes Sense
            if (inBody)
            {                
                throw new EndOfStreamException(
                    string.Format("Incomplete tag detected; check that each tag is enclosed within square brackets.", count));
            }
            else if (inTail)
            {
                throw new EndOfStreamException(
                    string.Format("Incomplete SQL detected; a complete SQL statement ending with a semicolon is expected.", count));
            }
            else
            {
                head = writer.ToString();
                Out.Write(head);
                return new Tag(head, "[ignore]");
            }
        }
    }

    /// <summary>
    /// Script Command Tag
    /// </summary>
    public sealed class Tag
    {
        private string[] text;  // Tag Arguments in Array Format        

        /// <summary>
        /// Create a new script tag.
        /// </summary>
        /// <param name="body">The tag's body.</param>
        public Tag(string body)
        {
            if (body[0] != '[')
                throw new Exception("Tag body must start with '['");

            if (body[body.Length - 1] != ']')
                throw new Exception("Tag body must end with ']'");

            this.Body = body;
            this.text = body.TrimStart('[').TrimEnd(']').Split(',');
            this.Keyword = text[0].ToLower().Trim();
        }

        /// <summary>
        /// Create a new script tag.
        /// </summary>
        /// <param name="head">The tag's head.</param>
        /// <param name="body">The tag's body.</param>
        public Tag(string head, string body)
            : this(body)
        {
            this.Head = head;
        }

        /// <summary>
        /// Create a new script tag.
        /// </summary>
        /// <param name="head">The tag's head.</param>
        /// <param name="body">The tag's body.</param>
        /// <param name="tail">The tag's tail.</param>
        public Tag(string head, string body, string tail)
            : this(head, body)
        {
            this.Tail = tail;
        }

        /// <summary>
        /// Gets the tag head.
        /// </summary>
        public string Head { get; private set; }

        /// <summary>
        /// Gets the tag body.
        /// </summary>
        public string Body { get; private set; }

        /// <summary>
        /// Gets the tag tail.
        /// </summary>
        public string Tail { get; private set; }
       
        /// <summary>
        /// Gets the tag SQL.
        /// </summary>
        public string Sql
        {
            get { return IsSql ? Tail : string.Empty; }
        }

        /// <summary>
        /// Gets the tag keyword.
        /// </summary>
        public string Keyword { get; private set; }

        /// <summary>
        /// Gets the tag value.
        /// </summary>
        public string Value { get; internal set; }

        /// <summary>
        /// Gets a value indicating whether the tag is a SQL tag.
        /// </summary>
        public bool IsSql
        {
            get { return Keyword.Contains("sql") || Keyword == "export"; }
        }

        /// <summary>
        /// Gets the number of tag arguments, including the keyword.
        /// </summary>
        public int Count
        {
            get { return text.Length; }
        }

        /// <summary>
        /// Tag Argument Indexer
        /// </summary>
        /// <param name="index">The argument index, where zero is always the keyword.</param>
        public string this[int index]
        {
            get
            {
                return text[index];
            }

            private set
            {
                text[index] = value;
            }
        }
    }
}