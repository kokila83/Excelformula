﻿namespace Scripter
{
    using System;
    using System.IO;

    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine(info);
                return;
            }

            string command = args[0].ToLower().Trim();

            if (command == "batch")
            {
                // args[0] = batch
                // args[1] = connection name
                // args[2] = path to sql file 
                // args[3] = path to list of dates, plans, and peers

                string name = args[1].Trim();
                string sqlPath = args[2];
                string tagPath = args[3];

                if (!File.Exists(Path.GetFullPath(sqlPath)))
                    throw new FileNotFoundException("File not found.", sqlPath);

                if (!File.Exists(Path.GetFullPath(tagPath)))
                    throw new FileNotFoundException("File not found.", tagPath);

                using (var connection = Connections.GetConnection(name))
                    Script.Batch(sqlPath, tagPath, connection);
            }

            else if(command == "single")
            {
                // args[0] = single
                // args[1] = connection name
                // args[2] = path to sql file 
                // args[3] = date
                // args[4] = plan
                // args[5] = peer

                string name = args[1].Trim();
                string sqlPath = args[2];
                var date = args.Length > 3 ? DateTime.Parse(args[3]) : DateTime.Now;
                var plan = args.Length > 4 ? args[4].Trim() : string.Empty;
                var peer = args.Length > 5 ? args[5].Trim() : string.Empty;
                string path = (string)Properties.Scripter.Default["path"];

                using (var connection = Connections.GetConnection(name))
                using (Script script = new Script(sqlPath, connection))
                {
                    script.Date = date;
                    script.Plan = plan;
                    script.Peer = peer;
                    script.Path = path;

                    script.DbEnabled = true;
                    script.XlEnabled = true;
                    script.PpEnabled = true;

                    script.LogTags = false;
                    script.LogCode = false;
                    script.Out = TextWriter.Null;

                    Console.WriteLine("Processing Script...");
                    script.Process();
                }                
            }
            else Console.WriteLine(info);
        }

        /// <summary>
        /// appears at the command line when no commands are entered
        /// </summary>
        static string info = @"
Scripter Command Line Options
-----------------------------
Batch Report Mode:
  scriptc batch 'connection' 'script.sql' 'list.txt'
  
   - connection is the name of the connection, created in scriptg.exe
   - script.sql is the path to the sql script 
   - list.txt   is the path to the list of dates, plans, and peers to run
     - list must be tab delimited
     - list must contain the following columns: date, plan, peer

Single Report Mode: 
  scriptc single 'connection' 'script.sql' date plan peer

   - connection is the name of the connection, created in scriptg.exe
   - script.sql is the path to the sql script     

Key Paremeters
   - date must have the format YYYY-MM-DD
   - plan number is generally 5 digits with leading zeroes (e.g., 00123)
   - peer number is generally 3 digits with leading zeroes (e.g., 098)  
";        
    }
}