﻿using System;
using System.Collections.Generic;

namespace Porter
{
    /// <summary>
    /// interface for an item that can be ordered into a sequence
    /// </summary>
    public interface ISequentialItem
    {
        int Id { get; }
    }

    /// <summary>
    /// interface for a list of items ordered into a sequence
    /// </summary>
    /// <typeparam name="T">an item that can be ordered into a sequence</typeparam>
    public interface ISequentialList<T> where T : ISequentialItem
    {
        int MinId { get; }
        int MaxId { get; }
        T this[int id] { get; }
    }

    /// <summary>
    /// an unbroken sequence of items
    /// </summary>
    /// <typeparam name="T">the type of item</typeparam>
    /// <remarks>this class currently supports only unbroken sequences, but it could be modified later to support broken sequences through interpolation</remarks>
    public class SequentialList<T> : ISequentialList<T>, IEnumerable<T> where T : ISequentialItem
    {
        /// <summary>
        /// underlying collection of items, in sequential order
        /// </summary>
        protected T[] data;

        /// <summary>
        /// id of the first item in the sequence
        /// </summary>
        public int MinId { get; private set; }

        /// <summary>
        /// id of the final item in the sequence
        /// </summary>
        public int MaxId { get; private set; }

        /// <summary>
        /// create a new sequential list of items
        /// </summary>
        /// <param name="items">an unordered array of sequence items to add to the list</param>
        public SequentialList(T[] items)
        {
            SortedList<int, T> list = new SortedList<int, T>();
            foreach (T item in items)
                if (!list.ContainsKey(item.Id))
                    list.Add(item.Id, item);
                else throw new Exception("duplicate entry in list of items");

            int minId = list.Keys[0];
            int maxId = list.Keys[list.Keys.Count - 1];

            if (maxId - minId + 1 != list.Count)
                throw new Exception("list contains broken sequence");

            this.MinId = minId;
            this.MaxId = maxId;

            this.data = new T[maxId - minId + 1];
            list.Values.CopyTo(data, 0);
        }        

        /// <summary>
        /// Gets the item with the specified index, or the nearest sequence endpoint if the
        /// specified index is outside the bounds of the sequence
        /// </summary>
        /// <param name="id">the index of the item to retrieve</param>
        public virtual T this[int id]
        {
            get
            {
                if (id < MinId)
                    return data[0];

                if (id > MaxId)
                    return data[data.Length - 1];

                else return data[id - MinId];
            }
        }

        /// <summary>
        /// Gets an enumerator for the items in this list
        /// </summary>
        public IEnumerator<T> GetEnumerator()
        {
            foreach (T item in data)
                yield return item;
        }

        /// <summary>
        /// Gets an enumerator for the items in this list
        /// </summary>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
