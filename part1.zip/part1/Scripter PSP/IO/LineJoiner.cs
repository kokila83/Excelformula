﻿namespace Porter.IO
{
    using System;
    using System.IO;

    /// <summary>
    /// A class for merging together multiple sorted text streams. Includes methods for 
    /// reading and peeking at whole lines.
    /// </summary>
    /// <remarks>Based on natural external merge join.</remarks>
    public class LineJoiner : ILineReader
    {
        /// <summary>
        /// An array of ILineReader streams, ordered by the next line of each stream.
        /// </summary>
        /// <remarks>
        /// The array is filled from the bottom (largest index) to the top (smallest index)
        /// to reduce the number of array copies.
        /// </remarks>
        private ILineReader[] data;

        /// <summary>
        /// The number of open streams.
        /// </summary>
        private int count; 

        /// <summary>
        /// The position of the top stream in the data array.
        /// </summary>
        private int start;

        /// <summary>
        /// Create a new LineJoiner
        /// </summary>
        /// <param name="readers">An array of objects that implement Porter.IO.ILineReader</param>
        public LineJoiner(params ILineReader[] readers)
        {
            // allocate an array to hold the readers
            data = new ILineReader[readers.Length];
            count = 0;
            start = readers.Length;

            // add each reader to the array individually
            foreach (ILineReader reader in readers)
                Insert(reader);
        }

        /// <summary>
        /// Create a new LineJoiner
        /// </summary>
        /// <param name="readers">An array of objects that implement System.IO.TextReader</param>
        public LineJoiner(params TextReader[] readers)
        {
            data = new ILineReader[readers.Length];
            count = 0;
            start = readers.Length;

            foreach (TextReader reader in readers)
                Insert(new LineReader(reader));
        }

        /// <summary>
        /// Compare this instance to another ILineReader based on the next line of text in
        /// each of the underlying streams.
        /// </summary>
        /// <param name="other">Any object that implements ILineReader</param>
        public int CompareTo(ILineReader other)
        {
            return this.PeekLine().CompareTo(other.PeekLine());
        }

        /// <summary>
        /// Release all managed and unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            if (data != null)
            {
                foreach (ILineReader reader in data)
                    if (reader != null)
                        reader.Dispose();

                data = null;
            }

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Return the next ordered line without consuming it from the stream, or return
        /// null if the streams have all been depleted.
        /// </summary>
        public string PeekLine()
        {
            if (count > 0) return data[start].PeekLine();
            else return null;
        }

        /// <summary>
        /// Return the next ordered line from the stream, or return null if all streams
        /// have been depleted.
        /// </summary>
        public string ReadLine()
        {
            if (count > 0)
            {
                // The underlying data array contains a collection of ILineReader streams. 
                // Each stream is assumed to be ordered with the least line at the top and 
                // the greatest line at the bottom. Furthermore, the streams themselves are 
                // ordered within the data array based on the next unconsumed line within
                // each stream.
                // 
                // This method returns null if there are no open streams. Otherwise it always
                // returns the next unconsumed line of the first open stream within the
                // underlying data array.
                //
                string result = data[start].ReadLine();

                // The streams may need to be reordered after consuming a line because the top 
                // stream may no longer be the smallest stream. However, the streams do not 
                // need to be reordered when either of the following conditions are true:
                //
                // (1) The top stream is the only open stream and has not yet been depleted.
                // (2) The top stream is not empty and is (still) not greater than the next
                //     stream in the underlying data array.
                // 
                if (data[start].PeekLine() != null)
                    if (count == 1) return result;
                    else if (data[start].CompareTo(data[start + 1]) <= 0)
                        return result;

                // The top stream is either depleted or not the smallest stream. Quickly 
                // remove it from the top of underlying data array and then insert it into 
                // the proper position within the sorted array.
                count--;
                start++;
                Insert(data[start - 1]);

                // Check whether the next unconsumed line in the top stream post reording is
                // not greater greater than the current result. This is an integrity check 
                // and may eventually be disabled for a small performance gain.
                if (count > 0)
                    if (result.CompareTo(data[start].PeekLine()) > 0)
                        throw new Exception("data are not ordered");

                return result;
            }
            else return null;
        }

        /// <summary>
        /// Insert an ILineReader stream into the underlying data array based on the value 
        /// of the next unconsumed line in that stream. If the stream is empty then it is
        /// disposed instead of inserted.
        /// </summary>
        /// <param name="reader">Any object that implements ILineReader</param>
        private void Insert(ILineReader reader)
        {
            // Check whether the stream is empty. Do not insert an empty stream into the 
            // underlying data array. Dispose of the stream and return execution.
            if (reader.PeekLine() == null)
            {
                reader.Dispose();
                return;
            }

            // Check whether the data array is already full. This is an integrity check and
            // may be eventually be removed for a small performance gain. 
            if (count == data.Length)
                throw new Exception("data array is already full");

            // Use binary search to find the index of any stream in the data array with
            // the same PeekLine() value. A negative index refers to the bitwise complement 
            // of the first larger stream, or the index of the last stream plus one if there
            // are no larger streams.
            int index = Array.BinarySearch<ILineReader>(data, start, count, reader);

            // Apply the bitwise complement operator when index is negative.
            if (index < 0) index = ~index;

            // The underlying data array is filled from bottom to top with the largest
            // stream occupying the largest array index. The smallest stream at the top
            // may may have empty slots above it, but the array size is fixed.
            //
            // Inserting a stream into the array implies one of two possible actions:
            // (1) The new strean is smaller than all other streams in the array, in which
            //     case it is appended to the top of the array. This also happens when the
            //     array is empty.
            // (2) The new stream is not the smallest and must be squeezed between two 
            //     existing streams, or squeezed between the largest stream and the end of
            //     the array. This implies shifting the contents of the array.
            //
            if (index == start)
            {
                start--;
                count++;
                data[start] = reader;
            }
            else if (index > start)
            {
                Array.Copy(data, start, data, start - 1, index - start);
                start--;
                count++;
                data[index - 1] = reader;
            }
            else if (index < start)
                throw new Exception();
        }
    }
}