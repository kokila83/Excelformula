﻿namespace Porter.IO
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// A reader that can read sequential blocks of lines from an underlying sorted text
    /// stream, where each block corresponds to a single participant. The underlying 
    /// stream must be sorted, delimited, and the first two columns must be plan number 
    /// and social security number. 
    /// </summary>
    public sealed class ParticipantLineReader : ILineReader
    {
        private ILineReader reader;
        private char delimiter = '\t';
        private List<string> data = new List<string>(256);

        /// <summary>
        /// The SSN prefix that identifies the majority of FPRS system accounts.
        /// </summary>
        public static readonly string SystemAccountPrefix = "999-99";

        /// <summary>
        /// Create a new participant line reader.
        /// </summary>
        /// <param name="reader">Any object that implements ILineReader</param>
        /// <param name="delimiter">The character that separates columns within a line.</param>
        public ParticipantLineReader(ILineReader reader, char delimiter)
        {
            this.reader = reader;
            this.delimiter = delimiter;
        }

        /// <summary>
        /// Create a new participant line reader.
        /// </summary>
        /// <param name="reader">Any object that implements System.IO.TextReader</param>
        /// <param name="delimiter">The character that separates columns within a line.</param>
        public ParticipantLineReader(System.IO.TextReader reader, char delimiter)
            : this(new LineReader(reader), delimiter) { }

        /// <summary>
        /// Create a new participant line reader. The stream must be tab-delimited.
        /// </summary>
        /// <param name="reader">Any object that implements ILineReader</param>
        public ParticipantLineReader(ILineReader reader)
            : this(reader, '\t') { }

        /// <summary>
        /// Create a new participant line reader. The stream must be tab-delimited.
        /// </summary>
        /// <param name="reader">Any object that implements System.IO.TextReader</param>
        public ParticipantLineReader(System.IO.TextReader reader)
            : this(reader, '\t') { }

        /// <summary>
        /// Release all managed and unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            if (reader != null)
            {
                reader.Dispose();
                reader = null;
            }

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Return the next available line without consuming it from the stream, or return 
        /// null if the stream has been depleted.
        /// </summary>
        public string PeekLine()
        {
            return reader.PeekLine();
        }

        /// <summary>
        /// Return the next available line without consuming it from the stream, or return
        /// null if the stream has been depleted.
        /// </summary>
        /// <param name="pln_n">The plan number associated with the next line.</param>
        /// <param name="ssn_n">The social security number associated with the next line.</param>
        public string PeekLine(out string pln_n, out string ssn_n)
        {
            string line = reader.PeekLine();

            if (line != null)
            {
                //string[] text = line.Split('\t');

                //if (text.Length < 2)
                //    throw new Exception("input line must contain at least two columns");

                //pln_n = text[0].PadRight(05);
                //ssn_n = text[1].PadRight(12);

                // BEGIN NEW CODE
                int p = line.IndexOf(delimiter);
                int s = line.IndexOf(delimiter, p + 1);

                pln_n = line.Substring(0, p).PadRight(05);
                ssn_n = line.Substring(p + 1, s - p - 1).PadRight(12);
                // END NEW CODE

                return line;
            }
            else return pln_n = ssn_n = null;
        }

        /// <summary>
        /// Return the next available line and consume it from the stream, or return
        /// null if the stream has been depleted.
        /// </summary>
        public string ReadLine()
        {
            return reader.ReadLine();
        }

        /// <summary>
        /// Read the next sequence of lines from the underlying stream which correspond
        /// to a single participant. Return the result as an array of strings.
        /// </summary>
        public string[] ReadLines()
        {
            string pln_n, ssn_n;
            return ReadLines(out pln_n, out ssn_n);
        }

        /// <summary>
        /// Skip the next available line.
        /// </summary>
        public void SkipLine()
        {
            if (PeekLine() != null)
                ReadLine();
        }

        /// <summary>
        /// Skip the next sequence of lines from the underlying stream which correspond
        /// to a single participant. 
        /// </summary>
        /// <remarks>
        /// This method consumes significantly less memory than the ReadLines() method 
        /// because it does not store the collection of consumed lines. This will be
        /// particularly useful for skipping over FPRS system accounts: 999-99.  
        /// </remarks>
        public void SkipLines()
        {
            string pln_n = null;
            string ssn_n = null;

            if (PeekLine(out pln_n, out ssn_n) != null)
            {
                string next_pln_n = null;
                string next_ssn_n = null;

                while (PeekLine(out next_pln_n, out next_ssn_n) != null)
                    if (pln_n == next_pln_n && ssn_n == next_ssn_n)
                        ReadLine();
                    
                    else break;
            }
            else return;
        }


        /// <summary>
        /// Read the next sequence of lines from the underlying stream which correspond
        /// to a single participant. Return the result as an array of strings.
        /// </summary>
        /// <param name="pln_n">The plan number associated with the return array.</param>
        /// <param name="ssn_n">The social security number associated with the return array.</param>
        public string[] ReadLines(out string pln_n, out string ssn_n)
        {
            string line; pln_n = null; ssn_n = null;

            // If the stream is empty, then return null. Otherwise read the first line and 
            // parse plan and social security number. These are assumed to be in the first 
            // two columns of each line. Add the first line to the data array.

            if (reader.PeekLine() != null)
            {
                line = reader.PeekLine();
                //text = line.Split(delimiter);

                // if (text.Length < 2) throw new Exception("input line must contain at least two columns");

                //pln_n = text[0].PadRight(05);
                //ssn_n = text[1].PadRight(12);

                // BEGIN NEW CODE
                int p = line.IndexOf(delimiter);
                int s = line.IndexOf(delimiter, p + 1);

                pln_n = line.Substring(0, p).PadRight(05);
                ssn_n = line.Substring(p + 1, s - p - 1).PadRight(12);
                // END NEW CODE

                data.Clear();

                // resize, but only if array is HUGE
                if (data.Capacity > 2048)
                    data.Capacity = 2048;

                data.Add(reader.ReadLine());
            }
            else return null;

            // Peek at the next line to determine whether it contains data for the same 
            // participant. If yes, then append it to the data array accordingly, otherwise
            // stop reading from the stream and return the contents of the data array.
            while (reader.PeekLine() != null)
            {
                line = reader.PeekLine();
                //text = line.Split(delimiter);

                //if (text.Length < 2) throw new Exception("input line must contain at least two columns");

                //string next_pln = text[0].PadRight(05);
                //string next_ssn = text[1].PadRight(12);

                // BEGIN NEW CODE
                // use substrings instead of splitting, reduces memory consumption and overhead
                int p = line.IndexOf(delimiter);
                int s = line.IndexOf(delimiter, p + 1);

                string next_pln = line.Substring(0, p).PadRight(05);
                string next_ssn = line.Substring(p + 1, s - p - 1).PadRight(12);
                // END NEW CODE

                if (pln_n == next_pln && ssn_n == next_ssn)
                    data.Add(reader.ReadLine());

                else break;
            }
            return data.ToArray();
        }

        /// <summary>
        /// Move the position of the reader to the next line with the specified plan number
        /// and social security number.
        /// </summary>
        /// <param name="pln_n">The plan number to seek.</param>
        /// <param name="ssn_n">The social security number to seek.</param>
        /// <returns>True if an exact match is found.</returns>
        public bool Seek(string pln_n, string ssn_n)
        {
            pln_n = pln_n.PadRight(05);
            ssn_n = ssn_n.PadRight(12);

            string curr_pln_n = string.Empty;
            string curr_ssn_n = string.Empty;

            while (PeekLine(out curr_pln_n, out curr_ssn_n) != null)
                if (string.CompareOrdinal(curr_pln_n, pln_n) >= 0)
                    if (string.CompareOrdinal(curr_ssn_n, ssn_n) >= 0)
                        return curr_pln_n == pln_n && curr_ssn_n == ssn_n;
                    else ReadLine();
                else ReadLine();

            return false;
        }

        /// <summary>
        /// Move the position of the reader to the next line with the specified plan number.
        /// </summary>
        /// <param name="pln_n">The plan number to seek.</param>
        /// <returns>True if an exact match is found.</returns>
        public bool Seek(string pln_n)
        {
            pln_n = pln_n.PadRight(05);

            string curr_pln_n = string.Empty;
            string curr_ssn_n = string.Empty;

            while (PeekLine(out curr_pln_n, out curr_ssn_n) != null)
                if (string.CompareOrdinal(curr_pln_n, pln_n) >= 0)
                    return curr_pln_n == pln_n;
                else ReadLine();

            return false;
        }

        /// <summary>
        /// Compare this instance to another ILineReader based on the next line of text in
        /// each of the underlying streams.
        /// </summary>
        /// <param name="other">Any object that implements ILineReader</param>
        public int CompareTo(ILineReader other)
        {
            return this.PeekLine().CompareTo(other.PeekLine());
        }

        /// <summary>
        /// Compare the participant of the next line of text in the underlying stream to another participant.
        /// </summary>
        /// <param name="pln_n">Plan Number</param>
        /// <param name="ssn_n">Social Security Number</param>
        public int CompareTo(string pln_n, string ssn_n)
        {
            string curr_pln_n = string.Empty;
            string curr_ssn_n = string.Empty;

            PeekLine(out curr_pln_n, out curr_ssn_n);
            int result = curr_pln_n.CompareTo(pln_n);
            if (result != 0) return result;
            else return curr_ssn_n.CompareTo(ssn_n);
        }
    }
}