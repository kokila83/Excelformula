﻿namespace Porter.IO
{
    using System;
    using System.IO;

    /// <summary>
    /// An interface that supports reading and peeking lines of text, but that does not
    /// require character by character streaming.
    /// </summary>
    public interface ILineReader : IDisposable, IComparable<ILineReader>
    {
        /// <summary>
        /// Return the next available line without consuming it from the stream, or return
        /// null if the stream has been depleted.
        /// </summary>
        string ReadLine();

        /// <summary>
        /// Return the next available line from the stream, or return null if the stream
        /// has been depleted.
        /// </summary>
        string PeekLine();
    }

    /// <summary>
    /// A class for reading and peeking whole lines.
    /// </summary>
    /// <remarks>
    /// Compared to System.IO.StreamReader, this class incurs negligible performance 
    /// cost regardless of whether the PeekLine() method is called. 
    /// </remarks>
    public class LineReader : ILineReader
    {
        private TextReader reader;
        private string line;
        private bool empty;

        /// <summary>
        /// Create a new LineReader from any object that implements System.IO.TextReader
        /// </summary>
        /// <param name="reader">Any object that implements System.IO.TextReader.</param>
        public LineReader(TextReader reader)
        {
            this.reader = reader;
            line = null;
            empty = true;
        }

        /// <summary>
        /// Compare this instance to another ILineReader based on the next line of text in
        /// each of the underlying streams.
        /// </summary>
        /// <param name="other">Any object that implements ILineReader</param>
        public int CompareTo(ILineReader other)
        {
            return PeekLine().CompareTo(other.PeekLine());
        }

        /// <summary>
        /// Release all managed and unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            if (reader != null)
            {
                reader.Dispose();
                reader = null;
            }

            line = null;
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Return the next available line without consuming it from the stream, or return
        /// null if the stream has been depleted.
        /// </summary>
        public string PeekLine()
        {
            if (empty)
            {
                if (reader.Peek() != -1)
                {
                    line = reader.ReadLine();
                    empty = false;
                    return line;
                }
                else return null;
            }
            else return line;
        }

        /// <summary>
        /// Return the next available line from the stream, or return null if the stream
        /// has been depleted.
        /// </summary>
        public string ReadLine()
        {
            if (empty) return reader.ReadLine();
            else
            {
                empty = true;
                return line;
            }
        }

        /// <summary>
        /// Merge multiple text files together.
        /// </summary>
        /// <param name="target">The target file</param>
        /// <param name="source">The source file</param>
        public static void Merge(string target, params string[] source)
        {
            if (File.Exists(target))
                throw new ArgumentException("target file already exists");

            foreach (string file in source)
                if (File.Exists(file) == false)
                    throw new ArgumentException("source file does not exist: " + file);

            using (StreamWriter writer = new StreamWriter(target))
            {
                Console.WriteLine("Appending Files");
                foreach (string file in source)
                {
                    Console.WriteLine(".. {0}", Path.GetFileName(file));
                    using (StreamReader reader = new StreamReader(file))
                        while (reader.Peek() != -1)
                            writer.WriteLine(reader.ReadLine());
                }
                Console.WriteLine("Done");
            }
        }
    }
}