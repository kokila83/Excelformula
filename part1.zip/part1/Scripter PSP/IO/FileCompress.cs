namespace Porter.IO
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Threading;
    using Porter.Compression.Zip;
    using Porter.Compression.Core;

    /// <summary>
    /// Methods for creating compressed file archives.
    /// </summary>
    public static class FileCompress
    {
        /// <summary>
        /// Add files to a compressed zip archive. If the archive does not exist, it is created. All files are
        /// added to the archive. If a file with the same name already exists in the archive, it is overwritten
        /// without warning. Once all files have been added and the archive has been updated, a high-level test
        /// is performed to test archive integrity.
        /// </summary>
        /// <param name="targetFile">The zip archive to append or create.</param>
        /// <param name="sourceFiles">The file(s) to add to the archive.</param>
        public static void Deflate(string targetFile, params string[] sourceFiles)
        {
            foreach (string filename in sourceFiles)
                if (File.Exists(filename) == false)
                    throw new FileNotFoundException("File not found.", filename);

            ZipFile archive;

            if (File.Exists(targetFile))
            {
                archive = new ZipFile(targetFile);
            }
            else archive = ZipFile.Create(targetFile);

            archive.UseZip64 = UseZip64.On;
            archive.BufferSize = 4194304;
            archive.BeginUpdate();

            foreach (string filename in sourceFiles)
                archive.Add(filename, CompressionMethod.Deflated);

            archive.CommitUpdate();
            bool pass = archive.TestArchive(true);
            archive.Close();

            if (pass)
                foreach (string filename in sourceFiles)
                    File.Delete(filename);

            else throw new IOException("Test of new archive failed.");
        }

        /// <summary>
        /// Unzips a file to a directory. 
        /// </summary>
        /// <param name="sourceFile">the source archive</param>
        /// <param name="targetFolder">the target directory to unzip into</param>
        public static void Inflate(string sourceFile, string targetFolder)
        {
            Inflate(sourceFile, targetFolder, null);
        }

        /// <summary>
        /// Unzips a file to a directory. 
        /// </summary>
        /// <param name="sourceFile">the source archive</param>
        /// <param name="targetFolder">the target directory to unzip into</param>
        /// <param name="password">the zip password</param>
        /// <remarks>
        /// This method was originally written by Matthias Mail�nder
        /// https://github.com/icsharpcode/SharpZipLib/wiki/Zip-Samples
        /// </remarks>
        public static void Inflate(string sourceFile, string targetFolder, string password)
        {        
            ZipFile zipFile = null;
            try
            {
                FileStream fileStream = File.OpenRead(sourceFile);
                zipFile = new ZipFile(fileStream);

                // AES encrypted entries are handled automatically
                if (!String.IsNullOrEmpty(password))
                    zipFile.Password = password;     

                foreach (ZipEntry zipEntry in zipFile)
                {
                    if (!zipEntry.IsFile)
                        continue;           // Ignore directories

                    String entryFileName = zipEntry.Name;
                    // to remove the folder from the entry:- entryFileName = Path.GetFileName(entryFileName);
                    // Optionally match entrynames against a selection list here to skip as desired.
                    // The unpacked length is available in the zipEntry.Size property.

                    byte[] buffer = new byte[1048576];     // 4K is optimum
                    Stream zipStream = zipFile.GetInputStream(zipEntry);

                    // Manipulate the output filename here as desired.
                    String fullZipToPath = Path.Combine(targetFolder, entryFileName);
                    string directoryName = Path.GetDirectoryName(fullZipToPath);
                    if (directoryName.Length > 0)
                        Directory.CreateDirectory(directoryName);

                    // Unzip file in buffered chunks. This is just as fast as unpacking to a buffer the full size
                    // of the file, but does not waste memory.
                    // The "using" will close the stream even if an exception occurs.
                    using (FileStream streamWriter = File.Create(fullZipToPath))
                        StreamUtils.Copy(zipStream, streamWriter, buffer);
                }
            }
            finally
            {
                if (zipFile != null)
                {
                    zipFile.IsStreamOwner = true; // Makes close also shut the underlying stream
                    zipFile.Close(); // Ensure we release resources
                }
            }
        }
    }    
}