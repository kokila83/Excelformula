﻿namespace Porter.IO
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// A class for sorting lines of text, especially large text files. 
    /// </summary>
    /// <remarks>Based on natural external merge sort.</remarks>
    public class LineSorter : ILineReader
    {
        private static int limit = 67108864;
        private static Random random = new Random();
        
        private LineJoiner joiner;
        private List<string> files;
        private List<ILineReader> tiles;

        /// <summary>
        /// Create a new LineSorter
        /// </summary>
        /// <param name="reader">Any object that implements ILineReader</param>
        private LineSorter(ILineReader reader)
        {
            files = new List<string>();
            tiles = new List<ILineReader>();
            string rootname = RandomFilename(12, true);

            while (reader.PeekLine() != null)
            {
                // The input stream is arbitrarily long. The main idea of external merge sort is 
                // to partition the entire stream into manageable subsets that can be individually
                // and efficiently sorted in memory and then later recombined into a contiguous 
                // sorted stream.
                // 
                // Start by reading lines from the stream and appending them to a list in memory 
                // until the number of characters consumed exceeds some constant character limit,
                // or until the stream is depleted.
                // 
                int count = 0;
                List<string> lines = new List<string>();
                while (reader.PeekLine() != null && count < limit)
                {
                    string line = reader.ReadLine();
                    count += line.Length;
                    lines.Add(line);
                }

                // Next sort the list of lines in memory and write the sorted list to a temporary
                // file on disk. The temporary file names consist of a randomly generated root name
                // followed by a four digit sequential serial number. The files will be deleted 
                // automatically when the LineSorter is disposed.
                // 
                string filename = string.Format("{0}{1:0000}", rootname, files.Count);
                files.Add(filename);
                lines.Sort();

                using (StreamWriter writer = new StreamWriter(filename))
                    for (int i = 0; i < lines.Count; i++)
                        writer.WriteLine(lines[i]);

                // Return to the beginning of the loop and continue reading, sorting, and writing 
                // files until the stream is depleted.
            }
            reader.Dispose();

            // By now the stream has been depleted and its contents partitioned into a collection 
            // of text files on disk. Each file contains a sorted list of lines. Recombine these
            // text files into a contiguous, sorted stream using the LineJoiner class.
            //
            foreach (string file in files)
                tiles.Add(new LineReader(new StreamReader(file)));

            joiner = new LineJoiner(tiles.ToArray());
        }

        /// <summary>
        /// Sort a text file.
        /// </summary>
        /// <param name="filename">The text file to sort.</param>
        public static void Sort(string filename)
        {
            // Generate a random output file name.
            string sortfile = RandomFilename(12, true);

            // Create a sorted stream from the input text file.
            using (LineSorter sorter = 
                new LineSorter(
                    new LineReader(
                        new StreamReader(filename))))

            // Write the sorted stream to a new file.
            using (StreamWriter writer = new StreamWriter(sortfile))
                while (sorter.PeekLine() != null)
                    writer.WriteLine(sorter.ReadLine());

            // Test whether the sorted file is actually sorted. This is an integrity test
            // and may eventually be removed for a performance gain.
            if (Test(sortfile) == false)
                throw new Exception("File sorting failed.");
            
            File.Delete(filename);
            File.Move(sortfile, filename);
        }

        /// <summary>
        /// Test whether a text file is sorted.
        /// </summary>
        /// <param name="filename">The text file to test.</param>
        public static bool Test(string filename)
        {
            using (LineReader reader = new LineReader(new StreamReader(filename)))
                return Test(reader);
        }

        /// <summary>
        /// Test whether a text stream is sorted.
        /// </summary>
        /// <param name="reader">The text stream to test.</param>
        public static bool Test(ILineReader reader)
        {
            using (reader)
            {
                while (reader.PeekLine() != null)
                {
                    string thisline = reader.ReadLine();
                    string nextline = reader.PeekLine();

                    if (thisline.CompareTo(nextline) > 0)
                        if (nextline != null)
                            return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Return the next ordered line without consuming it from the stream, or return
        /// null if the streams have all been depleted.
        /// </summary>
        public string PeekLine()
        {
            return joiner.PeekLine();
        }

        /// <summary>
        /// Return the next ordered line from the stream, or return null if all streams
        /// have been depleted.
        /// </summary>
        public string ReadLine()
        {
            return joiner.ReadLine();
        }

        /// <summary>
        /// Release all managed and unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            if (joiner != null)
            {
                joiner.Dispose();
                joiner = null;
            }

            if (tiles != null)
            {
                foreach (ILineReader tile in tiles)
                    if (tile != null)
                        tile.Dispose();

                tiles = null;
            }

            if (files != null)
            {
                foreach (string file in files)
                    if (File.Exists(file))
                        try { File.Delete(file); }
                        catch { Console.WriteLine("Could not delete file {0}", file); }


                files = null;
            }

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Compare this instance to another ILineReader based on the next line of text in
        /// each of the underlying streams.
        /// </summary>
        /// <param name="other">Any object that implements ILineReader</param>
        public int CompareTo(ILineReader other)
        {
            return this.PeekLine().CompareTo(other.PeekLine());
        }

        /// <summary>
        /// Generate a random file name.
        /// </summary>
        /// <param name="length">The number of characters in the file name.</param>
        /// <param name="uppercase">Indicates whether the file name is lower or upper case.</param>
        public static string RandomFilename(int length, bool uppercase)
        {
            string result = string.Empty;
            for (int i = 0; i < length; i++)
                result += Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));

            return uppercase ? result : result.ToLower();
        }
    }
}