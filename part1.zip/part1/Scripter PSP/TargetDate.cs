﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace Porter
{
    /// <summary>
    /// represents a target date
    /// </summary>
    public class TargetDate : IComparable<TargetDate>
    {
        /// <summary>
        /// minimum birth year
        /// </summary>
        public int MinBirthYear { get; protected set; }

        /// <summary>
        /// maximum birth year
        /// </summary>
        public int MaxBirthYear { get; protected set; }

        /// <summary>
        /// target year
        /// </summary>
        public string Target { get; private set; }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="minYear">minimum birth year</param>
        /// <param name="maxYear">maximum birth year</param>
        /// <param name="target">target</param>
        public TargetDate(int minYear, int maxYear, string target)
        {
            int year;
            if (target != "Income")
                if (!int.TryParse(target, out year))
                    throw new ArgumentOutOfRangeException("Target must be an integer year or 'Income'");

            if (minYear > maxYear)
                throw new ArgumentOutOfRangeException("min year must not be greater than max year");

            if (minYear < DateTime.MinValue.Year) minYear = DateTime.MinValue.Year;
            if (maxYear > DateTime.MaxValue.Year) maxYear = DateTime.MaxValue.Year;

            Target = target;
            MinBirthYear = minYear;
            MaxBirthYear = maxYear;
        }

        /// <summary>
        /// compare this instance to another on the basis of MinBirthYear
        /// </summary>
        /// <param name="other">another instance</param>
        public int CompareTo(TargetDate other)
        {
            return MinBirthYear.CompareTo(other.MinBirthYear);
        }
    }

    /// <summary>
    /// a set of target date items
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class TargetDateSet<T> : IEnumerable<T> where T : TargetDate
    {
        /// <summary>
        /// underlying collection of target date items
        /// </summary>
        protected T[] data;

        /// <summary>
        /// indicates whether the target date set is complete; a complete target date set covers the
        /// entire range of possible birth years with no discontinuities or overlaps
        /// </summary>
        public readonly bool IsCompleteSet;

        /// <summary>
        /// number of years between target dates
        /// </summary>
        public readonly int Interval;

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="items">collection of target date items</param>
        public TargetDateSet(T[] items)
        {
            // implicity check for duplicate entries when adding to set
            System.Collections.Generic.SortedSet<T> set
                = new System.Collections.Generic.SortedSet<T>();

            foreach (T item in items)
                set.Add(item);

            // copy set to array
            data = new T[set.Count];
            set.CopyTo(data);

            // check whether the set is complete: a complete target date set covers the 
            // entire range of possible birth years with no discontinuities or overlaps
            if (Count > 0)
            {
                IsCompleteSet = true;

                // set is incomplete if minimum birth year is above minimum possible year
                if (data[0].MinBirthYear != DateTime.MinValue.Year)
                    IsCompleteSet = false;

                // set is incomplete if maximum birth year is below maximum possible year
                if (data[data.Length - 1].MaxBirthYear != DateTime.MaxValue.Year)
                    IsCompleteSet = false;

                // set is incomplete if there are any gaps between adjacent target dates
                for (int i = 1; i < data.Length; i++)
                    if (data[i].MinBirthYear - 1 != data[i - 1].MaxBirthYear)
                        IsCompleteSet = false;
            }

            // estimate interval between target date funds by calculating the distance
            // between consecutive minyears and max year, then selecting the mode
            if (Count > 0)
            {
                var list = new SortedList<int, int>(10);

                // enumerate the intervals
                for (int i = 1; i < Count - 1; i++)
                {
                    int deltaMax = data[i].MaxBirthYear - data[i - 1].MaxBirthYear;
                    if (list.ContainsKey(deltaMax) == false) list.Add(deltaMax, 1);
                    else list[deltaMax]++;

                    int deltaMin = data[i + 1].MinBirthYear - data[i].MinBirthYear;
                    if (list.ContainsKey(deltaMin) == false) list.Add(deltaMin, 1);
                    else list[deltaMin]++;
                }

                // find the (first) mode in the list
                int maxValue = 0; int maxIndex = 0;
                for (int i = 0; i < list.Count; i++)
                {
                    if (list.Values[i] > maxValue)
                    {
                        maxValue = list.Values[i];
                        maxIndex = i;
                    }
                }

                // assume the mode interval is the best interval
                Interval = list.Keys[maxIndex];
            }
        }

        /// <summary>
        /// gets the number of target dates in the set
        /// </summary>
        public int Count
        {
            get
            {
                return data.Length;
            }
        }

        /// <summary>
        /// gets the instance at the specified index
        /// </summary>
        public T this[int index]
        {
            get
            {
                return data[index];
            }
        }

        /// <summary>
        /// gets the target date or nearest target date based on year of birth
        /// </summary>
        /// <param name="birthYear">year of birth</param>
        public T GetNearest(int birthYear)
        {
            if (data.Length == 0)
                throw new Exception("target date set is empty");

            if (birthYear <= data[0].MaxBirthYear)
                return data[0];

            if (birthYear >= data[Count - 1].MinBirthYear)
                return data[Count - 1];


            // case: when dob is between minyob and maxyob
            for (int i = 1; i < Count - 1; i++)                
                if(birthYear >= data[i].MinBirthYear && birthYear <= data[i].MaxBirthYear)
                    return data[i];

            // case: when dob is between target dates because the set is incomplete
            if (IsCompleteSet == false)
                for(int i = 0; i < Count-1; i++)
                    if (birthYear > data[i].MaxBirthYear && birthYear < data[i + 1].MinBirthYear)
                    {
                        int lowerGap = birthYear - (data[i].MaxBirthYear);
                        int upperGap = data[i + 1].MinBirthYear - birthYear;

                        if (lowerGap <= upperGap) return data[i];
                        else return data[i + 1];
                    }
            
            throw new Exception("unhandled case while searching for nearest target date; code must be incomplete");            
        }

        /// <summary>
        /// enumerate through all instances in the collection
        /// </summary>
        public IEnumerator<T> GetEnumerator()
        {
            foreach (T item in data)
                yield return item;            
        }

        /// <summary>
        /// enumerate through all instances in the collection
        /// </summary>
        IEnumerator IEnumerable.GetEnumerator()
        {            
            return data.GetEnumerator();
        }
    }

    public class TargetDateSeries
    {
        /// <summary>
        /// target date series id
        /// </summary>
        public int Id { get; private set; }

        /// <summary>
        /// target date series full name, longer and plural
        /// </summary>
        public string FullName { get; private set; }

        /// <summary>
        /// target date series unit name, shorter and singular
        /// </summary>
        public string UnitName { get; private set; }

        public TargetDateReturnSet Performance { get; private set; }
        public EquityBand Band { get; private set; }

        public TargetDateSeries(int id, string fullName, string unitName, TargetDateReturnSet performance, EquityBand band)
        {
            Id = id;
            FullName = fullName;
            UnitName = unitName;
            Performance = performance;
            Band = band;
        }

        /// <summary>
        /// parse all instances from an xml document
        /// </summary>
        /// <param name="doc">an xml document</param>
        public static TargetDateSeries[] Parse(XmlDocument doc)
        {
            List<TargetDateSeries> data = new List<TargetDateSeries>();
            XmlNodeList list = doc.GetElementsByTagName("TargetDateSeries");
            foreach (XmlNode node in list)
                data.Add(Parse(node));

            return data.ToArray();
        }

        /// <summary>
        /// parse all instances from an xml document
        /// </summary>
        /// <param name="file">the full path of an xml file</param>
        public static TargetDateSeries[] Parse(string file)
        {
            if (!File.Exists(file))
                throw new FileNotFoundException();

            XmlDocument document = new XmlDocument();
            document.Load(file);
            return Parse(document);
        }

        /// <summary>
        /// parse an instance from an xml node
        /// </summary>
        public static TargetDateSeries Parse(XmlNode node)
        {
            // Expected XML Format
            // -------------------------------------------------
            //<TargetDateSeries id="1" name="Fidelity Freedom Funds">   
            //  <TargetDateReturns>
            //    <TargetDateReturn target="Income" minyear="0001" maxyear="1940" date="2016-03-31" cm03m= "0.0160000" cm01y="-0.0045000" an03y="0.0258000" an05y="0.0319000" an10y="0.0372000" sd03y="0.0366000" sd05y="0.0369000" sd10y="0.0481000"/>
            //    ... ...
            //    <TargetDateReturn target="2040"   minyear="1971" maxyear="9999" date="2016-03-31" cm03m="-0.0046000" cm01y="-0.0362000" an03y="0.0615000" an05y="0.0575000" an10y="0.0418000" sd03y="0.1060000" sd05y="0.1183000" sd10y="0.1508000"/>
            //  </TargetDateReturns>
            //  <EquityBand id="1" name="Fidelity">
            //    <EquityBandWidth id=" 21" min="0.8000000" max="0.9500000"/>
            //    ... ... 
            //    <EquityBandWidth id="-17" min="0.1391000" max="0.3391000"/>
            //  </EquityBand>
            //</TargetDateSeries>

            if (node.Name != "TargetDateSeries")
                throw new XmlException("unexpected xml node");

            int id = int.Parse(node.Attributes["id"].Value);
            string fullName = node.Attributes["name"].Value;
            string unitName = node.Attributes["unitName"].Value;

            TargetDateReturnSet p =
                TargetDateReturnSet.Parse(node.SelectSingleNode("TargetDateReturnSet"));

            EquityBand b =
                EquityBand.Parse(node.SelectSingleNode("EquityBand"));

            return new TargetDateSeries(id, fullName, unitName, p, b);
        }
    }

    /// <summary>
    /// A set of target date fund performance data
    /// </summary>
    public class TargetDateReturn : TargetDate
    {
        public readonly RiskReturnSet Performance;

        /// <summary>
        /// Create a new instance
        /// </summary>
        /// <param name="minBirthYear">minimum year of birth</param>
        /// <param name="maxBirthYear">maximum year of birth</param>
        /// <param name="target">target date</param>
        TargetDateReturn(int minBirthYear, int maxBirthYear, string target, RiskReturnSet performance)
            : base(minBirthYear, maxBirthYear, target)
        {
            Performance = performance;
        }

        /// <summary>
        /// parse an instance from an xml node
        /// </summary>
        public static TargetDateReturn Parse(XmlNode node)
        {
            if (node.Name != "TargetDateReturn")
                throw new XmlException("unexpected xml node");

            string target = node.Attributes["target"].Value;
            short minyear = short.Parse(node.Attributes["minyear"].Value);
            short maxyear = short.Parse(node.Attributes["maxyear"].Value);

            DateTime date = DateTime.Parse(node.Attributes["date"].Value);

            string text;
            double? cm03m = null;
            text = node.Attributes["cm03m"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                cm03m = double.Parse(text);

            double? cm01y = null;
            text = node.Attributes["cm01y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                cm01y = double.Parse(text);

            double? an03y = null;
            text = node.Attributes["an03y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                an03y = double.Parse(text);

            double? an05y = null;
            text = node.Attributes["an05y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                an05y = double.Parse(text);

            double? an10y = null;
            text = node.Attributes["an10y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                an10y = double.Parse(text);

            double? sd03y = null;
            text = node.Attributes["sd03y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                sd03y = double.Parse(text);

            double? sd05y = null;
            text = node.Attributes["sd05y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                sd05y = double.Parse(text);

            double? sd10y = null;
            text = node.Attributes["sd10y"].Value;
            if (!string.IsNullOrEmpty(text) && text != "null")
                sd10y = double.Parse(text);

            return new TargetDateReturn(minyear, maxyear, target, new RiskReturnSet(date, cm03m, cm01y, an03y, an05y, an10y, sd03y, sd05y, sd10y));
        }
    }

    /// <summary>
    /// A collection of target date fundss
    /// </summary>
    public class TargetDateReturnSet : TargetDateSet<TargetDateReturn>
    {
        /// <summary>
        /// target date family id
        /// </summary>
        public readonly int Id;

        /// <summary>
        /// target date family name
        /// </summary>
        public readonly string Name;

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="id">target date family id</param>
        /// <param name="name">target date family name</param>
        /// <param name="items">collection of target date fund returns</param>
        public TargetDateReturnSet(int id, string name, TargetDateReturn[] items)
            : base(items)
        {
            Id = id;
            Name = name;
        }

        /// <summary>
        /// parse an instance from an xml node
        /// </summary>
        public static TargetDateReturnSet Parse(XmlNode node)
        {
            // Expected XML Format
            // -------------------------------------------------
            // <TargetDateReturnSet id="0" name="sample">
            //   <TargetDateReturn target="Income" minyear="1900" maxyear="1930" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            //   <TargetDateReturn target="2000"   minyear="1930" maxyear="1935" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            //   <TargetDateReturn target="2005"   minyear="1935" maxyear="1940" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            //   <TargetDateReturn target="2010"   minyear="1940" maxyear="1945" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            //   <TargetDateReturn target="2015"   minyear="1945" maxyear="1950" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            //   <TargetDateReturn target="2020"   minyear="1950" maxyear="1955" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            //   <TargetDateReturn target="2025"   minyear="1955" maxyear="1960" asof="2015-12-31" cm03m="0.0000" cm01y="0.0000" an03y="0.0000" an05y="0.0000" an10y="0.0000" anlof="0.0000"/>
            // </TargetDateReturnSet>

            if (node.Name != "TargetDateReturnSet")
                throw new XmlException("unexpected xml node");

            int id = int.Parse(node.Attributes["id"].Value);
            string name = node.Attributes["name"].Value;

            List<TargetDateReturn> items = new List<TargetDateReturn>();
            foreach (XmlNode item in node.ChildNodes)
                items.Add(TargetDateReturn.Parse(item));

            return new TargetDateReturnSet(id, name, items.ToArray());
        }

        /// <summary>
        /// parse all instances from an xml document
        /// </summary>
        /// <param name="doc">an xml document</param>
        public static TargetDateReturnSet[] Parse(XmlDocument doc)
        {
            List<TargetDateReturnSet> data = new List<TargetDateReturnSet>();
            XmlNodeList list = doc.GetElementsByTagName("TargetDateReturnSet");
            foreach (XmlNode node in list)
                data.Add(Parse(node));

            return data.ToArray();
        }

        /// <summary>
        /// parse all instances from an xml document
        /// </summary>
        /// <param name="file">the full path of an xml file</param>
        public static TargetDateReturnSet[] Parse(string file)
        {
            if (!File.Exists(file))
                throw new FileNotFoundException();

            XmlDocument document = new XmlDocument();
            document.Load(file);
            return Parse(document);
        }
    }

}
