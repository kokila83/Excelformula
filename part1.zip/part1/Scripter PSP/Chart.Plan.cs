namespace Porter.Charts
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    using Porter;
    using PP = Scripter.Office.PowerPoint;
    using XL = Scripter.Office.Excel;

    public sealed class Plan
    {
        /// <summary>
        /// gets the id
        /// </summary>
        public int Id { get; private set; }

        /// <summary>
        /// gets the name
        /// </summary>
        public string Number { get; private set; }

        /// <summary>
        /// gets the date
        /// </summary>
        public DateTime Date { get; private set; }

        /// <summary>
        /// gets the target date series
        /// </summary>
        public readonly TargetDateSeries Series;

        /// <summary>
        /// retirement age assumption
        /// </summary>
        public const int RetirementAge = 65;

        /// <summary>
        /// gets the total return
        /// </summary>
        public ReturnSet Return { get; private set; }

        private bool enableStockSlides;
        private bool enable01ySlides;
        private bool enable03ySlides;
        private bool enable05ySlides;
        private bool enable10ySlides;

        TargetDateTable tdRtnTable01y;
        TargetDateTable tdRtnTable03y;
        TargetDateTable tdRtnTable05y;
        TargetDateTable tdRtnTable10y;

        XYPlot eqAgeAllPlot = new XYPlot(2500);        
        EquityByAgeAllTable eqAgeAllTable = new EquityByAgeAllTable();

        XYPlot eqAgeDiyPlot = new XYPlot(2500);
        EquityByAgeDiyTable eqAgeDiyTable = new EquityByAgeDiyTable();

        XYPlot ttRtnPlot01y = new XYPlot(2500);
        XYPlot ttRtnPlot03y = new XYPlot(2500);
        XYPlot ttRtnPlot05y = new XYPlot(2500);
        XYPlot ttRtnPlot10y = new XYPlot(2500);
        XYPlot ttRskPlot03y = new XYPlot(2500);
        XYPlot ttRskPlot05y = new XYPlot(2500);
        XYPlot ttRskPlot10y = new XYPlot(2500);

        XYPlot csRtnPlot01y = new XYPlot(2500);
        XYPlot csRtnPlot03y = new XYPlot(2500);
        XYPlot csRtnPlot05y = new XYPlot(2500);
        XYPlot csRtnPlot10y = new XYPlot(2500);
        XYPlot csRskPlot03y = new XYPlot(2500);
        XYPlot csRskPlot05y = new XYPlot(2500);
        XYPlot csRskPlot10y = new XYPlot(2500);

        TtRtnByAgeTable ttRtnTable01y = new TtRtnByAgeTable();
        TtRtnByAgeTable ttRtnTable03y = new TtRtnByAgeTable();
        TtRtnByAgeTable ttRtnTable05y = new TtRtnByAgeTable();
        TtRtnByAgeTable ttRtnTable10y = new TtRtnByAgeTable();

        RskRtnByAgeTable ttRskTable03y = new RskRtnByAgeTable();
        RskRtnByAgeTable ttRskTable05y = new RskRtnByAgeTable();
        RskRtnByAgeTable ttRskTable10y = new RskRtnByAgeTable();
        RskRtnByAgeTable csRskTable03y = new RskRtnByAgeTable();
        RskRtnByAgeTable csRskTable05y = new RskRtnByAgeTable();
        RskRtnByAgeTable csRskTable10y = new RskRtnByAgeTable();

        CsReturnByAgeTable csRtnTable01y = new CsReturnByAgeTable();
        CsReturnByAgeTable csRtnTable03y = new CsReturnByAgeTable();
        CsReturnByAgeTable csRtnTable05y = new CsReturnByAgeTable();
        CsReturnByAgeTable csRtnTable10y = new CsReturnByAgeTable();

        XYPlotImage ttRtnImage01y = new XYPlotImage();
        XYPlotImage ttRtnImage03y = new XYPlotImage();
        XYPlotImage ttRtnImage05y = new XYPlotImage();
        XYPlotImage ttRtnImage10y = new XYPlotImage();
        XYPlotImage csRtnImage01y = new XYPlotImage();
        XYPlotImage csRtnImage03y = new XYPlotImage();
        XYPlotImage csRtnImage05y = new XYPlotImage();
        XYPlotImage csRtnImage10y = new XYPlotImage();

        XYPlotImage ttRskImage03y = new XYPlotImage();
        XYPlotImage ttRskImage05y = new XYPlotImage();
        XYPlotImage ttRskImage10y = new XYPlotImage();
        XYPlotImage csRskImage03y = new XYPlotImage();
        XYPlotImage csRskImage05y = new XYPlotImage();
        XYPlotImage csRskImage10y = new XYPlotImage();
        XYPlotImage eqAgeAllImage = new XYPlotImage();
        XYPlotImage eqAgeDiyImage = new XYPlotImage();

        bool isAdvisor = false;
        string eReviewPrrAgeRetail = (string)Properties.Chart.Default["eReviewPrrAgeRetail"];
        string eReviewPrrAgeAdvisor = (string)Properties.Chart.Default["eReviewPrrAgeAdvisor"];
        string eReviewRiskReturnRetail = (string)Properties.Chart.Default["eReviewRiskReturnRetail"];
        string eReviewRiskReturnAdvisor = (string)Properties.Chart.Default["eReviewRiskReturnAdvisor"];
        string eReviewPercentEquity = (string)Properties.Chart.Default["eReviewPercentEquity"];

        /// <summary>
        /// minimum number of participants required to generate content
        /// </summary>
        private const int participantMinimum = 100;

        /// <summary>
        /// maximum number of participants in scatter plot
        /// </summary>
        private const int participantMaximum = 5000;

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="id">id</param>
        /// <param name="number">plan number</param>
        /// <param name="date">date</param>
        /// <param name="series">target date series</param>
        /// <param name="ttReturn">plan return</param>
        public Plan(string number, DateTime date, TargetDateSeries series, ReturnSet ttReturn)
        {
            Number = number;
            Date = date;
            Series = series;
            Return = ttReturn;

            List<TargetDateTableRow> set01y = new List<TargetDateTableRow>();
            List<TargetDateTableRow> set03y = new List<TargetDateTableRow>();
            List<TargetDateTableRow> set05y = new List<TargetDateTableRow>();
            List<TargetDateTableRow> set10y = new List<TargetDateTableRow>();

            if (Series.Id == 11 || Series.Id == 12 || Series.Id == 13 || Series.Id == 14)
                isAdvisor = true;

            //if (series.Performance.IsCompleteSet == false)
            //    throw new Exception("not quite ready to support incomplete target date sets");

            // build target data return sets
            foreach (TargetDateReturn item in Series.Performance)
            {
                RiskReturnSet tdReturn = item.Performance;

                if (tdReturn.Cm01y.HasValue)
                    set01y.Add(new TargetDateTableRow(item.MinBirthYear, item.MaxBirthYear, item.Target, tdReturn.Date, tdReturn.Cm01y.Value, double.NaN));

                if (tdReturn.An03y.HasValue)
                    set03y.Add(new TargetDateTableRow(item.MinBirthYear, item.MaxBirthYear, item.Target, tdReturn.Date, tdReturn.An03y.Value, tdReturn.Sd03y.Value));

                if (tdReturn.An05y.HasValue)
                    set05y.Add(new TargetDateTableRow(item.MinBirthYear, item.MaxBirthYear, item.Target, tdReturn.Date, tdReturn.An05y.Value, tdReturn.Sd05y.Value));

                if (tdReturn.An10y.HasValue)
                    set10y.Add(new TargetDateTableRow(item.MinBirthYear, item.MaxBirthYear, item.Target, tdReturn.Date, tdReturn.An10y.Value, tdReturn.Sd10y.Value));
            }            

            tdRtnTable01y = new TargetDateTable(set01y.ToArray());
            tdRtnTable03y = new TargetDateTable(set03y.ToArray());
            tdRtnTable05y = new TargetDateTable(set05y.ToArray());
            tdRtnTable10y = new TargetDateTable(set10y.ToArray());                             
        }

        private class XYPlotImage
        {
            public string FileName { get; set; }
            public double PointHeight { get; set; }
            public double PointWidth { get; set; }

            ~XYPlotImage()
            {
                try
                {
                    if (File.Exists(FileName))
                        File.Delete(FileName);
                }
                catch { }
            }

        }

        private class TargetDateTable : TargetDateSet<TargetDateTableRow>
        {
            public TargetDateTable(TargetDateTableRow[] items)
                : base(items)
            { }

            public double[,] ToTargetRskRtnArray()
            {
                double[,] data = new double[Count, 3];
                for (int i = 0; i < Count; i++)
                {
                    TargetDateTableRow item = this[i];
                    int target = 0;
                    int.TryParse(item.Target, out target);

                    data[i, 0] = target;
                    data[i, 1] = item.Rsk;
                    data[i, 2] = item.Rtn;
                }
                return data;
            }

            public double[,] ToTargetAgeRtnArray()
            {
                double[,] data = new double[Count, 3];
                for (int i = 0; i < Count; i++)
                {
                    TargetDateTableRow item = this[i];
                    int target = 0;
                    int.TryParse(item.Target, out target);

                    // determine center ages
                    double age = 0;
                    int dayOffset = (int)(Interval * 365.2425 / 2);                    
                    if ( i == 0 )
                    {
                        DateTime ctrDate = new DateTime(item.MaxBirthYear, 12, 31).AddDays(-dayOffset);
                        age = ((DateTime)item.Date - ctrDate).TotalDays / 365.2425;
                    }   
                    else
                    {
                        DateTime ctrDate = new DateTime(item.MinBirthYear, 01, 01).AddDays(+dayOffset);
                        age = ((DateTime)item.Date - ctrDate).TotalDays / 365.2425;
                    }       

                    data[i, 0] = target;
                    data[i, 1] = age;
                    data[i, 2] = item.Rtn;
                }
                return data;
            }
        }

        /// <summary>
        /// target date risk, return, and center age
        /// used exclusively in scatter plot program
        /// </summary>
        private class TargetDateTableRow : TargetDate
        {
            /// <summary>
            /// Period-End Date
            /// </summary>
            public Date Date { get; private set; }

            /// <summary>
            /// Return
            /// </summary>
            public double Rtn { get; private set; }

            /// <summary>
            /// Risk
            /// </summary>
            public double Rsk { get; private set; }

            /// <summary>
            /// create a new instance
            /// </summary>
            /// <param name="minYear">minimum birth year</param>
            /// <param name="maxYear">maximum birth year</param>
            /// <param name="target">target</param>
            public TargetDateTableRow(int minYear, int maxYear, string target, Date date, double rtn, double rsk)
                : base(minYear, maxYear, target)
            {
                Date = date;
                Rtn = rtn;
                Rsk = rsk;
            }
        }

        private abstract class ByAgeTable
        {
            /// <summary>
            /// maximum number of cohorts
            /// </summary>
            protected static int n = 7;
            protected static int precision = 3;
            protected static int ToAgeId(double age)
            {
                return (int)Math.Min(6, Math.Max(0, Math.Floor(((age + 5) - 20) / 10)));
            }

            public abstract double[,] ToArray();
        }

        private class TtRtnByAgeTable : ByAgeTable
        {
            int[] total;
            int[] undernum;
            int[] underden;

            List<double>[] returns;

            public TtRtnByAgeTable()
            {
                total = new int[n + 1];
                undernum = new int[n + 1];
                underden = new int[n + 1];
                returns = new List<double>[n + 1];
                for (int i = 0; i < returns.Length; i++)
                    returns[i] = new List<double>();
            }

            public void Add(double age, double rtn, double? bmk)
            {
                int i = ToAgeId(age);

                total[n]++;
                total[i]++;

                returns[n].Add(rtn);
                returns[i].Add(rtn);

                if(bmk.HasValue)
                {
                    underden[n]++;
                    underden[i]++;

                    if (Math.Round(rtn, precision, MidpointRounding.AwayFromZero) < Math.Round(bmk.Value, precision, MidpointRounding.AwayFromZero))
                    {
                        undernum[n]++;
                        undernum[i]++;
                    }
                }
            }

            public override double[,] ToArray()
            {
                double[,] data = new double[3, n + 1];
                for (int i = 0; i < n + 1; i++)
                {
                    // compute distribution by age
                    data[0, i] = (double)total[i] / (double)total[n];

                    // compute median return
                    double median = Statistics.Median(returns[i].ToArray());                    
                    data[1, i] = median;

                    // compute portion underperforming
                    data[2, i] = (double)undernum[i] / (double)underden[i];
                }

                return data;
            }
        }

        private class CsReturnByAgeTable : ByAgeTable
        {
            int[] total;
            List<double>[] ttRtns;
            List<double>[] csRtns;

            public CsReturnByAgeTable()
            {
                total = new int[n + 1];
                ttRtns = new List<double>[n + 1];
                csRtns = new List<double>[n + 1];

                for (int i = 0; i < n + 1; i++)
                {
                    ttRtns[i] = new List<double>();
                    csRtns[i] = new List<double>();
                }
            }

            public void Add(double age, double ttRtn, double csRtn)
            {
                int i = ToAgeId(age);

                total[n]++; ttRtns[n].Add(ttRtn); csRtns[n].Add(csRtn);
                total[i]++; ttRtns[i].Add(ttRtn); csRtns[i].Add(csRtn);
            }

            public override double[,] ToArray()
            {
                double[,] data = new double[3, n + 1];
                for (int i = 0; i < data.GetLength(1); i++)
                {
                    // compute distribution by age
                    data[0, i] = (double)total[i] / (double)total[n];

                    // compute median returns
                    data[1, i] = Statistics.Median(ttRtns[i].ToArray());
                    data[2, i] = Statistics.Median(csRtns[i].ToArray());
                }

                return data;
            }
        }

        private class EquityByAgeDiyTable : ByAgeTable
        {
            int[] total;
            int[] at0;
            int[] at1;
            int[] inOuterBand;
            int[] inInnerBand;
            int[] outsideBand;

            public EquityByAgeDiyTable() : base()
            {
                total = new int[n + 1];
                at0 = new int[n + 1];
                at1 = new int[n + 1];
                inOuterBand = new int[n + 1];
                inInnerBand = new int[n + 1];
                outsideBand = new int[n + 1];
            }

            public string ToStringOverall()
            {
                return string.Format("{0},{1},{2},{3},{4},{5}", total[n], at0[n], at1[n], inOuterBand[n], inInnerBand[n], outsideBand[n]);
            }

            public void Add(double age, double equity, double innerBandMin, double innerBandMax, double outerBandMin, double outerBandMax)
            {
                int i = ToAgeId(age);

                total[n]++;
                total[i]++;

                if (equity == 0.0d)
                {
                    at0[n]++;
                    at0[i]++;
                }
                if (equity == 1.0d)
                {
                    at1[n]++;
                    at1[i]++;
                }

    if (equity >= innerBandMin && equity <= innerBandMax)
    {
        inInnerBand[n]++;
        inInnerBand[i]++;
    }
    else if (equity >=outerBandMin && equity <=outerBandMax)
    {
        inOuterBand[n]++;
        inOuterBand[i]++;
    }
    else
    {
        outsideBand[n]++;
        outsideBand[i]++;
    }
            }

            public override double[,] ToArray()
            {
                // age, band, 0, 1
                double[,] data = new double[6, n + 1];
                for (int i = 0; i < data.GetLength(1); i++)
                {
                    data[0, i] = (double)total[i] / (double)total[n];
                    data[1, i] = (double)inInnerBand[i] / (double)total[i];
                    data[2, i] = (double)inOuterBand[i] / (double)total[i];
                    data[3, i] = (double)outsideBand[i] / (double)total[i];
                    data[4, i] = (double)at0[i] / (double)total[i];
                    data[5, i] = (double)at1[i] / (double)total[i];
                }

                return data;
            }
        }

        private sealed class EquityByAgeAllTable : ByAgeTable
        {
            int[] total;
            int[] at0;
            int[] at1;
            int[] inBand;

            public EquityByAgeAllTable()
            {
                total = new int[n + 1];
                at0 = new int[n + 1];
                at1 = new int[n + 1];
                inBand = new int[n + 1];
            }

            public void Add(double age, double equity, double bandMin, double bandMax)
            {
                int i = ToAgeId(age);

                total[n]++;
                total[i]++;

                if (equity == 0.0d)
                {
                    at0[n]++;
                    at0[i]++;
                }
                if (equity == 1.0d)
                {
                    at1[n]++;
                    at1[i]++;
                }
                if (equity >= bandMin && equity <= bandMax)
                {
                    inBand[n]++;
                    inBand[i]++;
                }
            }

            public override double[,] ToArray()
            {
                // age, band, 0, 1
                double[,] data = new double[4, n + 1];
                for (int i = 0; i < data.GetLength(1); i++)
                {
                    data[0, i] = (double)total[i] / (double)total[n];
                    data[1, i] = (double)inBand[i] / (double)total[i];
                    data[2, i] = (double)at0[i] / (double)total[i];
                    data[3, i] = (double)at1[i] / (double)total[i];
                }

                return data;
            }
        }

        private class RskRtnByAgeTable : ByAgeTable
        {
            int[] total;
            int[] denom;
            int[] moreRiskMoreReturn;
            int[] moreRiskLessReturn;
            int[] lessRiskMoreReturn;
            int[] lessRiskLessReturn;

            public RskRtnByAgeTable()
            {
                total = new int[n + 1];
                denom = new int[n + 1];
                moreRiskMoreReturn = new int[n + 1];
                moreRiskLessReturn = new int[n + 1];
                lessRiskMoreReturn = new int[n + 1];
                lessRiskLessReturn = new int[n + 1];
            }

            public void Add(double age, double paRtn, double paRsk, double? bmRtn, double? bmRsk)
            {
                int i = ToAgeId(age);

                total[i]++;
                total[n]++;

                if(bmRtn.HasValue && bmRsk.HasValue)
                {
                    denom[i]++;
                    denom[n]++;

                    paRtn = Math.Round(paRtn, precision, MidpointRounding.AwayFromZero);
                    paRsk = Math.Round(paRsk, precision, MidpointRounding.AwayFromZero);
                    bmRtn = Math.Round(bmRtn.Value, precision, MidpointRounding.AwayFromZero);
                    bmRsk = Math.Round(bmRsk.Value, precision, MidpointRounding.AwayFromZero);

                    if (paRtn < bmRtn.Value)
                    {
                        if (paRsk > bmRsk.Value)
                        {
                            moreRiskLessReturn[i]++;
                            moreRiskLessReturn[n]++;
                        }
                        else
                        {
                            lessRiskLessReturn[i]++;
                            lessRiskLessReturn[n]++;
                        }
                    }
                    else
                    {
                        if (paRsk > bmRsk.Value)
                        {
                            moreRiskMoreReturn[i]++;
                            moreRiskMoreReturn[n]++;
                        }
                        else
                        {
                            lessRiskMoreReturn[i]++;
                            lessRiskMoreReturn[n]++;
                        }
                    }
                }

                return;
            }

            public override double[,] ToArray()
            {
                double[,] data = new double[4, n + 1];
                for (int i = 0; i < n + 1; i++)
                {
                    // compute distribution by age
                    data[0, i] = (double)lessRiskMoreReturn[i] / (double)denom[i];
                    data[1, i] = (double)lessRiskLessReturn[i] / (double)denom[i];
                    data[2, i] = (double)moreRiskMoreReturn[i] / (double)denom[i];
                    data[3, i] = (double)moreRiskLessReturn[i] / (double)denom[i];
                }

                return data;
            }
        }

        /// <summary>
        /// parse specific elements from the line
        /// </summary>
        /// <param name="line">line of text to parse</param>
        /// <param name="number">id</param>
        /// <param name="date">date</param>
        /// <param name="seriesId">series id</param>
        public static void PartialParse(string line, out string number, out DateTime date, out int seriesId)
        {
            string[] text = line.Split('\t');
            number = text[0];
            date = DateTime.Parse(text[1]);
            seriesId = int.Parse(text[2]);
            return;
        }

        /// <summary>
        /// parse specific elements from the line
        /// </summary>
        /// <param name="line">line of text to parse</param>
        /// <param name="planNumber">id</param>
        /// <param name="date">date</param>
        public static void Parse(string line, out string planNumber, out DateTime date)
        {
            int dummy;
            PartialParse(line, out planNumber, out date, out dummy);
        }

        ///// <summary>
        ///// parse specific elements from the line
        ///// </summary>
        ///// <param name="line">line of text to parse</param>
        ///// <param name="planNumber">id</param>
        //public static void PartialParse(string line, out string planNumber)
        //{
        //    DateTime dummy;
        //    Parse(line, out planNumber, out dummy);
        //}

        /// <summary>
        /// parse specific elements from the line
        /// </summary>
        /// <param name="line">line of text to parse</param>
        /// <param name="id">date</param>
        public static void PartialParse(string line, out DateTime date)
        {
            Parse(line, out string dummy, out date);
        }

        /// <summary>
        /// parse a new instance from a text array
        /// </summary>
        public static Plan Parse(string[] text, TargetDateSeries series)
        {
            /* Expected Layout
             * ----------------------------------------
             * [00] Plan Number
             * [01] Date
             * [02] TargetDateSeriesId
             * [03] Enable Company Stock Slides
             * [04] Enable 01-Year Slides
             * [05] Enable 03-Year Slides
             * [06] Enable 05-Year Slides
             * [07] Enable 10-Year Slides
             * [08] 01-Year Cumulative Return
             * [09] 03-Year Average Annual Return
             * [10] 05-Year Average Annual Return
             * [11] 10-Year Average Annual Return
             */

            string number = text[00];
            DateTime date = DateTime.Parse(text[01]);

            double? cm01y = ToNullableDouble(text[08]);
            double? an03y = ToNullableDouble(text[09]);
            double? an05y = ToNullableDouble(text[10]);
            double? an10y = ToNullableDouble(text[11]);
            ReturnSet ttReturn = new ReturnSet(date, 0.0d, cm01y, an03y, an05y, an10y);

            Plan plan = new Plan(number, date, series, ttReturn);

            plan.enableStockSlides = bool.Parse(text[03]);
            plan.enable01ySlides = bool.Parse(text[04]);
            plan.enable03ySlides = bool.Parse(text[05]);
            plan.enable05ySlides = bool.Parse(text[06]);
            plan.enable10ySlides = bool.Parse(text[07]);

            return plan;
        }

        private static double? ToNullableDouble(string s)
        {
            double d;
            if (double.TryParse(s, out d)) return d;
            return null;
        }

        private void buildSlideEqAgeAll(PP.Deck ppDeck, EquityByAgeAllTable eqAgeTable, XYPlotImage image, int slideNumber)
        {
            using (PP.Slide ppSlide = ppDeck.Slide(slideNumber))
            {
                using (PP.Shape ppShape = ppSlide.Shape("Chart"))
                {
                    ppSlide.AddImage(image.FileName, ppShape.Left, ppShape.Top, (float)image.PointWidth, (float)image.PointHeight);
                    ppShape.Delete();
                }
                using (PP.Shape ppShape = ppSlide.Shape("Subtitle"))
                {
                    ppShape.Replace("%PLAN%", Number);
                    ppShape.Replace("%DATE%", Date.ToString("MM/dd/yyyy"));
                }
                using (PP.Shape ppShape = ppSlide.Shape("Disclosure"))
                    ppShape.Replace("<ereviewnumber>", eReviewPercentEquity);

                using (PP.Table ppTable = ppSlide.Table("Table"))
                {
                    double[,] data = eqAgeTable.ToArray();
                    for (int i = 0; i < 6; i++)
                    {
                        int j = i + 2;
                        int k = i < 5 ? i + 1 : 7;

                        using (PP.Shape ppShape = ppTable[2, j]) ppShape.Text = data[0, k].ToString("0%");
                        using (PP.Shape ppShape = ppTable[3, j]) ppShape.Text = data[1, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[4, j]) ppShape.Text = data[2, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[5, j]) ppShape.Text = data[3, k].ToString("0%").Replace("NaN", "N/A");
                    }
                }
            }
        }

        private void buildSlideEqAgeDiy(PP.Deck ppDeck, EquityByAgeDiyTable eqAgeTable, XYPlotImage image, int slideNumber)
        {
            using (PP.Slide ppSlide = ppDeck.Slide(slideNumber))
            {
                using (PP.Shape ppShape = ppSlide.Shape("Chart"))
                {
                    ppSlide.AddImage(image.FileName, ppShape.Left, ppShape.Top, (float)image.PointWidth, (float)image.PointHeight);
                    ppShape.Delete();
                }
                using (PP.Shape ppShape = ppSlide.Shape("Subtitle"))
                {
                    ppShape.Replace("%PLAN%", Number);
                    ppShape.Replace("%DATE%", Date.ToString("MM/dd/yyyy"));                    
                }
                using (PP.Shape ppShape = ppSlide.Shape("Disclosure"))
                    ppShape.Replace("<ereviewnumber>", eReviewPercentEquity);

                using (PP.Table ppTable = ppSlide.Table("Table"))
                {
                    double[,] data = eqAgeTable.ToArray();
                    for (int i = 0; i < 6; i++)
                    {
                        int j = i + 2;
                        int k = i < 5 ? i + 1 : 7;

                        using (PP.Shape ppShape = ppTable[2, j]) ppShape.Text = data[0, k].ToString("0%");
                        using (PP.Shape ppShape = ppTable[3, j]) ppShape.Text = data[1, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[4, j]) ppShape.Text = data[2, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[5, j]) ppShape.Text = data[3, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[6, j]) ppShape.Text = data[4, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[7, j]) ppShape.Text = data[5, k].ToString("0%").Replace("NaN", "N/A");
                    }

                    // conditional formatting of the overall percentage of participants outside the 25% 
                    // equity band, requested by Karen Korn.  When the rounded percentage is less than
                    // 50% of participants, then the cell is shaded green, otherwise it is shaded red.
                    using (PP.Shape ppShape = ppTable[5, 7])
                    {
                        if (Math.Round(data[3, 7], 2) < 0.50)
                            ppShape.FillColor = System.Drawing.Color.FromArgb(153, 202, 155);

                        if (Math.Round(data[3, 7], 2) >= 0.50)
                            ppShape.FillColor = System.Drawing.Color.FromArgb(127, 132, 218);
                    }
                }
            }
        }

        private void buildSlideTtRtn(PP.Deck ppDeck, TtRtnByAgeTable ttRtnTable, XYPlotImage image, double? planReturn, int slideNumber)
        {
            using (PP.Slide ppSlide = ppDeck.Slide(slideNumber))
            {
                using (PP.Shape ppShape = ppSlide.Shape("Subtitle"))
                    ppShape.Text = string.Format("Plan {0} as of {1}", Number, Date.ToString("MM/dd/yyyy"));

                using (PP.Shape ppShape = ppSlide.Shape("Disclosure"))
                {
                    ppShape.Replace("<benchmark>", Series.UnitName);
                    ppShape.Replace("<ereviewnumber>", isAdvisor ? eReviewPrrAgeAdvisor : eReviewPrrAgeRetail);
                }

                using (PP.Shape ppShape = ppSlide.Shape("LabelTDF"))
                    ppShape.Replace("<family>", Series.FullName);

                using (PP.Shape ppShape = ppSlide.Shape("Chart"))
                {
                    ppSlide.AddImage(image.FileName, ppShape.Left, ppShape.Top, (float)image.PointWidth, (float)image.PointHeight);
                    ppShape.Delete();
                }
                using (PP.Table ppTable = ppSlide.Table("Table"))
                {
                    double[,] data = ttRtnTable.ToArray();
                    for (int i = 0; i < 6; i++)
                    {
                        int j = i + 2;
                        int k = i < 5 ? i + 1 : 7;
                        using (PP.Shape ppShape = ppTable[2, j]) ppShape.Text = data[0, k].ToString("0%");
                        using (PP.Shape ppShape = ppTable[3, j]) ppShape.Text = data[1, k].ToString("0.0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[4, j]) ppShape.Text = data[2, k].ToString("0%").Replace("NaN", "N/A");
                    }
                }

                using (PP.Table ppTable = ppSlide.Table("TablePlanReturn"))
                using (PP.Shape ppShape = ppTable[1, 2])
                    ppShape.Text = planReturn.HasValue ? planReturn.Value.ToString("#0.0%") : "N/A";
            }
        }

        private void buildSlideRskRtn(PP.Deck ppDeck, RskRtnByAgeTable table, XYPlotImage image, int slideNumber)
        {
            using (PP.Slide ppSlide = ppDeck.Slide(slideNumber))
            {
                using (PP.Shape ppShape = ppSlide.Shape("Subtitle"))
                    ppShape.Text = string.Format("Plan {0} as of {1}", Number, Date.ToString("MM/dd/yyyy"));

                using (PP.Shape ppShape = ppSlide.Shape("Disclosure"))
                {
                    ppShape.Replace("<benchmark>", Series.UnitName);
                    ppShape.Replace("<ereviewnumber>", isAdvisor ? eReviewRiskReturnAdvisor : eReviewRiskReturnRetail);
                }

                using (PP.Shape ppShape = ppSlide.Shape("LabelTDF"))
                    ppShape.Replace("<family>", Series.FullName);

                using (PP.Shape ppShape = ppSlide.Shape("Chart"))
                {
                    ppSlide.AddImage(image.FileName, ppShape.Left, ppShape.Top, (float)image.PointWidth, (float)image.PointHeight);
                    ppShape.Delete();
                }
                using (PP.Table ppTable = ppSlide.Table("Table"))
                {
                    double[,] data = table.ToArray();
                    for (int i = 0; i < 6; i++)
                    {
                        int j = i + 3;
                        int k = i < 5 ? i + 1 : 7;
                        using (PP.Shape ppShape = ppTable[3, j]) ppShape.Text = data[0, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[4, j]) ppShape.Text = data[1, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[5, j]) ppShape.Text = data[2, k].ToString("0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[6, j]) ppShape.Text = data[3, k].ToString("0%").Replace("NaN", "N/A");
                    }
                }
            }
        }

        private void buildSlideCsRtn(PP.Deck ppDeck, CsReturnByAgeTable table, XYPlotImage image, int slideNumber)
        {
            using (PP.Slide ppSlide = ppDeck.Slide(slideNumber))
            {
                using (PP.Shape ppShape = ppSlide.Shape("Subtitle"))
                    ppShape.Text = string.Format("Plan {0} as of {1}", Number, Date.ToString("MM/dd/yyyy"));

                using (PP.Shape ppShape = ppSlide.Shape("Disclosure"))
                {
                    ppShape.Replace("<benchmark>", Series.UnitName);
                    ppShape.Replace("<ereviewnumber>", isAdvisor ? eReviewPrrAgeAdvisor : eReviewPrrAgeRetail);
                }

                using (PP.Shape ppShape = ppSlide.Shape("LabelTDF"))
                    ppShape.Replace("<family>", Series.FullName);

                using (PP.Shape ppShape = ppSlide.Shape("Chart"))
                {
                    ppSlide.AddImage(image.FileName, ppShape.Left, ppShape.Top, (float)image.PointWidth, (float)image.PointHeight);
                    ppShape.Delete();
                }
                using (PP.Table ppTable = ppSlide.Table("Table"))
                {
                    double[,] data = table.ToArray();
                    for (int i = 0; i < 6; i++)
                    {
                        int j = i + 2;
                        int k = i < 5 ? i + 1 : 7;
                        using (PP.Shape ppShape = ppTable[2, j]) ppShape.Text = data[0, k].ToString("0%");
                        using (PP.Shape ppShape = ppTable[3, j]) ppShape.Text = data[1, k].ToString("0.0%").Replace("NaN", "N/A");
                        using (PP.Shape ppShape = ppTable[4, j]) ppShape.Text = data[2, k].ToString("0.0%").Replace("NaN", "N/A");
                    }
                }
            }
        }

        public void BuildIR(PP.Application ppInstance, string rootFolder)
        {
            bool[] keepSlide = new bool[18];
            string templateFile = string.Format("{0}scatter plot template.pptx", rootFolder);
            string shellFile = string.Format("{0}empty.pptx", rootFolder);
            
            using (PP.Deck ppDeck = ppInstance.Open(templateFile))
            using (PP.Deck ppShell = ppInstance.Open(shellFile))
            {
                // Slide: Return by Age, 01-Year Version
                if (ttRtnPlot01y.Count >= participantMinimum)
                {
                    buildSlideTtRtn(ppDeck, ttRtnTable01y, ttRtnImage01y, Return.Cm01y, 01);
                    PP.Deck.CopySlide(ppDeck, 01, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "01"));
                    ppShell.Clear();
                    keepSlide[01] = true;
                }

                // Slide: Return by Age, 03-Year Version
                if (ttRtnPlot03y.Count >= participantMinimum)
                {
                    buildSlideTtRtn(ppDeck, ttRtnTable03y, ttRtnImage03y, Return.An03y, 02);
                    PP.Deck.CopySlide(ppDeck, 02, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "02"));
                    ppShell.Clear();
                    keepSlide[02] = true;
                }

                // Slide: Return by Age, 05-Year Version
                if (ttRtnPlot05y.Count >= participantMinimum)
                {
                    buildSlideTtRtn(ppDeck, ttRtnTable05y, ttRtnImage05y, Return.An05y, 03);
                    PP.Deck.CopySlide(ppDeck, 03, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "03"));
                    ppShell.Clear();
                    keepSlide[03] = true;
                }

                // Slide: Return by Age, 10-Year Version
                if (ttRtnPlot10y.Count >= participantMinimum)
                {
                    buildSlideTtRtn(ppDeck, ttRtnTable10y, ttRtnImage10y, Return.An10y, 04);
                    PP.Deck.CopySlide(ppDeck, 04, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "06"));
                    ppShell.Clear();
                    keepSlide[04] = true;
                }

                // Slide: Return by Risk, 03-Year Version
                if (ttRskPlot03y.Count >= participantMinimum)
                {
                    buildSlideRskRtn(ppDeck, ttRskTable03y, ttRskImage03y, 05);
                    PP.Deck.CopySlide(ppDeck, 05, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "04"));
                    ppShell.Clear();
                    keepSlide[05] = true;
                }

                // Slide: Return by Risk, 05-Year Version
                if (ttRskPlot05y.Count >= participantMinimum)
                {
                    buildSlideRskRtn(ppDeck, ttRskTable05y, ttRskImage05y, 06);
                    PP.Deck.CopySlide(ppDeck, 06, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "05"));
                    ppShell.Clear();
                    keepSlide[06] = true;
                }

                // Slide: Return by Risk, 10-Year Version
                if (ttRskPlot10y.Count >= participantMinimum)
                {
                    buildSlideRskRtn(ppDeck, ttRskTable10y, ttRskImage10y, 07);
                    PP.Deck.CopySlide(ppDeck, 07, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "07"));
                    ppShell.Clear();
                    keepSlide[07] = true;
                }

                // Slide: Return Excluding Company Stock by Age, 01-Year Version
                if (csRtnPlot01y.Count >= participantMinimum)
                {
                    buildSlideCsRtn(ppDeck, csRtnTable01y, csRtnImage01y, 08);
                    PP.Deck.CopySlide(ppDeck, 08, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "11"));
                    ppShell.Clear();
                    keepSlide[08] = true;
                }

                // Slide: Return Excluding Company Stock by Age, 03-Year Version
                if (csRtnPlot03y.Count >= participantMinimum)
                {
                    buildSlideCsRtn(ppDeck, csRtnTable03y, csRtnImage03y, 09);
                    PP.Deck.CopySlide(ppDeck, 09, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "12"));
                    ppShell.Clear();
                    keepSlide[09] = true;
                }

                // Slide: Return Excluding Company Stock by Age, 05-Year Version
                if (csRtnPlot05y.Count >= participantMinimum)
                {
                    buildSlideCsRtn(ppDeck, csRtnTable05y, csRtnImage05y, 10);
                    PP.Deck.CopySlide(ppDeck, 10, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "13"));
                    ppShell.Clear();
                    keepSlide[10] = true;
                }

                // Slide: Return Excluding Company Stock by Age, 10-Year Version
                if (csRtnPlot10y.Count >= participantMinimum)
                {
                    buildSlideCsRtn(ppDeck, csRtnTable10y, csRtnImage10y, 11);
                    PP.Deck.CopySlide(ppDeck, 11, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "16"));
                    ppShell.Clear();
                    keepSlide[11] = true;
                }

                // Slide: Return Excluding Company Stock by Risk, 03-Year Version
                if (csRskPlot03y.Count >= participantMinimum)
                {
                    buildSlideRskRtn(ppDeck, csRskTable03y, csRskImage03y, 12);
                    PP.Deck.CopySlide(ppDeck, 12, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "14"));
                    ppShell.Clear();
                    keepSlide[12] = true;
                }

                // Slide: Return Excluding Company Stock by Risk, 05-Year Version
                if (csRskPlot05y.Count >= participantMinimum)
                {
                    buildSlideRskRtn(ppDeck, csRskTable05y, csRskImage05y, 13);
                    PP.Deck.CopySlide(ppDeck, 13, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "15"));
                    ppShell.Clear();
                    keepSlide[13] = true;
                }

                // Slide: Return Excluding Company Stock by Risk, 10-Year Version
                if (csRskPlot10y.Count >= participantMinimum)
                {
                    buildSlideRskRtn(ppDeck, csRskTable10y, csRskImage10y, 14);
                    PP.Deck.CopySlide(ppDeck, 14, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "17"));
                    ppShell.Clear();
                    keepSlide[14] = true;
                }

                // Slide: Percent Equity (All Participants)
                if (eqAgeAllPlot.Count >= participantMinimum)
                {
                    buildSlideEqAgeAll(ppDeck, eqAgeAllTable, eqAgeAllImage, 16);
                    PP.Deck.CopySlide(ppDeck, 16, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "20"));
                    ppShell.Clear();
                    keepSlide[16] = true;
                }

                // Slide: Percent Equity (DIY Participants)
                if (eqAgeAllPlot.Count >= participantMinimum && eqAgeDiyPlot.Count > 0)
                {
                    buildSlideEqAgeDiy(ppDeck, eqAgeDiyTable, eqAgeDiyImage, 15);
                    PP.Deck.CopySlide(ppDeck, 15, ppShell, 01);
                    ppShell.Save(string.Format(rootFolder + "ppt\\irp\\{0}.{1}.{2}.pptx", Number, Date.ToString("yyMM"), "19"));
                    ppShell.Clear();
                    keepSlide[15] = true;

                    // save overall results to text file
                    using (var writer = new StreamWriter(string.Format("{0}\\report.{1}.20.txt", rootFolder, Date.ToString("yyMM")), true))
                        writer.WriteLine("{0},{1},{2}"
                            , Number, Date.ToString("yyyy-MM-dd"), eqAgeDiyTable.ToStringOverall());
                }                

                // Scan deck in reverse order and delete unused slides
                for (int i = 16; i >= 1; i--)
                    if (keepSlide[i] == false)
                        ppDeck.DeleteSlide(i);

                ppDeck.Save(string.Format(rootFolder + "ppt\\irc\\{0}.{1}.ir.pptx", Number, Date.ToString("yyMM")));
            }
        }

        /// <summary>
        /// Create worksheet from template T1: "Return by Age"
        /// </summary>
        private void buildSheetTtRtn(XL.Book xlBook, XYPlot plot, TtRtnByAgeTable ttRtnTable, TargetDateTable tdRtnTable, XYPlotImage image, double? ttRtnPlan, string rootFolder, string sheetName)
        {
            xlBook.CopySheet("T1", sheetName);
            using (XL.Sheet xlSheet = xlBook.Sheet(sheetName))
            {
                plot.Randomize();
                double[,] data = plot.ToXYArray(participantMaximum);
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!ScatterCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = ttRtnTable.ToArray();
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!SummaryCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = tdRtnTable.ToTargetAgeRtnArray();
                if (data.GetLength(0) > 0 && data.GetLength(1) > 0)
                    using (XL.Range xlCorner = xlSheet.Range(sheetName + "!BenchmarkCorner"))
                    using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                        xlEntire.Value = data;

                if (ttRtnPlan.HasValue)
                    using (XL.Range xlRange = xlSheet.Range(sheetName + "!OverallReturn"))
                        xlRange.Value = ttRtnPlan.Value;

                using (XL.Chart xlChart = xlSheet.Chart("plot"))
                {
                    XYPlotSummary axes = new XYPlotSummary(plot);
                    XYAxis yAxis = XYAxis.ToPretty(axes.Y025, axes.Y975);
                    if (!yAxis.IsAuto)
                    {
                        xlChart.YAxisMin = yAxis.Min;
                        xlChart.YAxisMax = yAxis.Max;
                        xlChart.YAxisMajorUnit = yAxis.Unit;
                    }

                    image.FileName = string.Format(rootFolder + "png\\{0}.{1}.png", Number, sheetName);
                    image.PointHeight = xlChart.Height;
                    image.PointWidth = xlChart.Width;
                    xlChart.SavePNG(image.FileName);
                }
            }
        }

        /// <summary>
        /// Create worksheet from template T2: "Return by Risk"
        /// </summary>
        private void buildSheetRskRtn(XL.Book xlBook, XYPlot plot, RskRtnByAgeTable ttRskTable, TargetDateTable tdRtnTable, XYAxis xAxis, XYAxis yAxis, XYPlotImage image, string rootFolder, string sheetName)
        {
            xlBook.CopySheet("T2", sheetName);
            using (XL.Sheet xlSheet = xlBook.Sheet(sheetName))
            {
                plot.Randomize();
                double[,] data = plot.ToXYArray(5000);
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!ScatterCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = ttRskTable.ToArray();
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!SummaryCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;
                
                data = tdRtnTable.ToTargetRskRtnArray();
                if (data.GetLength(0) > 0 && data.GetLength(1) > 0)
                    using (XL.Range xlCorner = xlSheet.Range(sheetName + "!BenchmarkCorner"))
                    using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                        xlEntire.Value = data;

                using (XL.Chart xlChart = xlSheet.Chart("plot"))
                {
                    if (!yAxis.IsAuto)
                    {
                        xlChart.YAxisMin = yAxis.Min;
                        xlChart.YAxisMax = yAxis.Max;
                        xlChart.YAxisMajorUnit = yAxis.Unit;
                    }
                    if (!xAxis.IsAuto)
                    {
                        xlChart.XAxisMin = 0;
                        xlChart.XAxisMax = xAxis.Max;
                        xlChart.XAxisMajorUnit = xAxis.Unit;
                    }

                    image.FileName = string.Format(rootFolder + "png\\{0}.{1}.png", Number, sheetName);
                    image.PointHeight = xlChart.Height;
                    image.PointWidth = xlChart.Width;
                    xlChart.SavePNG(image.FileName);
                }
            }

        }

        /// <summary>
        /// Create worksheet from template T3: "Return Excluding Company Stock, by Age"
        /// </summary>
        private void buildSheetCsRtn(XL.Book xlBook, XYPlot plot, CsReturnByAgeTable csRtnTable, TargetDateTable tdRtnTable, XYPlotImage image, string rootFolder, string sheetName)
        {
            xlBook.CopySheet("T3", sheetName);
            using (XL.Sheet xlSheet = xlBook.Sheet(sheetName))
            {
                plot.Randomize();
                double[,] data = plot.ToXYArray(5000);
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!ScatterCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = csRtnTable.ToArray();
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!SummaryCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = tdRtnTable.ToTargetAgeRtnArray();
                if (data.GetLength(0) > 0 && data.GetLength(1) > 0)
                    using (XL.Range xlCorner = xlSheet.Range(sheetName + "!BenchmarkCorner"))
                    using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                        xlEntire.Value = data;

                using (XL.Chart xlChart = xlSheet.Chart("plot"))
                {
                    XYPlotSummary axes = new XYPlotSummary(plot);
                    XYAxis yAxis = XYAxis.ToPretty(axes.Y025, axes.Y975);
                    if (!yAxis.IsAuto)
                    {
                        xlChart.YAxisMin = yAxis.Min;
                        xlChart.YAxisMax = yAxis.Max;
                        xlChart.YAxisMajorUnit = yAxis.Unit;
                    }

                    image.FileName = string.Format(rootFolder + "png\\{0}.{1}.png", Number, sheetName);
                    image.PointHeight = xlChart.Height;
                    image.PointWidth = xlChart.Width;
                    xlChart.SavePNG(image.FileName);
                }
            }
        }

        /// <summary>
        /// Create worksheet from template T4: "Percent Equity, by Age"
        /// </summary>
        private void buildSheetEqAgeAll(XL.Book xlBook, XYPlot eqAgePlot, EquityByAgeAllTable eqAgeTable, EquityBand eqBand, XYPlotImage image, string rootFolder, string sheetName)
        {
            xlBook.CopySheet("T4", sheetName);
            using (XL.Sheet xlSheet = xlBook.Sheet(sheetName))
            {
                eqAgePlot.Randomize();
                double[,] data = eqAgePlot.ToXYArray(5000);
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!ScatterCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = eqAgeTable.ToArray();
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!SummaryCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = new double[51, 3];
                for (int i = 25; i <= 75; i++)
                {
                    data[i - 25, 0] = i;
                    data[i - 25, 1] = eqBand[RetirementAge - i].Min;
                    data[i - 25, 2] = eqBand[RetirementAge - i].Max;
                }
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!BandCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                using (XL.Chart xlChart = xlSheet.Chart("plot"))
                {
                    image.FileName = string.Format(rootFolder + "png\\{0}.{1}.png", Number, sheetName);
                    image.PointHeight = xlChart.Height;
                    image.PointWidth = xlChart.Width;
                    xlChart.SavePNG(image.FileName);
                }
            }
        }

        /// <summary>
        /// Create worksheet from template T4: "Percent Equity, by Age"
        /// </summary>
        private void buildSheetEqAgeDiy(XL.Book xlBook, XYPlot eqAgePlot, EquityByAgeDiyTable eqAgeTable, EquityBand eqBand, XYPlotImage image, string rootFolder, string sheetName)
        {
            xlBook.CopySheet("T5", sheetName);
            using (XL.Sheet xlSheet = xlBook.Sheet(sheetName))
            {
                eqAgePlot.Randomize();
                double[,] data = eqAgePlot.ToXYArray(5000);
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!ScatterCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = eqAgeTable.ToArray();
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!SummaryCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                data = new double[51, 3];
                for (int i = 25; i <= 75; i++)
                {
                    data[i - 25, 0] = i;
                    data[i - 25, 1] = eqBand[RetirementAge - i].Min;
                    data[i - 25, 2] = eqBand[RetirementAge - i].Max;
                }
                using (XL.Range xlCorner = xlSheet.Range(sheetName + "!BandCorner"))
                using (XL.Range xlEntire = xlCorner.Resize(data.GetLength(0), data.GetLength(1)))
                    xlEntire.Value = data;

                using (XL.Chart xlChart = xlSheet.Chart("plot"))
                {
                    image.FileName = string.Format(rootFolder + "png\\{0}.{1}.png", Number, sheetName);
                    image.PointHeight = xlChart.Height;
                    image.PointWidth = xlChart.Width;
                    xlChart.SavePNG(image.FileName);
                }                                
            }
        }

        /// <summary>
        /// populate the template workbook
        /// </summary>
        /// <param name="xlInstance">an open instance of excel</param>
        /// <param name="rootFolder">the folder that contains the template file</param>
        /// <param name="templateFile">the template file name</param>
        public void BuildSpreadsheet(XL.Application xlInstance, string rootFolder, bool saveFile)
        {            
            XYAxis ttRskXAxis03y = null;
            XYAxis ttRskYAxis03y = null;
            XYAxis csRskXAxis03y = null;
            XYAxis csRskYAxis03y = null;

            if (ttRskPlot03y.Count >= participantMinimum)
            {
                XYPlotSummary ttAxes;
                XYPlotSummary csAxes;
                ttAxes = new XYPlotSummary(ttRskPlot03y);
                if (csRskPlot03y.Count >= participantMinimum)
                {
                    csAxes = new XYPlotSummary(csRskPlot03y);
                    csRskXAxis03y = ttRskXAxis03y = XYAxis.ToPretty(Math.Min(ttAxes.X025, csAxes.X025), Math.Max(ttAxes.X975, csAxes.X975));
                    csRskYAxis03y = ttRskYAxis03y = XYAxis.ToPretty(Math.Min(ttAxes.Y025, csAxes.Y025), Math.Max(ttAxes.Y975, csAxes.Y975));                    
                }
                else
                {
                    ttRskXAxis03y = XYAxis.ToPretty(ttAxes.X025, ttAxes.X975);
                    ttRskYAxis03y = XYAxis.ToPretty(ttAxes.Y025, ttAxes.Y975);
                }
            }

            XYAxis ttRskXAxis05y = null;
            XYAxis ttRskYAxis05y = null;
            XYAxis csRskXAxis05y = null;
            XYAxis csRskYAxis05y = null;

            if (ttRskPlot05y.Count >= participantMinimum)
            {
                XYPlotSummary ttAxes;
                XYPlotSummary csAxes;
                ttAxes = new XYPlotSummary(ttRskPlot05y);
                if (csRskPlot05y.Count >= participantMinimum)
                {
                    csAxes = new XYPlotSummary(csRskPlot05y);
                    csRskXAxis05y = ttRskXAxis05y = XYAxis.ToPretty(Math.Min(ttAxes.X025, csAxes.X025), Math.Max(ttAxes.X975, csAxes.X975));
                    csRskYAxis05y = ttRskYAxis05y = XYAxis.ToPretty(Math.Min(ttAxes.Y025, csAxes.Y025), Math.Max(ttAxes.Y975, csAxes.Y975));
                }
                else
                {
                    ttRskXAxis05y = XYAxis.ToPretty(ttAxes.X025, ttAxes.X975);
                    ttRskYAxis05y = XYAxis.ToPretty(ttAxes.Y025, ttAxes.Y975);
                }
            }

            XYAxis ttRskXAxis10y = null;
            XYAxis ttRskYAxis10y = null;
            XYAxis csRskXAxis10y = null;
            XYAxis csRskYAxis10y = null;

            if (ttRskPlot10y.Count >= participantMinimum)
            {
                XYPlotSummary ttAxes;
                XYPlotSummary csAxes;
                ttAxes = new XYPlotSummary(ttRskPlot10y);
                if (csRskPlot10y.Count >= participantMinimum)
                {
                    csAxes = new XYPlotSummary(csRskPlot10y);
                    csRskXAxis10y = ttRskXAxis10y = XYAxis.ToPretty(Math.Min(ttAxes.X025, csAxes.X025), Math.Max(ttAxes.X975, csAxes.X975));
                    csRskYAxis10y = ttRskYAxis10y = XYAxis.ToPretty(Math.Min(ttAxes.Y025, csAxes.Y025), Math.Max(ttAxes.Y975, csAxes.Y975));
                }
                else
                {
                    ttRskXAxis10y = XYAxis.ToPretty(ttAxes.X025, ttAxes.X975);
                    ttRskYAxis10y = XYAxis.ToPretty(ttAxes.Y025, ttAxes.Y975);
                }
            }

            string templateFile = string.Format("{0}Scatter Plot Template.xlsx", rootFolder);
            using (XL.Book xlBook = xlInstance.Open(templateFile))
            {
                // Sheet: Returns by Age, 01-Year Version
                if (ttRtnPlot01y.Count >= participantMinimum)
                    buildSheetTtRtn(xlBook, ttRtnPlot01y, ttRtnTable01y, tdRtnTable01y, ttRtnImage01y, Return.Cm01y, rootFolder, "01");

                // Sheet: Returns by Age, 03-Year Version
                if (ttRtnPlot03y.Count >= participantMinimum)
                    buildSheetTtRtn(xlBook, ttRtnPlot03y, ttRtnTable03y, tdRtnTable03y, ttRtnImage03y, Return.An03y, rootFolder, "02");

                // Sheet: Returns by Age, 05-Year Version
                if (ttRtnPlot05y.Count >= participantMinimum)
                    buildSheetTtRtn(xlBook, ttRtnPlot05y, ttRtnTable05y, tdRtnTable05y, ttRtnImage05y, Return.An05y, rootFolder, "03");

                // Sheet: Returns by Age, 10-Year Version
                if (ttRtnPlot10y.Count >= participantMinimum)
                    buildSheetTtRtn(xlBook, ttRtnPlot10y, ttRtnTable10y, tdRtnTable10y, ttRtnImage10y, Return.An10y, rootFolder, "06");

                // Sheet: Total Return by Risk, 03-Year Version
                if (ttRskPlot03y.Count >= participantMinimum)
                    buildSheetRskRtn(xlBook, ttRskPlot03y, ttRskTable03y, tdRtnTable03y, ttRskXAxis03y, ttRskYAxis03y, ttRskImage03y, rootFolder, "04");

                // Sheet: Total Return by Risk, 05-Year Version
                if (ttRskPlot05y.Count >= participantMinimum)
                    buildSheetRskRtn(xlBook, ttRskPlot05y, ttRskTable05y, tdRtnTable05y, ttRskXAxis05y, ttRskYAxis05y, ttRskImage05y, rootFolder, "05");

                // Sheet: Total Return by Risk, 10-Year Version
                if (ttRskPlot10y.Count >= participantMinimum)
                    buildSheetRskRtn(xlBook, ttRskPlot10y, ttRskTable10y, tdRtnTable10y, ttRskXAxis10y, ttRskYAxis10y, ttRskImage10y, rootFolder, "07");

                // Sheet: Returns Excluding Company Stock by Age, 01-Year Version
                if (csRtnPlot01y.Count >= participantMinimum)
                    buildSheetCsRtn(xlBook, csRtnPlot01y, csRtnTable01y, tdRtnTable01y, csRtnImage01y, rootFolder, "11");

                // Sheet: Returns Excluding Company Stock by Age, 03-Year Version
                if (csRtnPlot03y.Count >= participantMinimum)
                    buildSheetCsRtn(xlBook, csRtnPlot03y, csRtnTable03y, tdRtnTable03y, csRtnImage03y, rootFolder, "12");

                // Sheet: Returns Excluding Company Stock by Age, 05-Year Version
                if (csRtnPlot05y.Count >= participantMinimum)
                    buildSheetCsRtn(xlBook, csRtnPlot05y, csRtnTable05y, tdRtnTable05y, csRtnImage05y, rootFolder, "13");

                // Sheet: Returns Excluding Company Stock by Age, 10-Year Version
                if (csRtnPlot10y.Count >= participantMinimum)
                    buildSheetCsRtn(xlBook, csRtnPlot10y, csRtnTable10y, tdRtnTable10y, csRtnImage10y, rootFolder, "16");

                // Sheet: Returns Excluding Stock by Risk, 03-Year Version
                if (csRskPlot03y.Count >= participantMinimum)
                    buildSheetRskRtn(xlBook, csRskPlot03y, csRskTable03y, tdRtnTable03y, csRskXAxis03y, csRskYAxis03y, csRskImage03y, rootFolder, "14");

                // Sheet: Returns Excluding Stock by Risk, 05-Year Version
                if (csRskPlot05y.Count >= participantMinimum)
                    buildSheetRskRtn(xlBook, csRskPlot05y, csRskTable05y, tdRtnTable05y, csRskXAxis05y, csRskYAxis05y, csRskImage05y, rootFolder, "15");

                // Sheet: Returns Excluding Stock by Risk, 10-Year Version
                if (csRskPlot10y.Count >= participantMinimum)
                    buildSheetRskRtn(xlBook, csRskPlot10y, csRskTable10y, tdRtnTable10y, csRskXAxis10y, csRskYAxis10y, csRskImage10y, rootFolder, "17");

                // Sheet: Percent Equity by Age (All Participants)
                if (eqAgeAllPlot.Count >= participantMinimum)
                    buildSheetEqAgeAll(xlBook, eqAgeAllPlot, eqAgeAllTable, Series.Band, eqAgeAllImage, rootFolder, "19");

                // Sheet: Percent Equity by Age (DIY Participants)
                if (eqAgeAllPlot.Count >= participantMinimum && eqAgeDiyPlot.Count > 0)
                    buildSheetEqAgeDiy(xlBook, eqAgeDiyPlot, eqAgeDiyTable, Series.Band, eqAgeDiyImage, rootFolder, "20");


                // Save Workbook
                if (saveFile)
                    xlBook.Save(string.Format(rootFolder + "xls\\{0}.{1}.xlsx", Number, Date.ToString("yyMM")));
            }
        }

        public void Add(double? age, double? equity, bool isDiy, RiskReturnSet ttRtn, RiskReturnSet csRtn, RiskReturnSet tdRtn)
        {
            // Skip Age-Less Participants
            if (!age.HasValue)
                return;

            int ageRange = (int)Math.Min(6, Math.Max(0, Math.Floor(((age.Value + 5) - 20) / 10)));

            if (equity.HasValue)
            {
                eqAgeAllPlot.Add(age.Value, equity.Value);
                
                int ytr = (int)Math.Round(RetirementAge - age.Value, 0, MidpointRounding.AwayFromZero);
                EquityBandWidth bw = Series.Band[ytr];

                eqAgeAllTable.Add(age.Value, equity.Value, bw.Min, bw.Max);

                // Per Bill Ralls: 
                // Another equity band line will be added at +/- 25% of the Fidelity Equity Glide Path, capped at 99%. 
                if (isDiy) 
                {
                    eqAgeDiyPlot.Add(age.Value, equity.Value);
                    eqAgeDiyTable.Add(age.Value, equity.Value, bw.Min, bw.Max, bw.Min - 0.15d, Math.Min(bw.Max + 0.15d, 0.99d));
                }
            }

            // 01-Year Return Slides
            //if (enable01ySlides && ttRtn.Cm01y.HasValue && tdRtn.Cm01y.HasValue)
            if (enable01ySlides && ttRtn.Cm01y.HasValue)
            {
                ttRtnPlot01y.Add(age.Value, ttRtn.Cm01y.Value);
                ttRtnTable01y.Add(age.Value, ttRtn.Cm01y.Value, tdRtn.Cm01y);

                if (enableStockSlides && csRtn.Cm01y.HasValue)
                {
                    csRtnPlot01y.Add(age.Value, csRtn.Cm01y.Value);
                    csRtnTable01y.Add(age.Value, ttRtn.Cm01y.Value, csRtn.Cm01y.Value);
                }
            }

            // 03-Year Return Slides
            //if (enable03ySlides && ttRtn.An03y.HasValue && tdRtn.An03y.HasValue)
            if (enable03ySlides && ttRtn.An03y.HasValue)
            {
                ttRtnPlot03y.Add(age.Value, ttRtn.An03y.Value);
                ttRtnTable03y.Add(age.Value, ttRtn.An03y.Value, tdRtn.An03y);
                //if (ttRtn.Sd03y.HasValue && tdRtn.Sd03y.HasValue)
                if (ttRtn.Sd03y.HasValue)
                {
                    ttRskPlot03y.Add(ttRtn.Sd03y.Value, ttRtn.An03y.Value);
                    ttRskTable03y.Add(age.Value, ttRtn.An03y.Value, ttRtn.Sd03y.Value, tdRtn.An03y, tdRtn.Sd03y);
                    if (enableStockSlides && csRtn.An03y.HasValue)
                    {
                        csRtnPlot03y.Add(age.Value, csRtn.An03y.Value);
                        csRtnTable03y.Add(age.Value, ttRtn.An03y.Value, csRtn.An03y.Value);
                        if(csRtn.Sd03y.HasValue)
                        {
                            csRskPlot03y.Add(csRtn.Sd03y.Value, csRtn.An03y.Value);
                            csRskTable03y.Add(age.Value, csRtn.An03y.Value, csRtn.Sd03y.Value, tdRtn.An03y, tdRtn.Sd03y);
                        }
                    }
                }
            }
            else return;

            // 05-Year Return Slides
            //if (enable05ySlides && ttRtn.An05y.HasValue && tdRtn.An05y.HasValue)
            if (enable05ySlides && ttRtn.An05y.HasValue)
            {
                ttRtnPlot05y.Add(age.Value, ttRtn.An05y.Value);
                ttRtnTable05y.Add(age.Value, ttRtn.An05y.Value, tdRtn.An05y);
                //if (ttRtn.Sd05y.HasValue && tdRtn.Sd05y.HasValue)
                if (ttRtn.Sd05y.HasValue)
                {
                    ttRskPlot05y.Add(ttRtn.Sd05y.Value, ttRtn.An05y.Value);
                    ttRskTable05y.Add(age.Value, ttRtn.An05y.Value, ttRtn.Sd05y.Value, tdRtn.An05y, tdRtn.Sd05y);
                    if (enableStockSlides && csRtn.An05y.HasValue)
                    {
                        csRtnPlot05y.Add(age.Value, csRtn.An05y.Value);
                        csRtnTable05y.Add(age.Value, ttRtn.An05y.Value, csRtn.An05y.Value);
                        if (csRtn.Sd05y.HasValue)
                        {
                            csRskPlot05y.Add(csRtn.Sd05y.Value, csRtn.An05y.Value);
                            csRskTable05y.Add(age.Value, csRtn.An05y.Value, csRtn.Sd05y.Value, tdRtn.An05y, tdRtn.Sd05y);
                        }
                    }
                }
            }
            else return;

            // 10-Year Return Slides
            //if (enable10ySlides && ttRtn.An10y.HasValue && tdRtn.An10y.HasValue)
            if (enable10ySlides && ttRtn.An10y.HasValue)
            {
                ttRtnPlot10y.Add(age.Value, ttRtn.An10y.Value);
                ttRtnTable10y.Add(age.Value, ttRtn.An10y.Value, tdRtn.An10y);
                //if (ttRtn.Sd10y.HasValue && tdRtn.Sd10y.HasValue)
                if (ttRtn.Sd10y.HasValue)
                {
                    ttRskPlot10y.Add(ttRtn.Sd10y.Value, ttRtn.An10y.Value);
                    ttRskTable10y.Add(age.Value, ttRtn.An10y.Value, ttRtn.Sd10y.Value, tdRtn.An10y, tdRtn.Sd10y);
                    if (enableStockSlides && csRtn.An10y.HasValue)
                    {
                        csRtnPlot10y.Add(age.Value, csRtn.An10y.Value);
                        csRtnTable10y.Add(age.Value, ttRtn.An10y.Value, csRtn.An10y.Value);
                        if (csRtn.Sd10y.HasValue)
                        {
                            csRskPlot10y.Add(csRtn.Sd10y.Value, csRtn.An10y.Value);
                            csRskTable10y.Add(age.Value, csRtn.An10y.Value, csRtn.Sd10y.Value, tdRtn.An10y, tdRtn.Sd10y);
                        }
                    }
                }
            }
            else return;
        }
    }
}