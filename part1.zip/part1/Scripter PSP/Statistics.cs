﻿namespace Porter
{
    using System;

    /// <summary>
    /// Statistics Functions and Classes
    /// </summary>
    public static class Statistics
    {
        /// <summary>
        /// Compute the sum.
        /// </summary>
        /// <param name="data">An array of values.</param>
        public static double Sum(params double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return data[0];

            double result = 0;

            foreach (double value in data)
                result = checked(result + value);

            return result;
        }

        /// <summary>
        /// Compute the arithmetic mean.
        /// </summary>
        /// <param name="data">An array of values.</param>
        public static double Mean(params double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return data[0];

            return Sum(data) / data.Length;
        }

        /// <summary>
        /// Compute the weighted arithmetic average.
        /// </summary>
        /// <param name="data">An array of values.</param>
        /// <param name="weight">An array of weights.</param>
        public static double Mean(double[] data, double[] weight)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return data[0];

            if (data.Length != weight.Length)
                throw new ArgumentException("The data[] and weight[] arrays must be the same length.");

            double sum = 0;
            for (int i = 0; i < data.Length; i++)
                sum = checked(sum + data[i] * weight[i]);

            return sum / data.Length;
        }

        /// <summary>
        /// Compute the minimum
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double Min(double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return data[0];

            double value = data[0];
            for (int i = 1; i < data.Length; i++)
            {
                if (value > data[i]) value = data[i];
            }
            return value;
        }

        /// <summary>
        /// Compute the maximum
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double Max(double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return data[0];

            double value = data[0];
            for (int i = 1; i < data.Length; i++)
            {
                if (value < data[i]) value = data[i];
            }
            return value;
        }

        /// <summary>
        /// Compute the sample variance.
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double Variance(double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return 0;

            double sum = 0;
            double mean = Mean(data);

            // Sum of Squared Deviations from the Mean
            for (int i = 0; i < data.Length; i++)
                sum = checked(sum + (data[i] - mean) * (data[i] - mean));

            return sum / (data.Length - 1);
        }

        /// <summary>
        /// Compute the sample skewness.
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double Skewness(double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return 0;

            double mean = Mean(data);
            double m2 = 0;
            double m3 = 0;

            for (int i = 0; i < data.Length; i++)
            {
                double m = data[i] - mean;

                m2 += m * m;
                m3 += m * m * m;                
            }
            return Math.Sqrt(data.Length) * m3 / Math.Pow(m2, 1.5);
        }

        /// <summary>
        /// Compute the sample kurtosis.
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double Kurtosis(double[] data)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return 0;

            double mean = Mean(data);
            double m2 = 0;
            double m4 = 0;

            for (int i = 0; i < data.Length; i++)
            {
                double m = data[i] - mean;

                m2 += m * m;
                m4 += m * m * m * m;
            }
            return (data.Length * m4) / (m2 * m2) - 3;
        }

        /// <summary>
        /// Compute the percentile.
        /// </summary>
        /// <param name="data">An array of values</param>
        /// <param name="rank">A percentile rank</param>
        public static double Percentile(double[] data, double rank)
        {
            return Quantile(Sort(data), rank);
        }

        /// <summary>
        /// Compute the percentile.
        /// </summary>
        /// <param name="keys">An array of keys to determine sort order.</param>
        /// <param name="values">An array of values to be sorted based on array of keys.</param>
        /// <param name="rank">A percentile rank</param>
        public static double Percentile(double[] keys, double[] values, double rank)
        {
            return Quantile(Sort(keys, values), rank);
        }

        /// <summary>
        /// Compute the median.
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double Median(double[] data)
        {
            return Quantile(Sort(data), 0.50);
        }

        /// <summary>
        /// Compute the median absolute deviation about the specified value.
        /// </summary>
        /// <param name="data">An array of values</param>
        /// <param name="center">The value to center about, typically the median.</param>
        public static double MAD(double[] data, double center)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return Math.Abs(data[0] - center);

            double[] deviations = new double[data.Length];

            for (int i = 0; i < data.Length; i++)
                deviations[i] = Math.Abs(data[i] - center);

            return Percentile(deviations, 0.500);
        }

        /// <summary>
        /// Compute the median absolute deviation about the median. 
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double MAD(double[] data)
        {
            return MAD(data, Percentile(data, 0.500));
        }

        /// <summary>
        /// Compute the percentile rank of the specified value.
        /// </summary>
        /// <param name="data">An array of value</param>
        /// <param name="value">The value of which to compute the percentile rank</param>
        public static double PercentileRank(double[] data, double value)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return value < data[0] ? 0 : 1;

            double[] copy = Sort(data);

            if (value < copy[0]) return 0;
            if (value >= copy[copy.Length - 1]) return 1;

            for (int i = 1; i < copy.Length; i++)
            {
                if (copy[i - 1] < value && copy[i] >= value)
                {
                    return ((value - copy[i - 1]) / (copy[i] - copy[i - 1]) + i - 1) / ((double)copy.Length - 1);
                }
            }
            return double.NaN;
        }

        /// <summary>
        /// Compute the mean absolute deviation about the specified value.
        /// </summary>
        /// <param name="data">An array of values</param>
        /// <param name="center">The value to center about, typically the mean</param>
        public static double AAD(double[] data, double center)
        {
            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return Math.Abs(data[0] - center);

            double sum = 0;
            for (int i = 0; i < data.Length; i++)
            {
                sum = checked(sum + Math.Abs(data[i] - center));
            }
            return sum / data.Length;           
        }

        /// <summary>
        /// Compute the mean absolute deviation about the mean. 
        /// </summary>
        /// <param name="data">An array of values</param>
        public static double AAD(double[] data)
        {
            return AAD(data, Mean(data));
        }

        /// <summary>
        /// Compute the Autocorrelation of a Time Series
        /// </summary>
        /// <param name="data">An array of data, presumably representing chronological values</param>
        /// <param name="lag">The autocorrelation lag</param>
        public static double AutoCorrelation(double[] data, int lag)
        {
            if (data.Length < lag || lag < 1)
                throw new ArgumentException("Invalid Lag Parameter");

            double[] x = new double[data.Length - lag];
            double[] y = new double[data.Length - lag];

            for (int i = 0; i < data.Length - lag; i++)
            {
                x[i] = data[i];
                y[i] = data[i + lag];
            }

            return Correlation(x, y);
        }

        /// <summary>
        /// Compute the sample correlation between to arrays of values.
        /// </summary>
        /// <param name="x">The array of X values</param>
        /// <param name="y">The array of Y values</param>
        public static double Correlation(double[] x, double[] y)
        {
            /* The sample correlation is calculated as:
             * 
             *           SUM((x[i]-mean(x))*(y[i]-mean(y)))
             * r(x,y) =  ----------------------------------
             *                (n-1)*stdev(x)*stdev(y)
             * 
             * Where mean() and stdev() are the sample mean, and sample standard deviation
             * and x[i] and y[i] are the i'th pair of observations. 
             */

            if (x.Length != y.Length)
                throw new ArgumentException("Arrays must be the same length");

            // Correlation is Not Defined for Small Arrays
            if (x.Length < 2) return double.NaN;

            double xStdev = Math.Sqrt(Variance(x));
            double yStdev = Math.Sqrt(Variance(y));

            double sum = 0;
            double n = x.Length;

            for (int i = 0; i < x.Length; i++)
            {
                sum += x[i] * y[i];
            }

            return (sum - n * Mean(x) * Mean(y)) / ((n - 1) * xStdev * yStdev);
        }

        /// <summary>
        /// Compute a distribution quantile assuming sorted data.
        /// </summary>
        /// <param name="data">The sorted array of data</param>
        /// <param name="rank">The percentile rank</param>
        private static double Quantile(double[] data, double rank)
        {
            if (rank > 100 || rank < 0)
                throw new ArgumentException("Invalid Percentile Rank");

            if (data.Length == 0) return double.NaN;
            if (data.Length == 1) return data[0];

            // Position in Continuous Distribution
            double position = 1 + rank * (data.Length - 1);

            if (Math.Floor(position) < 1) return data[0]; // If Percentile = Min
            if (Math.Floor(position) >= data.Length) return data[data.Length - 1]; // If Percentile = Max

            double upper = data[(uint)position];
            double lower = data[(uint)position - 1];
            double difference = position - Math.Floor(position);

            return lower + difference * (upper - lower);
        }

        /// <summary>
        /// Sort an array of values.
        /// </summary>
        /// <param name="data">An unsorted array of values</param>
        private static double[] Sort(double[] data)
        {
            double[] copy = new double[data.Length];
            Array.Copy(data, copy, data.Length);
            Array.Sort<double>(copy);

            return copy;
        }

        /// <summary>
        /// Sort an array of values based on an array of keys.
        /// </summary>
        /// <param name="keys">An unsorted array of keys</param>
        /// <param name="values">An unsorted array of values</param>
        private static double[] Sort(double[] keys, double[] values)
        {
            if (keys.Length != values.Length)
                throw new Exception("Arrays of keys and values must have same length.");

            double[] kcopy = new double[keys.Length];
            double[] vcopy = new double[values.Length];

            Array.Copy(keys, kcopy, keys.Length);
            Array.Copy(values, vcopy, values.Length);

            Array.Sort<double, double>(kcopy, vcopy);

            return vcopy;
        }
    }
}