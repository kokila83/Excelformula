﻿namespace Porter.Charts
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// a list with support for random sampling
    /// </summary>
    public class SampleableList<T> : List<T>
    {
        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="capacity">the initial capacity of the list</param>
        public SampleableList(int capacity)
            : base(capacity) { }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="collection">the intial collection to add to the list</param>
        public SampleableList(IEnumerable<T> collection)
            : base(collection) { }

        /// <summary>
        /// select a uniform random sample with the specified number of items; if the sample size is larger
        /// than the number of items available, then the full set is returned
        /// </summary>
        /// <param name="size">the desired sample size</param>
        public SampleableList<T> Sample(int size)
        {
            if (size >= Count) return this;
            else
            {
                int[] keys = new int[Count];
                T[] values = ToArray();
                Random r = new Random();
                for (int i = 0; i < Count; i++)
                    keys[i] = r.Next();

                Array.Sort(keys, values);

                SampleableList<T> sample = new SampleableList<T>(size);
                for (int i = 0; i < size; i++)
                    sample.Add(values[i]);

                return sample;
            }
        }

        /// <summary>
        /// randomly reorder the items in the list
        /// </summary>
        public void Randomize()
        {
            int[] keys = new int[Count];
            T[] values = ToArray();
            Random r = new Random();
            for (int i = 0; i < Count; i++)
                keys[i] = r.Next();

            Array.Sort(keys, values);

            for (int i = 0; i < Count; i++)
                this[i] = values[i];
        }
    }
    
    /// <summary>
    /// an immutable xy coordinate pair
    /// </summary>
    public class XYPair
    {
        /// <summary>
        /// x coordinate
        /// </summary>
        public double X { get; private set; }

        /// <summary>
        /// y coordinate
        /// </summary>
        public double Y { get; private set; }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="x">x coordinate</param>
        /// <param name="y">y coordinate</param>
        public XYPair(double x, double y)
        {
            X = x;
            Y = y;
        }
    }

    /// <summary>
    /// an xy plot with support for random sampling
    /// </summary>
    public class XYPlot : SampleableList<XYPair>
    {
        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="capacity">initial capacity of the plot</param>
        public XYPlot(int capacity) 
            : base(capacity) { }

        /// <summary>
        /// add a new xy pair to the plot
        /// </summary>
        /// <param name="x">x coordinate</param>
        /// <param name="y">y coordinate</param>
        public void Add(double x, double y)
        {
            Add(new XYPair(x, y));
        }

        /// <summary>
        /// copy the underlying xy coordinates to a rectangular array
        /// </summary>
        public double[,] ToXYArray()
        {
            return ToXYArray(Count);
        }

        /// <summary>
        /// copy underlying xy coordinates to a rectangular array
        /// </summary>
        /// <param name="size">the maximum number of coordinates to copy</param>
        public double[,] ToXYArray(int size)
        {
            if (size > Count) size = Count;
            double[,] array = new double[size, 2];
            for (int i = 0; i < size; i++)
            {
                array[i, 0] = this[i].X;
                array[i, 1] = this[i].Y;
            }
            return array;
        }
    }

    /// <summary>
    /// an xy plot statistical summary of both x and y dimensions
    /// </summary>
    public class XYPlotSummary
    {
        /// <summary>
        /// gets the 0.025th percentile of x values
        /// </summary>
        public readonly double X025;

        /// <summary>
        /// gets the 0.975th percentile of x values
        /// </summary>
        public readonly double X975;

        /// <summary>
        /// gets the 0.025th percentile of y values
        /// </summary>
        public readonly double Y025;

        /// <summary>
        /// gets the 0.975th percentile of y values
        /// </summary>
        public readonly double Y975;

        /// <summary>
        /// create a new xy plot summary
        /// </summary>
        /// <param name="plot">the xy plot to summarize</param>
        public XYPlotSummary(IList<XYPair> plot)
        {
            double[] x = new double[plot.Count];
            double[] y = new double[plot.Count];

            for (int i = 0; i < plot.Count; i++)
            {
                x[i] = plot[i].X;
                y[i] = plot[i].Y;
            }

            X025 = Statistics.Percentile(x, 0.025);
            X975 = Statistics.Percentile(x, 0.975);

            Y025 = Statistics.Percentile(y, 0.025);
            Y975 = Statistics.Percentile(y, 0.975);
        }
    }

    /// <summary>
    /// represents an x or y axis
    /// </summary>
    public class XYAxis
    {
        /// <summary>
        /// whether the axis is automatic or not
        /// </summary>
        public readonly bool IsAuto;

        /// <summary>
        /// axis minimum
        /// </summary>
        public readonly double Min;

        /// <summary>
        /// axis maximum
        /// </summary>
        public readonly double Max;

        /// <summary>
        /// axis tick width
        /// </summary>
        public readonly double Unit;

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="min">axis minimum</param>
        /// <param name="max">axis maximum</param>
        /// <param name="unit">axis tick width</param>
        /// <param name="isAuto">whether the axis is automatic or not</param>
        public XYAxis(double min, double max, double unit, bool isAuto)
        {
            if (min >= max)
                throw new ArgumentException("min must be less than max");

            Min = min;
            Max = max;
            Unit = unit;
            IsAuto = isAuto;
        }

        /// <summary>
        /// pretty axis default unit sizes for consideration
        /// </summary>
        private static double[] prettyUnits = { .001, .002, .004, .005, .01, .02, .04, .05, .10, .20, .25, .50, 1.0 };

        /// <summary>
        /// pretty axis default number of ticks 
        /// </summary>
        private static int prettyTicks = 8;

        /// <summary>
        /// pretty axis default buffer size
        /// </summary>
        private static double prettyBuffer = 0.1d;

        /// <summary>
        /// Get clean, profesional looking axis parameters 
        /// </summary>
        /// <param name="min">a starting point for the axis minimum, usually a tail percentile</param>
        /// <param name="max">a starting point for the axis maximum, usually a tail percentile</param>
        public static XYAxis ToPretty(double min, double max)
        {
            return ToPretty(min, max, prettyTicks);
        }

        /// <summary>
        /// Get clean, profesional looking axis parameters 
        /// </summary>
        /// <param name="min">a starting point for the axis minimum, usually a tail percentile</param>
        /// <param name="max">a starting point for the axis maximum, usually a tail percentile</param>
        /// <param name="ticks">desired number of axis ticks</param>
        public static XYAxis ToPretty(double min, double max, int ticks)
        {
            return ToPretty(min, max, ticks, prettyBuffer);
        }

        /// <summary>
        /// Get clean, profesional looking axis parameters 
        /// </summary>
        /// <param name="min">a starting point for the axis minimum, usually a tail percentile</param>
        /// <param name="max">a starting point for the axis maximum, usually a tail percentile</param>
        /// <param name="ticks">desired number of axis ticks</param>
        /// <param name="buffer">minimum amount of whitespace buffer around specified min and max</param>
        public static XYAxis ToPretty(double min, double max, int ticks, double buffer)
        {
            /* Title: Axis Rescaling Algorithm (v2008.08.03), Copyright 2008-2009
             * By: Jonathan Legare
             * 
             * Parameter List
             *      Min: Minimum Axis Scale. Assert: Min < Max. Updated by reference.
             *      Max: Maximum Axis Scale. Assert: Max > Min. Updated by reference.
             *     Unit: Axis Unit. Updated by reference.
             *   Border: Additional white-space padding, proportional to range. Must be non-negative.
             * 
             *  Summary: Updates the axis minimum scale, maximum scale, and unit parameters such that
             *           the resulting graphical representation looks professional. The function 
             *           requires the data-based minimum and maximum, or upper and lower tail
             *           distribution percentiles. Optionally, the function will pad data within a
             *           border of whitespace, proportional to the range of the data. 
             * 
             *  Returns: If a "pretty" axis scale is found, then reference paremeters are updated 
             *           and the function returns true. Otherwise the function returns false and 
             *           reference paramters are not updated.
             *  
             *  Threads: Function is not thread safe.
             */

            double pmin = min;
            double pmax = max;
            double punit = 0d;

            double rMax = pmax + (pmax - pmin) * buffer;   // White-Space Adjusted Minimum Scale
            double rMin = pmin - (pmax - pmin) * buffer;   // White-Space Adjusted Maximum Scale
            double rRange = rMax - rMin;                   // White-Space Adjusted Range

            for (int i = 0; i < prettyUnits.Length; i++)         // Search for Pretty Units
                if (rRange < ticks * prettyUnits[i])             // If Pretty Units Found..
                {
                    punit = prettyUnits[i];
                    pmax = Math.Round(rMax - (rMax % punit) + ((rMax % punit != 0 && rMax > 0) ? punit : 0), 3);
                    pmin = Math.Round(rMin - (rMin % punit) - ((rMin % punit != 0 && rMin < 0) ? punit : 0), 3);
                    return new XYAxis(pmin, pmax, punit, false);
                }

            return new XYAxis(pmin, pmax, punit, true);
        }
    }
}