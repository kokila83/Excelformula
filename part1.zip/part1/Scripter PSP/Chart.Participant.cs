namespace Porter.Charts
{
    using System;

    public class Participant
    {
        /// <summary>
        /// Participant Age
        /// </summary>
        public readonly double? Age;

        /// <summary>
        /// Participant Percent Equity
        /// </summary>
        public readonly double? Equity;

        /// <summary>
        /// Indicates whether the participant is a do-it-yourself (DIY) investor
        /// </summary>
        public readonly bool IsDIY;

        /// <summary>
        /// Risk/Return of Participant Account in Total
        /// </summary>
        public readonly RiskReturnSet TtReturn;

        /// <summary>
        /// Risk/Return of Participant Account Excluding Company Stock
        /// </summary>
        public readonly RiskReturnSet CsReturn;

        /// <summary>
        /// Risk/Return Target Date Fund Benchmark
        /// </summary>
        public readonly RiskReturnSet TdReturn;

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="age">current age</param>
        /// <param name="equity">current percent equity</param>
        /// <param name="isDiy">whether the participant is a do-it-yourself investor</param>
        /// <param name="ttReturn">total returns</param>
        /// <param name="csReturn">total returns exclduing company stock</param>
        /// <param name="tdReturn">benchmark returns</param>
        public Participant(double? age, double? equity, bool isDiy, RiskReturnSet ttReturn, RiskReturnSet csReturn, RiskReturnSet tdReturn)
        {
            Age = age;
            Equity = equity;
            IsDIY = isDiy;

            TtReturn = ttReturn;
            CsReturn = csReturn;
            TdReturn = tdReturn;
        }

        private static int? ToNullableInt32(string s)
        {
            int i;
            if (int.TryParse(s, out i)) return i;
            return null;
        }

        private static double? ToNullableDouble(string s)
        {
            double d;
            if (double.TryParse(s, out d)) return d;
            return null;
        }

        public static Participant Parse(string[] text, TargetDateReturnSet series, Date date)
        {
            /* Expected File Layout
             * ------------------------------------------------------------------------------------
             * [02] AGE_A     Age
             * [03] EQUITY    Equity
             * [04] CM01Y     01-Year Cumulative Return
             * [05] CM03Y     03-Year Cumulative Return
             * [06] CM05Y     05-Year Cumulative Return
             * [07] CM10Y     10-Year Cumulative Return
             * [08] RK03Y     03-Year Risk
             * [09] RK05Y     05-Year Risk
             * [10] RK10Y     10-Year Risk
             * [11] CM01YNS   01-Year Cumulative Return Excluding Stock
             * [12] CM03YNS   03-Year Cumulative Return Excluding Stock
             * [13] CM05YNS   05-Year Cumulative Return Excluding Stock
             * [14] CM10YNS   10-Year Cumulative Return Excluding Stock
             * [15] RK03YNS   03-Year Risk Excluding Stock
             * [16] RK05YNS   05-Year Risk Excluding Stock
             * [17] RK10YNS   10-Year Risk Excluding Stock
             */

            double? age = ToNullableDouble(text[2]);
            double? equity = ToNullableDouble(text[3]);

            bool isDiy = int.Parse(text[04]) == 1;

            RiskReturnSet tdReturn = null;
            if (age.HasValue)
            {
                int birthYear = date.AddDays(-(int)(age.Value * 365.2425)).Year;
                tdReturn = series.GetNearest(birthYear).Performance;
            }

            double? cm03m = 0.0d, cm01y, an03y, an05y, an10y, sd03y, sd05y, sd10y;

            cm01y = an03y = an05y = an10y = sd03y = sd05y = sd10y = an03y = an05y = an10y = null;
            cm01y = ToNullableDouble(text[05]);
            an03y = ToNullableDouble(text[06]);
            an05y = ToNullableDouble(text[07]);
            an10y = ToNullableDouble(text[08]);
            sd03y = ToNullableDouble(text[09]);
            sd05y = ToNullableDouble(text[10]);
            sd10y = ToNullableDouble(text[11]);
            RiskReturnSet ttReturn = new RiskReturnSet(date, cm03m, cm01y, an03y, an05y, an10y, sd03y, sd05y, sd10y);

            cm01y = an03y = an05y = an10y = sd03y = sd05y = sd10y = an03y = an05y = an10y = null;
            cm01y = ToNullableDouble(text[12]);
            an03y = ToNullableDouble(text[13]);
            an05y = ToNullableDouble(text[14]);
            an10y = ToNullableDouble(text[15]);
            sd03y = ToNullableDouble(text[16]);
            sd05y = ToNullableDouble(text[17]);
            sd10y = ToNullableDouble(text[18]);
            RiskReturnSet csReturn = new RiskReturnSet(date, cm03m, cm01y, an03y, an05y, an10y, sd03y, sd05y, sd10y);

            return new Participant(age, equity, isDiy, ttReturn, csReturn, tdReturn);
        }
    }
}