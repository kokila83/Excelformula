namespace Porter.Charts
{
    using System;
    using System.IO;
    using System.Collections.Generic;

    using XL = Scripter.Office.Excel;
    using PP = Scripter.Office.PowerPoint;

    using Porter;
    using Porter.IO;
    using Porter.Compression.Zip;

    public static class ChartCreator
    {
        private static string rootFolder = (string)Properties.Chart.Default["rootFolder"];

        /// <summary>
        /// create a scatter plot deck for a single plan
        /// </summary>
        /// <param name="number">plan number</param>
        /// <param name="date">quarter end date</param>
        public static void Build(string number, DateTime date)
        {
            // Load Single Plan from File            
            string path = string.Format(rootFolder + "PLN.{0}.TXT", date.ToString("yyMM"));
            using (StreamReader reader = new StreamReader(path))
            {
                while(reader.Peek() != -1)
                {
                    string line = reader.ReadLine();                    
                    string thisNumber; DateTime thisDate;
                    Plan.Parse(line, out thisNumber, out thisDate);

                    if (thisNumber == number && thisDate == date)
                    {
                        build(true, new string[] { line });
                        break;
                    }
                }
            }
            Console.WriteLine("Done");
        }

        /// <summary>
        /// create a scatter plot deck for multiple plans
        /// </summary>
        /// <param name="date">quarter end date</param>
        public static void Build(DateTime date)
        {
            // Load XML Settings and Benchmarks
            TargetDateSeries[] data = TargetDateSeries.Parse(string.Format(rootFolder + "scatter.{0}.xml", date.ToString("yyMM")));
            SortedList<int, TargetDateSeries> tdSeriesList = new SortedList<int, TargetDateSeries>();
            foreach (TargetDateSeries item in data)
                tdSeriesList.Add(item.Id, item);

            // Load Single Plan from File
            List<string> lines = new List<string>(1024);
            string path = string.Format(rootFolder + "PLN.{0}.TXT", date.ToString("yyMM"));
            using (StreamReader reader = new StreamReader(path))
                while (reader.Peek() != -1)
                    lines.Add(reader.ReadLine());                

            build(false, lines.ToArray());
            Console.WriteLine("Done");
        }

        /// <summary>
        /// create a scatter plot deck for multiple plans
        /// </summary>
        /// <param name="plans">one or more plan instances</param>
        private static void build(bool saveXl, params string[] lines)
        {
            int xlOpenLimit = (int)Properties.Chart.Default["xlOpenLimit"];
            int xlMemoryLimit = (int)Properties.Chart.Default["xlMemoryLimit"];
            int xlStartDelay = (int)Properties.Chart.Default["xlStartDelay"];
            int xlTryCount = (int)Properties.Chart.Default["xlTryCount"];

            int ppOpenLimit = (int)Properties.Chart.Default["ppOpenLimit"];
            int ppMemoryLimit = (int)Properties.Chart.Default["ppMemoryLimit"];
            int ppStartDelay = (int)Properties.Chart.Default["ppStartDelay"];
            int ppTryCount = (int)Properties.Chart.Default["ppTryCount"];

            using (XL.Application xlInstance = new XL.Application(xlOpenLimit, xlMemoryLimit, xlTryCount, xlStartDelay))
            using (PP.Application ppInstance = new PP.Application(ppOpenLimit, ppMemoryLimit, ppTryCount, ppStartDelay))
            {
                // Create Subfolders
                if (!Directory.Exists(rootFolder + "ppt")) Directory.CreateDirectory(rootFolder + "ppt");
                if (!Directory.Exists(rootFolder + "png")) Directory.CreateDirectory(rootFolder + "png");
                if (!Directory.Exists(rootFolder + "xls")) Directory.CreateDirectory(rootFolder + "xls");

                if (!Directory.Exists(rootFolder + "ppt\\irc")) Directory.CreateDirectory(rootFolder + "ppt\\irc");
                if (!Directory.Exists(rootFolder + "ppt\\irp")) Directory.CreateDirectory(rootFolder + "ppt\\irp");                

                // Sort lines by date
                SortedList<Date, List<string>> linesByDate = new SortedList<Date, List<string>>();
                foreach (string line in lines)
                {
                    DateTime date;
                    Plan.PartialParse(line, out date);
                    if (linesByDate.ContainsKey(date) == false)
                        linesByDate.Add(date, new List<string>());

                    linesByDate[date].Add(line);
                }

                foreach (Date date in linesByDate.Keys)
                {
                    // Load XML Settings and Benchmarks
                    TargetDateSeries[] xmlData = TargetDateSeries.Parse(string.Format(rootFolder + "scatter.{0}.xml", date.ToString("yyMM")));
                    SortedList<int, TargetDateSeries> tdSeriesList = new SortedList<int, TargetDateSeries>();
                    foreach (TargetDateSeries item in xmlData)
                        tdSeriesList.Add(item.Id, item);

                    // open the zip file containing participant data
                    string zipPath = string.Format(rootFolder + "PRT.{0}.ZIP", date.ToString("yyMM"));
                    using (ZipFile zipFile = new ZipFile(zipPath))
                    {
                        // process each plan
                        foreach (string line in linesByDate[date])
                        {
                            // parse the plan number, date, and tdf series id
                            Plan.PartialParse(line
                                , out string number
                                , out DateTime d
                                , out int seriesId);

                            // skip already-processed plans
                            string outputFile = string.Format(rootFolder + "ppt\\irc\\{0}.{1}.ir.pptx"
                                , number, date.ToString("yyMM"));

                            if (File.Exists(outputFile))
                                continue;

                            Plan plan = Plan.Parse(line.Split('\t'), tdSeriesList[seriesId]);

                            // get entry with participant-level data from zip file
                            string entryName = string.Format("{0}.{1}.TXT", plan.Number, plan.Date.ToString("yyMM"));
                            if (zipFile.FindEntry(entryName, true) >= 0)
                            {
                                Console.WriteLine("Processing Plan: {0} as of {1}", plan.Number, plan.Date.ToString("yyyy-MM-dd"));
                                ZipEntry zipEntry = zipFile.GetEntry(entryName);
                                using (StreamReader reader = new StreamReader(zipFile.GetInputStream(zipEntry)))
                                {
                                    // parse participant data into plan         
                                    while (reader.Peek() != -1)
                                    {
                                        string[] text = reader.ReadLine().Split('\t');
                                        Participant item = Participant.Parse(text, plan.Series.Performance, plan.Date);
                                        plan.Add(item.Age, item.Equity, item.IsDIY, item.TtReturn, item.CsReturn, item.TdReturn);
                                    }
                                }

                                // process plan
                                plan.BuildSpreadsheet(xlInstance, rootFolder, saveXl);
                                plan.BuildIR(ppInstance, rootFolder);
                            }
                        } // end of plan loop
                    } // end of zipfile
                } // end of date loop 
            } // end of office application instances
        } // end of method     


        /// <summary>
        /// transform a single text file with participants from multiple plans into a zipped 
        /// archive with a single text file per plan
        /// </summary>
        /// <param name="textFileName">the input text file</param>
        /// <param name="date">the date of the data</param>
        public static void PrepareZipFile(string textFileName, DateTime date)
        {
            Console.WriteLine("preparing dataset: sorting file");            
            LineSorter.Sort(textFileName);
            StreamWriter writer = null;
            List<string> files = new List<string>(10000);

            Console.WriteLine("preparing dataset: disaggregating plans");
            try
            {
                using (StreamReader textReader = new StreamReader(textFileName))
                using (ParticipantLineReader lineReader = new ParticipantLineReader(textReader))
                {
                    string cur_pln = null, prv_pln = null;
                    string cur_ssn = null, prv_ssn = null;

                    while (lineReader.PeekLine() != null)
                    {
                        prv_pln = cur_pln;
                        prv_ssn = cur_ssn;                       

                        lineReader.PeekLine(out cur_pln, out cur_ssn);

                        if (cur_pln != prv_pln)
                        {
                            if (writer != null)
                                writer.Close();

                            string fileName = string.Format("{0}.{1}.txt"
                                // , int.Parse(cur_pln).ToString("00000")
                                , cur_pln
                                , date.ToString("yyMM"));

                            files.Add(fileName);
                            writer = new StreamWriter(fileName, true);
                        }
                        writer.WriteLine(lineReader.ReadLine());
                    }
                }
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }

            Console.WriteLine("preparing dataset: compressing plan files");
            ZipFile zipFile = ZipFile.Create(string.Format("PRT.{0}.ZIP", date.ToString("yyMM")));

            zipFile.BeginUpdate();
            foreach (string file in files)
                zipFile.Add(file);
            zipFile.CommitUpdate();

            Console.WriteLine("preparing dataset: cleaning up");
            File.Delete(textFileName);
            foreach (string file in files)
                File.Delete(file);
            
            Console.WriteLine("preparing dataset: finished");
        }
    }
}