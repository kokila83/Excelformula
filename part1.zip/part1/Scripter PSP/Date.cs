﻿// Copyright (C) 2012 Jonathan Legare
//
namespace Porter
{
    using System;

    /// <summary>
    /// A simple, memory-efficient date structure. 
    /// </summary>
    /// <remarks>
    /// This is a 32-bit alternative to the 64-bit System.DateTime and is implicitly
    /// convertable to and from System.DateTime. 
    /// 
    /// The basic functionality of this class was modeled after the System.DateTime 
    /// structure by Microsoft Corporation.
    /// </remarks>
    public struct Date : IComparable<Date>
    {
        private static readonly Date min = new Date(0001,01,01);
        private static readonly Date max = new Date(9999,12,31);

        private static readonly int[] DaysToMonth365 = {
            0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365};

        private static readonly int[] DaysToMonth366 = { 
            0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366};

        //private byte dd, mm;    // Underlying Day and Month
        //private ushort yy;      // Underlying Year

        private int data;
/*        {
            get
            {
                return (int)yy * 10000 + (int)mm * 100 + (int)dd;
            }
        }*/

        /// <summary>
        /// Create a new Porter.Date from a System.DateTime
        /// </summary>
        /// <param name="datetime">The System.DateTime to convert.</param>
        public Date(DateTime datetime)
            : this(datetime.Year, datetime.Month, datetime.Day)
        { }

        /// <summary>
        /// Create a new Porter.Date by specifying year, month and day.
        /// </summary>
        /// <param name="year">The year of the date.</param>
        /// <param name="month">The month of the date.</param>
        /// <param name="day">The day of the date.</param>
        public Date(int year, int month, int day)
        {
            if (year < 0 || year > 9999)
                throw new ArgumentOutOfRangeException("Invalid Year");

            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException("Invalid Month");

            if (day < 1 || day > 31)
                throw new ArgumentOutOfRangeException("Invalid Day");

            this.data = year * 10000 + month * 100 + day;

            //this.yy = (ushort)year;
            //this.mm = (byte)month;
            //this.dd = (byte)day;
        }

        /// <summary>
        /// Gets the smallest possible value of Porter.Date
        /// </summary>
        public static Date MinValue
        { get { return Date.min; } }

        /// <summary>
        /// Gets the largest possible value of Porter.Date
        /// </summary>
        public static Date MaxValue
        { get { return Date.max; } }

        /// <summary>
        /// Gets the year component of the date.
        /// </summary>
        public int Year
        {
            get
            {
                // return (int)yy;
                return this.data / 10000;
            }
        }

        /// <summary>
        /// Gets the month component of the date.
        /// </summary>
        public int Month
        {
            get
            {
                // return (int)mm;
                return (this.data - this.Year * 10000) / 100;
            }
        }

        /// <summary>
        /// Gets the day component of the date.
        /// </summary>
        public int Day
        {
            get
            {
                // return (int)dd;
                return this.data - this.Year * 10000 - this.Month * 100;
            }
        }

        /// <summary>
        /// Gets the current date.
        /// </summary>
        public static Date Today
        {
            get
            {
                return (Date)DateTime.Now;
            }
        }

        /// <summary>
        /// Implicitly convert System.DateTime to Porter.Date.
        /// </summary>
        /// <param name="date">The System.DateTime to convert.</param>
        public static implicit operator Date(DateTime date)
        {
            return new Date(date);
        }

        /// <summary>
        /// Implicitly convert Porter.Date to System.DateTime.
        /// </summary>
        /// <param name="date">The Porter.Date value to convert.</param>
        public static implicit operator DateTime(Date date)
        {
            //return new DateTime(date.yy, date.mm, date.dd);
            return new DateTime(date.Year, date.Month, date.Day);
        }

        /// <summary>
        /// Indicates whether two Date instances are equal.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static bool operator ==(Date a, Date b)
        {
            return a.data == b.data;
        }

        /// <summary>
        /// Indicates whether two Date instances are not equal.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static bool operator !=(Date a, Date b)
        {
            return a.data != b.data;
        }

        /// <summary>
        /// Indicates whether the left Date is greater than the right date.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static bool operator >(Date a, Date b)
        {
            return a.data > b.data;
        }

        /// <summary>
        /// Indicates whether the left Date is less than the right date.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static bool operator <(Date a, Date b)
        {
            return a.data < b.data;
        }

        /// <summary>
        /// Indicates whether the left Date is greater than or equal to the right date.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static bool operator >=(Date a, Date b)
        {
            return a.data >= b.data;
        }

        /// <summary>
        /// Indicates whether the left Date is less than or equal to the right date.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static bool operator <=(Date a, Date b)
        {
            return a.data <= b.data;
        }

        /// <summary>
        /// Calculate the number of days between two dates.
        /// </summary>
        /// <param name="a">The LHS Date value.</param>
        /// <param name="b">The RHS Date value.</param>
        public static int operator -(Date a, Date b)
        {
            return DaysFromEpoch(a) - DaysFromEpoch(b);
        }

        /// <summary>
        /// Add days to a date.
        /// </summary>
        /// <param name="date">A date value.</param>
        /// <param name="days">The number of days to add.</param>
        public static Date operator +(Date date, int days)
        {
            return date.AddDays(+days);
        }

        /// <summary>
        /// Subtract days from a date.
        /// </summary>
        /// <param name="date">A date value.</param>
        /// <param name="days">The number of days to subtract.</param>
        public static Date operator -(Date date, int days)
        {
            return date.AddDays(-days);
        }

        /// <summary>
        /// Converts the specified string representation of date to its Porter.Date equivalent.
        /// </summary>
        /// <param name="s">The string to convert.</param>
        public static Date Parse(string s)
        {
            // take advantage of the built-in datetime parser
            // return new Date(DateTime.Parse(s));
            return new Date(DateTime.ParseExact(s, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture));
        }

        /// <summary>
        /// Return the first day of the month.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static Date FirstDayMonth(Date date)
        {
            return new Date(date.Year, date.Month, 1);
        }

        /// <summary>
        /// Return the first day of the month.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static DateTime FirstDayMonth(DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1);
        }

        /// <summary>
        /// Return the first day of the year.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static Date FirstDayYear(Date date)
        {
            return new Date(date.Year, 1, 1);
        }

        /// <summary>
        /// Return the first day of the year.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static DateTime FirstDayYear(DateTime date)
        {
            return new DateTime(date.Year, 1, 1);
        }

        /// <summary>
        /// Return the first day of the quarter.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static Date FirstDayQuarter(Date date)
        {
            return new Date(date.Year, date.Month - (date.Month - 1) % 3, 1);
        }

        /// <summary>
        /// Return the first day of the quarter.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static DateTime FirstDayQuarter(DateTime date)
        {
            return new DateTime(date.Year, date.Month - (date.Month - 1) % 3, 1);
        }

        /// <summary>
        /// Return the last day of the month.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static Date LastDayMonth(Date date)
        {
            return new Date(date.Year, date.Month, 1).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// Return the last day of the month.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static DateTime LastDayMonth(DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// Return the last day of the quarter.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static Date LastDayQuarter(Date date)
        {
            return new Date(date.Year, date.Month + ((3 - date.Month % 3) % 3), 1).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// Return the last day of the quarter.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static DateTime LastDayQuarter(DateTime date)
        {
            return new DateTime(date.Year, date.Month + ((3 - date.Month % 3) % 3), 1).AddMonths(1).AddDays(-1);
        }

        /// <summary>
        /// Return the last day of the year.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static Date LastDayYear(Date date)
        {
            return new Date(date.Year, 12, 31);
        }

        /// <summary>
        /// Return the last day of the year.
        /// </summary>
        /// <param name="date">The reference date.</param>
        public static DateTime LastDayYear(DateTime date)
        {
            return new DateTime(date.Year, 12, 31);
        }

        /// <summary>
        /// Indicates whether this Date value equals another object. Returns true when the
        /// boxed object is a Porter.Date instance and the underlying values are equal.
        /// </summary>
        /// <param name="value">The object to check equality.</param>
        public override bool Equals(object value)
        {
            if (value is Date)
            {
                return this.data == ((Date)value).data;
            }
            else return false;
        }

        /// <summary>
        /// Returns the hash code for this Date value.
        /// </summary>
        public override int GetHashCode()
        {
            return this.data;
        }

        /// <summary>
        /// Compares this instance to another Porter.Date instance and returns an integer indicating their relative values. 
        /// </summary>
        /// <param name="other">Another Porter.Date instance to which this instance will be compared.</param>
        public int CompareTo(Date other)
        {
            return this.data.CompareTo(other.data);
        }

        /// <summary>
        /// Return the number of days since 01/01/0001.
        /// </summary>
        /// <param name="date">The reference date.</param>
        private static int DaysFromEpoch(Date date)
        {
            //int[] days = IsLeapYear(date.yy) ? DaysToMonth366 : DaysToMonth365;
            //int x = date.yy - 1;

            //return x * 365 + x / 4 - x / 100 + x / 400 + days[date.mm - 1] + date.dd - 1;

            int[] days = IsLeapYear(date.Year) ? DaysToMonth366 : DaysToMonth365;
            int x = date.Year - 1;

            return x * 365 + x / 4 - x / 100 + x / 400 + days[date.Month - 1] + date.Day - 1;
        }

        /// <summary>
        /// Add the specified number of days to the value of this instance.
        /// </summary>
        /// <param name="value">The number of days to add.</param>
        public Date AddDays(int value)
        {
            //int d = this.dd;
            //int m = this.mm;
            //int y = this.yy;
            int d = this.Day;
            int m = this.Month;
            int y = this.Year;
            int n = value;

            // Leap Day Avoidance
            if (m == 2 && d == 29)
                return new Date(y, m, d - 1).AddDays(value + 1);

            while (n > 366)
            {                
                if (IsLeapYear(y))
                    //if (m == 1 || (mm == 2 && d < 29)) n = n - 366;
                    if (m == 1 || (m == 2 && d < 29)) n = n - 366;
                    else n = n - 365;
                else if (IsLeapYear(y + 1))
                    //if (m == 1 || (mm == 2 && d < 29)) n = n - 365;
                    if (m == 1 || (m == 2 && d < 29)) n = n - 365;
                    else n = n - 366;
                else n = n - 365;

                y++;
            }
            while (n < -366)
            {
                if (IsLeapYear(y))
                    //if (m == 1 || (mm == 2 && d < 29)) n = n + 365;
                    if (m == 1 || (m == 2 && d < 29)) n = n + 365;
                    else n = n + 366;
                else if (IsLeapYear(y - 1))
                    //if (m == 1 || (mm == 2 && d < 29)) n = n + 366;
                    if (m == 1 || (m == 2 && d < 29)) n = n + 366;
                    else n = n + 365;
                else n = n + 365;

                y--;
            }            
            while (n > 0)
            {
                int x = DaysInMonth(y, m);
                if (n + d > x)
                {
                    n = n - (x - d + 1);
                    d = 1;

                    if (m == 12)
                    {
                        m = 1;
                        y = y + 1;
                    }
                    else m = m + 1;
                }
                else
                {
                    d = d + n;
                    break;
                }
            }
            while (n < 0)
            {
                if (-n > d - 1)
                {
                    if (m == 1)
                    {
                        m = 12;
                        y = y - 1;
                    }
                    else m--;

                    n = n + d;
                    d = DaysInMonth(y, m);

                }
                else
                {
                    d = d + n;
                    break;
                }
            }
            
            return new Date(y, m, d);
        }
        
        /// <summary>
        /// Suite of Integrity Tests 
        /// </summary>
        public static void Test()
        {
            #region Test Suite 1: Check Results of AddDays() Function and Measure Performance
            {
                int k = 31;
                for (int i = k; i < 73000; i++)
                {
                    DateTime d1 = DateTime.MinValue.AddDays(i).AddDays(367);
                    Date d2 = Date.MinValue.AddDays(i).AddDays(367);

                    if (d1.Year != d2.Year || d1.Month != d2.Month || d1.Day != d2.Day)
                        throw new Exception();

                    for (int j = -k; j <= k; j++)
                    {
                        DateTime d1x = d1.AddDays(j);
                        Date d2x = d2.AddDays(j);

                        if (d1x.Year != d2x.Year || d1x.Month != d2x.Month || d1x.Day != d2x.Day)
                            throw new Exception();
                    }

                }

                Date t1 = Date.Today; Date t1x;
                DateTime t2 = DateTime.Today; DateTime t2x;

                System.Diagnostics.Stopwatch sw1 = System.Diagnostics.Stopwatch.StartNew();
                for (int i = k; i < 73000; i++)
                    for (int j = -k; j < k; j++)
                    {
                        t1x = t1.AddDays(j);
                        //t1x = new Date(t1x.yy, t1x.mm, t1x.dd);
                    }
                sw1.Stop();

                System.Diagnostics.Stopwatch sw2 = System.Diagnostics.Stopwatch.StartNew();
                for (int i = k; i < 73000; i++)
                    for (int j = -k; j < k; j++)
                    {
                        t2x = t2.AddDays(j);
                        //t2x = new DateTime(t2x.Year, t2x.Month, t2x.Day);
                    }
                sw2.Stop();

                Console.WriteLine("New: {0}", sw1.ElapsedMilliseconds);
                Console.WriteLine("Old: {0}", sw2.ElapsedMilliseconds);
            }
            #endregion
            #region Test Suite 2: Check Subtraction Operators
            {
                DateTime t1 = DateTime.Today;
                Date d1 = Date.Today;

                for (int i = -50000; i < 50000; i++)
                {
                    DateTime t2 = t1.AddDays(i);
                    Date d2 = d1.AddDays(i);

                    if (d2.Year != t2.Year || d2.Month != t2.Month || d2.Day != t2.Day)
                        throw new Exception("d2 != t2");

                    int t3 = (int)(t2 - t1).TotalDays;
                    int d3 = d2 - d1;

                    if (d3 != t3)
                        throw new Exception("d3 != t3");

                    DateTime t4 = t1.AddDays(t3);
                    Date d4 = d1.AddDays(d3);

                    if (d4.Year != t4.Year || d4.Month != t4.Month || d4.Day != t4.Day)
                        throw new Exception("d4 != t4");
                }                
            }
            #endregion
            Console.WriteLine("All Tests Passed");
        }

        /// <summary>
        /// Add the specified number of months to the value of this instance.
        /// </summary>
        /// <param name="months">The number of months to add.</param>
        public Date AddMonths(int value)
        {
            //int dd = this.dd;
            //int mm = this.mm;
            //int yy = this.yy;

            int dd = this.Day;
            int mm = this.Month;
            int yy = this.Year;

            int i = mm - 1 + value;
            if (i >= 0)
            {
                mm = i % 12 + 01;
                yy = yy + i / 12;
            }
            else
            {
                mm = 12 + (i + 01) % 12;
                yy = yy + (i - 11) / 12;
            }

            dd = Math.Min(dd, DaysInMonth(yy, mm));

            return new Date(yy, mm, dd);
        }

        /// <summary>
        /// Add the specified number of years to the value of this instance.
        /// </summary>
        /// <param name="value">The number of years to add.</param>
        public Date AddYears(int value)
        {
            return AddMonths(12 * value);
        }

        /// <summary>
        /// Converts this instance to an ISO 8601 string representation. 
        /// </summary>
        public override string ToString()
        {
            //return string.Format("{0,4:0000}-{1,2:00}-{2,2:00}", (int)yy, (int)mm, (int)dd);
            return string.Format("{0,4:0000}-{1,2:00}-{2,2:00}", this.Year, this.Month, this.Day);
        }

        /// <summary>
        /// Converts this instance to string representation of the date.
        /// </summary>
        /// <param name="format">A System.DateTime format string.</param>
        public string ToString(string format)
        {
            return ((DateTime)this).ToString(format);
        }

        /// <summary>
        /// Indicates whether the year is a leap year.
        /// </summary>
        /// <param name="year">The year to check.</param>
        public static bool IsLeapYear(int year)
        {
            return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
        }

        /// <summary>
        /// Returns the number of days in a given year.
        /// </summary>
        /// <param name="year">The year to check.</param>
        public static int DaysInYear(int year)
        {
            return IsLeapYear(year) ? 366 : 355;
        }

        /// <summary>
        /// Returns the number of days in the given year and month.
        /// </summary>
        /// <param name="year">The year to check.</param>
        /// <param name="month">The month to check.</param>
        public static int DaysInMonth(int year, int month)
        {
            if (year < 0 || year > 9999)
                throw new ArgumentException("invalid year");

            if (month < 1 || month > 12)
                throw new ArgumentException("invalid month");

            if (IsLeapYear(year)) return DaysToMonth366[month] - DaysToMonth366[month - 1];
            else return DaysToMonth365[month] - DaysToMonth365[month - 1];
        } 
    }
}