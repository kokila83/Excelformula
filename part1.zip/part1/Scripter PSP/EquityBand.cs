﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace Porter
{
    /// <summary>
    /// a generic class to represent the width of something
    /// </summary>
    public class Width
    {
        /// <summary>
        /// the lower bound of the width
        /// </summary>
        public double Min { get; private set; }

        /// <summary>
        /// the upper bound of the width
        /// </summary>
        public double Max { get; private set; }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="min">lower bound of the width</param>
        /// <param name="max">upper bound of the width</param>
        public Width(double min, double max)
        {
            if (min > max)
                throw new ArgumentOutOfRangeException("min must be less than max");

            Min = min;
            Max = max;
        }

        /// <summary>
        /// convert this instance to a tab-delimited string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format("{0}\t{1}", Min, Max);
        }
    }

    /// <summary>
    /// class to represent the percent equity width at a point along the band
    /// </summary>
    public class EquityBandWidth : Width, ISequentialItem
    {
        /// <summary>
        /// number of years to retirement
        /// </summary>
        public int Id { get; private set; }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="id">number of years to retirement</param>
        /// <param name="min">minimum percent equity</param>
        /// <param name="max">maximum percent equity</param>
        public EquityBandWidth(int id, double min, double max)
            : base(min, max) 
        { 
            this.Id = id;
            if (min < 0 || min > 1)
                throw new ArgumentOutOfRangeException("equity band minimum must be between 0.0 and 1.0");

            if (max < 0 || max > 1)
                throw new ArgumentOutOfRangeException("equity band maximum must be between 0.0 and 1.0");
        }

        /// <summary>
        /// convert this instance to a tab-delimited string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format("{0}\t{1}", Id, base.ToString());
        }

        /// <summary>
        /// parse an instance from an xml node
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        public static EquityBandWidth Parse(XmlNode node)
        {
            if (node.Name != "EquityBandWidth")
                throw new XmlException("unexpected xml node");

            int id = int.Parse(node.Attributes["id"].Value);
            double min = double.Parse(node.Attributes["min"].Value);
            double max = double.Parse(node.Attributes["max"].Value);

            return new EquityBandWidth(id, min, max);
        }
    }

    /// <summary>
    /// a percent equity band, aka rolldown band
    /// </summary>
    public class EquityBand : SequentialList<EquityBandWidth>
    {
        /// <summary>
        /// percent equity band id
        /// </summary>
        public readonly int Id; 

        /// <summary>
        /// percent equity band name
        /// </summary>
        public readonly string Name;

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="id">percent equity band id</param>
        /// <param name="name">percent equity band name</param>
        /// <param name="items">array of band widths</param>
        public EquityBand(int id, string name, EquityBandWidth[] items)
            : base(items) 
        {
            Id = id;
            Name = name;
        }

        /// <summary>
        /// parse an instance from an xml node
        /// </summary>
        public static EquityBand Parse(XmlNode node)
        {
            // Expected XML Format
            // -------------------------------------------------
            // <EquityBand id="0" name="sample">
            //   <EquityBandWidth id="0" min="0.80", max="0.90">
            //   <EquityBandWidth id="1" min="0.80", max="0.90">
            //   <EquityBandWidth id="2" min="0.80", max="0.90">
            // </EquityBand>

            if (node.Name != "EquityBand")
                throw new XmlException("unexpected xml node");

            int id = int.Parse(node.Attributes["id"].Value);
            string name = node.Attributes["name"].Value;

            List<EquityBandWidth> items = new List<EquityBandWidth>();
            foreach (XmlNode item in node.ChildNodes)
                items.Add(EquityBandWidth.Parse(item));

            return new EquityBand(id, name, items.ToArray());
        }

        /// <summary>
        /// parse all instances from an xml document
        /// </summary>
        /// <param name="doc">an xml document</param>
        public static EquityBand[] Parse(XmlDocument doc)
        {
            List<EquityBand> data = new List<EquityBand>();
            XmlNodeList list = doc.GetElementsByTagName("EquityBand");
            foreach(XmlNode node in list)
                data.Add(Parse(node));

            return data.ToArray();
        }

        /// <summary>
        /// parse all instances from an xml document
        /// </summary>
        /// <param name="file">the full path of an xml file</param>
        public static EquityBand[] Parse(string file)
        {
            if (!File.Exists(file))
                throw new FileNotFoundException();

            XmlDocument document = new XmlDocument();
            document.Load(file);
            return Parse(document);
        }
    }
}