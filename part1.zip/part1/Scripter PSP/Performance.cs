﻿namespace Porter
{
    using System;

    interface IStandardReturnSet
    {
        double? Cm03m { get; }
        double? Cm01y { get; }
        double? An03y { get; }
        double? An05y { get; }
        double? An10y { get; }
    }

    interface IStandardRiskSet
    {
        double? Sd03y { get; }
        double? Sd05y { get; }
        double? Sd10y { get; }
    }

    /// <summary>
    /// class for manipulating return performance data
    /// </summary>
    public class ReturnSet : IStandardReturnSet
    {
        /// <summary>
        /// period end date
        /// </summary>
        public Date Date { get; private set; }

        /// <summary>
        /// 3-month cumulative return
        /// </summary>
        public double? Cm03m { get; private set; }

        /// <summary>
        /// 1-year cumulative return
        /// </summary>
        public double? Cm01y { get; private set; }

        /// <summary>
        /// 3-year average annual return
        /// </summary>
        public double? An03y { get; private set; }

        /// <summary>
        /// 5-year average annual return
        /// </summary>
        public double? An05y { get; private set; }

        /// <summary>
        /// 10-year average annual return
        /// </summary>
        public double? An10y { get; private set; }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="date">return period-end date</param>
        /// <param name="cm03m">3-month cumulative return</param>
        /// <param name="cm01y">1-year cumulative return</param>
        /// <param name="an03y">3-year average annual return</param>
        /// <param name="an05y">5-year average annual return</param>
        /// <param name="an10y">10-year average anual return</param>
        public ReturnSet(Date date, double? cm03m, double? cm01y, double? an03y, double? an05y, double? an10y)
        {
            if (an10y.HasValue && !(cm03m.HasValue && cm01y.HasValue && an03y.HasValue && an05y.HasValue))
                throw new ArgumentException("shorter periods missing data", "an10y");

            if (an05y.HasValue && !(cm03m.HasValue && cm01y.HasValue && an03y.HasValue))
                throw new ArgumentException("shorter periods missing data", "an05y");

            if (an03y.HasValue && !(cm03m.HasValue || cm01y.HasValue))
                throw new ArgumentException("shorter periods missing data", "an03y");

            if (cm01y.HasValue && !(cm03m.HasValue))
                throw new ArgumentException("shorter periods missing data", "cm01y");

            Date = date;
            Cm03m = cm03m;
            Cm01y = cm01y;
            An03y = an03y;
            An05y = an05y;
            An10y = an10y;
        }
    }

    /// <summary>
    /// class for manipulating risk and return performance data
    /// </summary>
    public class RiskReturnSet : ReturnSet, IStandardRiskSet
    {
        /// <summary>
        /// 3-year annualized standard deviation
        /// </summary>
        public double? Sd03y { get; private set; }

        /// <summary>
        /// 5-year annualized standard deviation
        /// </summary>
        public double? Sd05y { get; private set; }

        /// <summary>
        /// 10-year annualized standard deviation
        /// </summary>
        public double? Sd10y { get; private set; }

        /// <summary>
        /// create a new instance
        /// </summary>
        /// <param name="cm03m">3-month cumulative return</param>
        /// <param name="cm01y">1-year cumulative return</param>
        /// <param name="an03y">3-year cumulative return</param>
        /// <param name="an05y">5-year cumulative return</param>
        /// <param name="an10y">10-year cumulative return</param>
        /// <param name="sd03y">3-year risk</param>
        /// <param name="sd05y">5-year risk</param>
        /// <param name="sd10y">10-year risk</param>
        public RiskReturnSet(Date date, double? cm03m, double? cm01y, double? an03y, double? an05y, double? an10y, double? sd03y, double? sd05y, double? sd10y)
            : base(date, cm03m, cm01y, an03y, an05y, an10y)
        {
            if (sd03y.HasValue != an03y.HasValue)
                throw new ArgumentNullException("risk and return must both be provided or both be null");

            if (sd05y.HasValue != an05y.HasValue)
                throw new ArgumentNullException("risk and return must both be provided or both be null");

            if (sd10y.HasValue != an10y.HasValue)
                throw new ArgumentNullException("risk and return must both be provided or both be null");

            Sd03y = sd03y;
            Sd05y = sd05y;
            Sd10y = sd10y;
        }
    }
}
