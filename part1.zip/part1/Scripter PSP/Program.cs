﻿namespace Porter.Charts
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            string Command = args[0].ToLower().Trim();

            if (Command == "buildall")
            {
                try
                {
                    DateTime date = DateTime.Parse(args[1]);
                    ChartCreator.Build(date);
                }
                catch (Exception Exception)
                {
                    Console.WriteLine(Exception.Message);
                    Console.WriteLine(Exception.StackTrace);
                }
                return;
            }

            else if (Command == "buildone")
            {
                try
                {
                    DateTime date = DateTime.Parse(args[1]);
                    string planNumber = args[2].Trim();
                    ChartCreator.Build(planNumber, date);
                }
                catch (Exception Exception)
                {
                    Console.WriteLine(Exception.Message);
                    Console.WriteLine(Exception.StackTrace);
                }
                return;
            }

            else if (Command == "preparedata")
            {
                string file = args[1];
                DateTime date = DateTime.Parse(args[2]);
                ChartCreator.PrepareZipFile(file, date);
                return;
            }
        }
    }
}
